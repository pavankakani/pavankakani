package com.medplus.cache;
import org.springframework.stereotype.Service;

@Service
public class CacheTestServiceImpl implements CacheTestService {
	
	
	@Override
	@MedplusCacheable(expiresInSec=60000, cacheClearingEvent = PremitiveParamTestEvent.class, needRedis = true)
	public Test getTestWithPremitiveParams(int one, int two){
		System.out.println("in get test with premitive params  actual method");
		return new Test(one, two);
	}

	@Override
	@MedplusCacheable(expiresInSec=60000, cacheClearingEvent = ObjectParamTestEvent.class, needRedis = false)
	public Test getTestWithObjectParams(TestOne testOne, TestTwo testTwo) {
		System.out.println("in get test with object params actual method");
		return new Test(testOne.getOne(), testTwo.getTwo());
	}
	
}
