package com.medplus.cache;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;




public class CacheTestFireClearEvent {
	static AnnotationConfigApplicationContext context;
	static{
		context = new AnnotationConfigApplicationContext(SpringConfiguration.class);
	}
	
	public static void main(String[] args) {
		
		MedplusCache medplusCache = context.getBean(MedplusCache.class);
		System.out.println("medplusCache : "+ medplusCache);
		try {
			Thread.sleep(2000);
			medplusCache.fireClearEvent(new PremitiveParamTestEvent(""));
			Thread.sleep(5000);
			medplusCache.fireClearEvent(new ObjectParamTestEvent(""));
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("========================================");
	}
	
}
