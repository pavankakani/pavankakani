package com.medplus.cache;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;




public class CacheTest2 {
	static AnnotationConfigApplicationContext context;
	static{
		context = new AnnotationConfigApplicationContext(SpringConfiguration.class);
	}
	
	public static void main(String[] args) {
		
		CacheTestService cacheTest = context.getBean(CacheTestService.class);
		
		System.out.println(cacheTest.getTestWithPremitiveParams(1, 2));
		System.out.println(cacheTest.getTestWithPremitiveParams(2, 3));
		System.out.println(cacheTest.getTestWithPremitiveParams(4, 5));
		System.out.println(cacheTest.getTestWithPremitiveParams(5, 6));
		System.out.println(cacheTest.getTestWithPremitiveParams(1, 2));
		
		System.out.println(cacheTest.getTestWithObjectParams(new TestOne(1, "1"), new TestTwo(2, "2")));
		System.out.println(cacheTest.getTestWithObjectParams(new TestOne(2, "2"), new TestTwo(3, "3")));
		System.out.println(cacheTest.getTestWithObjectParams(new TestOne(4, "4"), new TestTwo(5, "5")));
		System.out.println(cacheTest.getTestWithObjectParams(new TestOne(5, "6"), new TestTwo(6, "6")));
		System.out.println(cacheTest.getTestWithObjectParams(new TestOne(1, "1"), new TestTwo(2, "2")));
		
		try {
			Thread.sleep(300000l);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		/*MedplusCache medplusCache = context.getBean(MedplusCache.class);
		System.out.println("medplusCache : "+ medplusCache);
		try {
			Thread.sleep(2000);
			medplusCache.fireClearEvent(new VoidEvent(""));
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		System.out.println("========================================");
		System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
		System.out.println("========================================");
		
		System.out.println(cacheTest.getTestWithPremitiveParams(1, 2));
		
		System.out.println(cacheTest.getTestWithObjectParams(new TestOne(1, "1"), new TestTwo(2, "2")));
	}
	
}
