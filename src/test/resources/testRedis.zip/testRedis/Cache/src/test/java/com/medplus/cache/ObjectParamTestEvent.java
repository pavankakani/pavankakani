package com.medplus.cache;

import org.springframework.context.ApplicationEvent;

/**
 * @author ShivaGanesh
 *
 */
public class ObjectParamTestEvent extends ApplicationEvent implements
		CacheInvalidator<ApplicationEvent> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1025729923102900771L;

	public ObjectParamTestEvent(Object source) {
		super(source);
	}

	public boolean invalidate(String thisCacheKey) {
		return true;
	}
}
