package com.medplus.cache;

public class TestTwo {

	int two;
	String strTwo;
	public int getTwo() {
		return two;
	}
	public void setTwo(int two) {
		this.two = two;
	}
	public String getStrTwo() {
		return strTwo;
	}
	public void setStrTwo(String strTwo) {
		this.strTwo = strTwo;
	}
	public TestTwo(int two, String strTwo) {
		super();
		this.two = two;
		this.strTwo = strTwo;
	}
	public TestTwo() {
		super();
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((strTwo == null) ? 0 : strTwo.hashCode());
		result = prime * result + two;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TestTwo other = (TestTwo) obj;
		if (strTwo == null) {
			if (other.strTwo != null)
				return false;
		} else if (!strTwo.equals(other.strTwo))
			return false;
		if (two != other.two)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "TestTwo [two=" + two + ", strTwo=" + strTwo + "]";
	}
	
	
}
