package com.medplus.cache;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource("classpath:cache-applicationContext.xml")
class SpringConfiguration {

}


public class CacheTest {
	static AnnotationConfigApplicationContext context;
	static{
		context = new AnnotationConfigApplicationContext(SpringConfiguration.class);
	}
	
	public static void main(String[] args) {
		
		CacheTestService cacheTest = context.getBean(CacheTestService.class);
		System.out.println(cacheTest.getTestWithPremitiveParams(1, 2));
		System.out.println(cacheTest.getTestWithPremitiveParams(2, 3));
		System.out.println(cacheTest.getTestWithPremitiveParams(4, 5));
		System.out.println(cacheTest.getTestWithPremitiveParams(5, 6));
		System.out.println(cacheTest.getTestWithPremitiveParams(1, 2));
		
		try {
			Thread.sleep(300000l);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("========================================");
		System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
		System.out.println("========================================");
		
		System.out.println(cacheTest.getTestWithPremitiveParams(1, 2));
	}
	
}
