package com.medplus.cache;
public class Test{
	int one;
	int two;
	public Test(int one, int two){
		this.one = one;
		this.two = two;
	}
	public int getOne() {
		return one;
	}
	public void setOne(int one) {
		this.one = one;
	}
	public int getTwo() {
		return two;
	}
	public void setTwo(int two) {
		this.two = two;
	}
	@Override
	public String toString() {
		return "Test [one=" + one + ", two=" + two + "]";
	}
	
}