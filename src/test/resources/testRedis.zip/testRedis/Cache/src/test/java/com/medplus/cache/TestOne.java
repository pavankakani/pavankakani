package com.medplus.cache;

public class TestOne {
	
	int one;
	String strOne;
	public int getOne() {
		return one;
	}
	public void setOne(int one) {
		this.one = one;
	}
	public String getStrOne() {
		return strOne;
	}
	public void setStrOne(String strOne) {
		this.strOne = strOne;
	}
	public TestOne(int one, String strOne) {
		super();
		this.one = one;
		this.strOne = strOne;
	}
	
	public TestOne() {
		super();
	}
	@Override
	public String toString() {
		return "TestOne [one=" + one + ", strOne=" + strOne + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + one;
		result = prime * result + ((strOne == null) ? 0 : strOne.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TestOne other = (TestOne) obj;
		if (one != other.one)
			return false;
		if (strOne == null) {
			if (other.strOne != null)
				return false;
		} else if (!strOne.equals(other.strOne))
			return false;
		return true;
	}

}
