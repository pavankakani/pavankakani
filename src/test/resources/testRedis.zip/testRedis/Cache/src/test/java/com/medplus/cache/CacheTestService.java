package com.medplus.cache;

public interface CacheTestService {

	public Test getTestWithPremitiveParams(int one, int two);
	
	public Test getTestWithObjectParams(TestOne testOne, TestTwo testTwo);
}
