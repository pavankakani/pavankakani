/**
 * 
 */
package com.medplus.cache;

import java.util.Arrays;
import java.util.List;

import net.sf.ehcache.Cache;

import org.apache.log4j.Logger;

import redis.clients.jedis.JedisPubSub;

/**
 * @author Venkat
 *
 */
public class MedplusCachePubSub extends JedisPubSub {

	static Logger logger = Logger.getLogger(MedplusCachePubSub.class);
	
	private Cache cache;
	
	public MedplusCachePubSub(Cache cache) {
		super();
		this.cache = cache;
	}
	
	@Override
	public void onMessage(String channel, String message) {
		logger.info("Message received. Channel : "
				+ channel + " message : " + message);
		try {
			if (message != null && message.length() > 0) {
				String[] splits = message.split("\\|");
				logger.info(" action, message : "+Arrays.toString(splits));
				if (splits != null) {
					if (splits.length == 2) {
						if (splits[0].equalsIgnoreCase("remove")) {
							@SuppressWarnings("unchecked")
							List<String> cacheKeys = cache.getKeys();
							logger.debug("cacheKeys : "+cacheKeys);
							for (String cacheKey : cacheKeys) {
								logger.debug("cacheKey : "+cacheKey 
										+ " event name : " + splits[1]);
								if(cacheKey.contains(splits[1])){
									boolean b = cache.remove(cacheKey);
									logger.debug(cacheKey + " removed from cache "+b);
								}else{
									logger.debug(cacheKey 
											+ "is not belongs to this event!");
								}
							}
							logger.info("cache cleared for event : "+ splits[1]);
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	@Override
	public void onPMessage(String pattern, String channel, String message) {

	}

	@Override
	public void onSubscribe(String channel, int subscribedChannels) {

	}

	@Override
	public void onUnsubscribe(String channel, int subscribedChannels) {

	}

	@Override
	public void onPUnsubscribe(String pattern, int subscribedChannels) {

	}

	@Override
	public void onPSubscribe(String pattern, int subscribedChannels) {
	}
	
	
}
