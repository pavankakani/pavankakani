package com.medplus.cache;

import org.springframework.context.ApplicationEvent;

/**
 * @author ShivaGanesh
 *
 */
public class VoidEvent extends ApplicationEvent implements
		CacheInvalidator<ApplicationEvent> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1025729923102900771L;

	public VoidEvent(Object source) {
		super(source);
	}

	public boolean invalidate(String thisCacheKey) {
		// TODO Auto-generated method stub
		return true;
	}
}
