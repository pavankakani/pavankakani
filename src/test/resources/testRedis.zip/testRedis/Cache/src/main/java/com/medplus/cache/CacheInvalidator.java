package com.medplus.cache;

import java.io.Serializable;

import org.springframework.context.ApplicationEvent;

/**
 * @author ShivaGanesh
 * 
 */
public interface CacheInvalidator<T extends ApplicationEvent> extends
		Serializable {

	boolean invalidate(String thisCacheKey);
}
