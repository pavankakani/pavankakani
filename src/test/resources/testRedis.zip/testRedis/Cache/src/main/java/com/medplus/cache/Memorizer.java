package com.medplus.cache;

import java.lang.reflect.Type;
import java.util.Set;

import javax.annotation.PostConstruct;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.medplus.redis.JedisConnection;
import com.medplus.redis.RedisKing;

/**
 * @author ShivaGanesh
 * 
 */
@Aspect
@Component
@DependsOn("RedisKing")
public class Memorizer implements ApplicationListener<ApplicationEvent> {
	
	public static final int CACHE_DB = 6;
	
	private static Logger logger = Logger.getLogger(Memorizer.class);
	
	Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();

	private static final String CACHE_NAME = "Cache";
	
	protected static final long RE_SUBSCRIBE_LIMIT = 300000l;

	private Cache cache;

	@Autowired
	private CacheManager cacheManager;
	@PostConstruct
	public void initializeCache() {
		logger.info("initializeCache begin");
		cache = cacheManager.getCache(CACHE_NAME);
		logger.info("starting subscriber thread");
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				MedplusCacheSubscriber subscriber = new MedplusCacheSubscriber(cache);
				MedplusCacheSubscriber subscriber1 = null;
				subscriber.start();
				while (true) {
					try {
						logger.debug("sleeping for " + RE_SUBSCRIBE_LIMIT + "to subscribe");
						Thread.sleep(RE_SUBSCRIBE_LIMIT);
						subscriber1 = new MedplusCacheSubscriber(cache);
						logger.debug("new subscriber started");
						subscriber1.start();
						if(subscriber.isSubscribed()){
							logger.debug("unsubscribe the old subscription");
							subscriber.unsubscribe();
						}
						subscriber = subscriber1;
					} catch (Exception e) {
						e.printStackTrace();
						logger.error(e.getLocalizedMessage(), e);
					}
				}
			}
		}).start();
		
		logger.info("initializeCache end");
	}

	@Around("@annotation(cacheable)")
	public Object aroundCacheableMethod(ProceedingJoinPoint pjp,
			MedplusCacheable cacheable) throws Throwable {
		
		String thisMethodKey = getObjectKey(pjp);
		String thisMethodParams = getObjectKeyOnlyParams(pjp);
		String thisMethodName = getObjectKeyWithOutParams(pjp);
		String thisCacheIdentifier = cacheable.cacheClearingEvent()
				.getCanonicalName();
		boolean isRedisRequired = cacheable.needRedis();
		String thisCacheKey = thisCacheIdentifier + "-" + thisMethodKey;
		logger.debug("isRedisRequired : " + isRedisRequired 
				+" thisCacheKey : "+ thisCacheKey);
		Element result = .get(thisCacheKey);
		logger.debug("Cache Result : "+result);
		if (result == null) {
			if (isRedisRequired) {
				try {
					Object redisObjectValue = gson.fromJson(RedisKing.
							getJedisServer().getJedisConnection(CACHE_DB)
							.hget(thisCacheIdentifier + "-"	+ thisMethodName,
							thisMethodParams), getSignature(pjp));
					
					logger.debug("Redis Result : "+redisObjectValue);
					if (redisObjectValue != null) {
						boolean isSavedToRedis = createCacheInEhCache(
								thisCacheKey, redisObjectValue, cacheable);
						logger.info("SAVED TO EHCACHE :" + isSavedToRedis
								+ ":");
						logger.debug("RESPONSE FROM -------------------- REDIS:"
								+ thisCacheKey + "---VALUE:" + redisObjectValue);
						return redisObjectValue;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else {
			logger.debug("RESPONSE FROM -------------------- MEDPLUS CACHE:"
					+ thisCacheKey + "---VALUE:" + result);
			return result.getObjectValue();
		}
		Object actualMethodResponse = pjp.proceed();
		logger.debug("Actual Methid Result : " + actualMethodResponse);
		try {
			if (isRedisRequired) {
				createCacheInRedis(thisCacheIdentifier, thisMethodName,
						thisMethodParams, actualMethodResponse);
			}
			createCacheInEhCache(thisCacheKey, actualMethodResponse,
						cacheable);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getLocalizedMessage(), e.fillInStackTrace());
		}
		logger.debug("RESPONSE FROM -------------------- ACTUAL METHOD:"
				+ thisCacheKey + "---VALUE:" + result);
		return actualMethodResponse;
	}
	
	private boolean createCacheInRedis(String eventName, String methodName,
			String params, Object value) {
		boolean status = true;
		try {
			RedisKing.getJedisServer().getJedisConnection(CACHE_DB)
					.sadd("CACHE_CLEARING_EVENTS", eventName);
			RedisKing
					.getJedisServer()
					.getJedisConnection(CACHE_DB)
					.hset(eventName + "-" + methodName, params,
							gson.toJson(value));
		} catch (Exception e) {
			status = false;
		}
		return status;
	}

	private boolean createCacheInEhCache(String objectKey, Object value,
			MedplusCacheable cacheable) {
		boolean status = true;
		try {
			logger.info("NEW KEY CREATED in cache :" + objectKey + ":");
			Element element = new Element(objectKey, value);
			element.setTimeToLive(cacheable.expiresInSec());
			cache.put(element);
		} catch (Exception e) {
			status = false;
		}
		return status;
	}

	private Type cachegetSignature(ProceedingJoinPoint pjp) {
		MethodSignature sig = (MethodSignature) pjp.getSignature();
		return sig.getMethod().getGenericReturnType();
	}

	private String getObjectKey(ProceedingJoinPoint pjp) {
		String targetName = pjp.getTarget().getClass().getSimpleName();
		String methodName = pjp.getSignature().getName();
		StringBuilder sb = new StringBuilder();
		sb.append(targetName).append(".").append(methodName);
		sb.append(getObjectKeyOnlyParams(pjp));
		logger.debug(sb.toString());
		return sb.toString();
	}

	private String getObjectKeyWithOutParams(ProceedingJoinPoint pjp) {
		String targetName = pjp.getTarget().getClass().getSimpleName();
		String methodName = pjp.getSignature().getName();
		StringBuilder sb = new StringBuilder();
		sb.append(targetName).append(".").append(methodName);
		logger.debug(sb.toString());
		return sb.toString();
	}

	private String getObjectKeyOnlyParams(ProceedingJoinPoint pjp) {
		Object[] args = pjp.getArgs();
		StringBuilder sb = new StringBuilder();
		if (args != null){
			for (Object arg : args){
				sb.append(".").append(arg instanceof Object ? arg.hashCode() : arg);
			}
		}
		logger.debug(sb.toString());
		return sb.toString();
	}

	void clearCache(String key) {
		cache.remove(key);
	}

	public void onApplicationEvent(ApplicationEvent event) {
		String eventName = event.getClass().getCanonicalName();
		logger.debug("event : "+event + " eventName : "+eventName);
		if (event instanceof CacheInvalidator) {
			Set<String> keysMatchingThisEvent = null;
			JedisConnection jedis = RedisKing.getJedisServer()
					.getJedisConnection(CACHE_DB);
			
			if (!jedis.sismember("CACHE_CLEARING_EVENTS", eventName)){
				logger.info("Publish a message to clear loacl caches of"
						+ " subscribed apps for event : " + eventName);
				MedplusCachePublisher.cacheClearPublish("remove|" + eventName);
				return;
			}
			try {
				keysMatchingThisEvent = jedis.keys(eventName + "*");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			logger.debug("keysMatchingThisEvent : "+keysMatchingThisEvent);
			if(keysMatchingThisEvent != null && keysMatchingThisEvent.size() > 0){
				try {
					logger.info("deleting redis cache for event : " + eventName);
					jedis.del(keysMatchingThisEvent.toArray(new String[0]));
					logger.info("redis cache cleared");
					logger.info("Publish a message to clear loacl caches of "
							+ "subscribed apps for event : " + eventName);
					MedplusCachePublisher.cacheClearPublish("remove|" + eventName);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		}
	}
}
