/**
 * 
 */
package com.medplus.cache;

import org.apache.log4j.Logger;

import net.sf.ehcache.Cache;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;

import com.medplus.redis.JedisConnection;
import com.medplus.redis.RedisKing;

/**
 * @author Venkat
 *
 */
public class MedplusCacheSubscriber extends Thread {

	static Logger logger = Logger.getLogger(MedplusCacheSubscriber.class);
	
	JedisPubSub jedisPubSub;
	
	public MedplusCacheSubscriber(Cache cache) {
		super();
		this.jedisPubSub = new MedplusCachePubSub(cache);
	}

	@Override
	public void run() {
		logger.info("MedplusCacheSubscriber started");
		try {
		
			JedisConnection jedisConnection = RedisKing
					.getJedisServer().getJedisConnection();
			Jedis jedis = jedisConnection.getConnection();
			logger.info("going to subscribe medplus channel");
			jedis.subscribe(jedisPubSub, MedplusCachePublisher.CACHE_CHANNEL);
			logger.info("channel was unsubscribed going to relase jedis resource");
			jedisConnection.releaseConnection(jedis);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getLocalizedMessage(), e);
		}
	}
	
	public void unsubscribe(){
		jedisPubSub.unsubscribe();
	}
	
	public boolean isSubscribed(){
		return jedisPubSub.isSubscribed();
	}
	
}

