package com.medplus.cache;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.ApplicationEvent;

/**
 * @author ShivaGanesh
 * 
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface MedplusCacheable {
	int expiresInSec() default 3600;

	Class<? extends ApplicationEvent> cacheClearingEvent() default VoidEvent.class;

	boolean needRedis() default true;

}
