package com.medplus.cache;

import org.apache.log4j.Logger;

import com.medplus.redis.RedisKing;

/**
 * @author ShivaGanesh
 * 
 */
public class MedplusCachePublisher {
	
	static Logger logger = Logger.getLogger(MedplusCachePublisher.class);
	
	public static final String CACHE_CHANNEL = "MEDPLUS_CACHE";

	public static boolean cacheClearPublish(String toClearKey) {
		try {
			long l = RedisKing.getJedisServer().getJedisConnection()
					.publish(CACHE_CHANNEL, toClearKey);
			logger.info("Publish message : " + toClearKey + " result : "+ l);
			return true;
		} catch (Exception e) {
			logger.info("exception occured in publishing message : " + toClearKey);
			logger.info(e.getLocalizedMessage());
			logger.info("re trying to Publish a message : " + toClearKey);
			cacheClearPublish(toClearKey);
		}
		return false;
	}
}
