package com.medplus.cache;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.stereotype.Component;

/**
 * @author ShivaGanesh
 * 
 */
@Component
public class MedplusCache {

	private ApplicationContext applicationContext;

	public void fireClearEvent(ApplicationEvent event) {
		applicationContext.publishEvent(event);
	}
	@Autowired
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.applicationContext = applicationContext;
	}
}