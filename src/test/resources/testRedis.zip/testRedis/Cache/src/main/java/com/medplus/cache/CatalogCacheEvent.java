package com.medplus.cache;

import org.springframework.context.ApplicationEvent;

public class CatalogCacheEvent extends ApplicationEvent implements CacheInvalidator<ApplicationEvent> {

	private static final long serialVersionUID = -902817614206891885L;

	public CatalogCacheEvent(Object source) {
		super(source);
	}

	public boolean invalidate(String thisCacheKey) {
		// check whether this key can be removed or not.
		return true;
	}

}
