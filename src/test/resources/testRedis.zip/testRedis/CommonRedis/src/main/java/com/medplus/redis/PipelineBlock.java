/**
 * 
 */
package com.medplus.redis;

import java.util.List;

import redis.clients.jedis.Pipeline;
import redis.clients.jedis.Response;

/**
 * @author venkat
 *
 */
public abstract class PipelineBlock extends Pipeline{
	
	public abstract void execute();
	
	public List<Object> run() {
		Response<List<Object>> res;
		execute();
		if(isInMulti()){
			res = exec();
		} else {
			return syncAndReturnAll();
		}
		close();
		try {
			client.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(res != null)
			return res.get();
		else return null;
		
	}
}
