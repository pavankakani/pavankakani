/**
 * 
 */
package com.medplus.redis;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisConnectionException;
import redis.clients.util.Pool;

/**
 * @author venkat
 *
 */
public abstract class JedisAction<T> {

	private int RETRYCOUNT = 3;
	
	private Pool<Jedis> jedisPool;
	
	public JedisAction(Pool<Jedis> jedisPool) {
		this.jedisPool = jedisPool;
	}

	public abstract T execute(Jedis connection);

	public T run(String key) {
		
		if (key == null) {
			
			return null;
		}

		return run();
	}
	
	public T run() {
		return runWithRetries(this.RETRYCOUNT);
	}

	private T runWithRetries(int redirections) {
		
		Jedis jedisConnection = null;
		try{
			jedisConnection = jedisPool.getResource();
			
			return execute(jedisConnection);
			
		}catch(JedisConnectionException e){
			
			if(redirections == 0){
				throw e;
			}
			return runWithRetries(redirections - 1);
		} finally{
			if(jedisConnection != null)
				jedisConnection.close();
		}
		
	}
}
