/**
 * 
 */
package com.medplus.redis;

import java.util.Collection;

import redis.clients.jedis.Protocol;

/**
 * @author venkat
 *
 */
public class ReadJedisInstance extends MyJedisInstance {


	public ReadJedisInstance(Collection<RedisConfig> redisConfigs) {
		super(redisConfigs);
	}

	@Override
	public JedisConnection getJedisConnection() {
		return getJedisConnection(0, Protocol.DEFAULT_DATABASE, true);
	}

	@Override
	public JedisConnection getJedisConnection(int dataBase) {
		return getJedisConnection(0,dataBase, true);
	}

}
