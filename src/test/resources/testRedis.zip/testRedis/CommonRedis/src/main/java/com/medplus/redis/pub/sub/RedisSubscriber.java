/**
 * 
 */
package com.medplus.redis.pub.sub;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.Jedis;

import com.medplus.redis.RedisKing;


/**
 * This is Thread that continuously start the subscription to the given channel
 * for every subscriptionTimeOut that specified, and will un-subscribe the previous
 * subscription.
 *    
 * @author venkat
 *
 */
public class RedisSubscriber extends Thread {
	
	static Logger logger = LoggerFactory.getLogger(RedisSubscriber.class);
	
	private String name;
	private PubSubAction pubSubAction;
	private String[] channels;
	private int subscriptionTimeOut = 300000;
	private SubscriptionType subscriptionType;
	private int logicalDb = 0;
	
	public RedisSubscriber(String name, PubSubAction pubSubAction, String[] channels, 
			int subscriptionTimeOut, SubscriptionType subscriptionType, int logicalDb) {
		super(name);
		this.name = name;
		this.pubSubAction = pubSubAction;
		this.channels = channels;
		this.logicalDb = logicalDb;
		if(subscriptionTimeOut != 0)
			this.subscriptionTimeOut = subscriptionTimeOut;
		this.subscriptionType = subscriptionType;
		setDaemon(true);
	}



	@Override
	public void run() {
		logger.info("redis subscriber start for name {}, channels {}", name, Arrays.toString(channels));
		Subscriber subscriber = new Subscriber(name, new MedplusPubSub(pubSubAction), getConnection(logicalDb), subscriptionType, channels);
		Subscriber subscriber1 = null;
		subscriber.start();
		while(true){
			try {
				logger.debug("wait {} ms to resubscribe.", subscriptionTimeOut);
				try {
					Thread.sleep(subscriptionTimeOut);
				} catch (Exception e) {
				}
				
				subscriber1 = new Subscriber(name, new MedplusPubSub(pubSubAction), getConnection(logicalDb), subscriptionType, channels);
				subscriber1.start();
				try {
					//wait 5 sec for subscribe to channel
					Thread.sleep(5000);
				} catch (Exception e) {
				}
				logger.debug("subscriber.isSubscribed() {}", subscriber.isSubscribed());
				if (subscriber.isSubscribed()){
					logger.debug("unsubscribe for name {}, channels {}", name, Arrays.toString(channels));
					subscriber.unsubscribe();
				}
				subscriber = subscriber1;
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	}

	Jedis getConnection(int logicalDb) {
		
		return RedisKing.getJedisServer().getJedisConnection(logicalDb).getConnection();
	}

}
