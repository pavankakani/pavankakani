/**
 * 
 */
package com.medplus.redis.pub.sub;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;
import static com.medplus.redis.pub.sub.SubscriptionType.*;

/**
 * This is Thread that subscribes to the given redis channel and, closes the
 * client connection when it was unsubscribe.
 * 
 * @author venkat
 *
 */
public class Subscriber extends Thread{

	static Logger logger = LoggerFactory.getLogger(Subscriber.class);
	
	private String name;//name of the subscriber
	private JedisPubSub jedisPubSub;
	private Jedis jedis;
	private String[] channels;
	private SubscriptionType subscriptionType;
	 
	public Subscriber(String name, JedisPubSub jedisPubSub, Jedis jedis, SubscriptionType subscriptionType, String... channels) {
		super(name);
		this.name = name;
		this.jedisPubSub = jedisPubSub;
		this.jedis = jedis;
		this.channels = channels;
		this.subscriptionType = subscriptionType;
		setDaemon(true);
	}

	@Override
	public void run() {
		
		try {
			logger.debug("subscribing {} to channels {}", name, Arrays.toString(channels));
			if(SUBSCRIBE == subscriptionType)
				jedis.subscribe(jedisPubSub, channels);
			else if(PSUBSCRIBE == subscriptionType)
				jedis.psubscribe(jedisPubSub, channels);
			logger.trace("closing redis connection");
			jedis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void unsubscribe(){
		if(SUBSCRIBE == subscriptionType)
			jedisPubSub.unsubscribe();
		else if(PSUBSCRIBE == subscriptionType)
			jedisPubSub.punsubscribe();
	}
	
	public boolean isSubscribed(){
		
		return jedisPubSub.isSubscribed();
	}

}
