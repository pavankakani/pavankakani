package com.medplus.redis.mq;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

import com.medplus.redis.RedisKing;

/**
 * @author venu
 * 
 */
public class Queue {
	// Name of the Queue
	String name;
	// static int noofputs=0;
	Map<Long, Map<String, Long>> rateStatsCache;
	LinkedBlockingQueue<DataPoint> rateStatsChan;
	long lastStatsWrite;
	Map<String, Consumer> consumerMap = Collections
			.synchronizedMap(new HashMap<String, Consumer>());
	static Map<String, Queue> queueMap = Collections
			.synchronizedMap(new HashMap<String, Queue>());

	private Queue(String name) {
		this.name = name;
	}

	// CreateQueue return a queue that you can put() or addConsumer() to
	// Works like SelectQueue for existing queues

	/**
	 * CreateQueue return a queue that you can put() or addConsumer() to. Works
	 * like SelectQueue for existing queues
	 * 
	 * @param name
	 *            - Name of the Queue
	 * @return Queue
	 */
	public static Queue CreateQueue(String name) {
		return newQueue(name);
	}

	private static synchronized Queue newQueue(String name) {
		if (queueMap.get(name) != null) {
			return queueMap.get(name);
		}
		Queue q = new Queue(name);
		// q.redisClient = redis.NewTCPClient(redisHost+":"+redisPort,
		// redisPassword, redisDB)
		RedisKing.getMQJedisServerConnection().sadd(KeyNames.masterQueueKey(),
				name);
		queueMap.put(name, q);
		q.startStatsWriter();
		return q;
	}

	// SelectQueue returns a Queue if a queue with the name exists
	/**
	 * Returns a Queue if there is Queue with this name else returns null;
	 * 
	 * @param name
	 *            - Name of the queue
	 * @return Queue or Null
	 */
	public static Queue selectQueue(String name) {

		boolean answer = RedisKing.getMQJedisServerConnection().sismember(
				KeyNames.masterQueueKey(), name);

		if (!answer) {
			return null;
		}

		return newQueue(name);
	}

	// AddConsumer returns a consumer that can write from the queue

	/**
	 * addConsumer returns a consumer that can write from the queue.
	 * 
	 * @param name
	 *            of the
	 * @return
	 * @throws IllegalStateException
	 *             , if Consumer with this name is already create and is
	 *             presently active.
	 */
	public synchronized Consumer addConsumer(String name)
			throws IllegalStateException {
		if (consumerMap.get(KeyNames.consumerNameKey(this.name, name)) != null) {
			return consumerMap.get(KeyNames.consumerNameKey(this.name, name));
		}
		Consumer c = new Consumer(name, this);
		// check uniqueness and start heartbeat
		long added = RedisKing.getMQJedisServerConnection().sadd(
				KeyNames.queueWorkersKey(this.name), name);
		if (added == 0) {
			if (isActiveConsumer(name)) {
				throw new IllegalStateException(
						"Consumer with this name is already present" + name);
			}
		}
		consumerMap.put(KeyNames.consumerNameKey(this.name, name), c);
		c.startHeartbeat();
		return c;
	}

	// Delete clears all input and failed queues as well as all consumers
	// will not proceed as long as consumers are running

	/**
	 * Delete clears all input and failed queues as well as all consumer will
	 * not proceed as long as consumers are running
	 */
	public synchronized void delete() {
		Set<String> consumers = getConsumers();

		if (consumers == null)
			return;
		for (String name : consumers) {
			try {
				if (isActiveConsumer(name)) {
					System.out
							.println("cannot delete queue with active consumers"
									+ name);
					continue;
				}
				Consumer customer = addConsumer(name);
				if (customer == null) {
					continue;
				}
				customer.resetWorking();
				RedisKing.getMQJedisServerConnection().srem(
						KeyNames.queueWorkersKey(this.name), name);
			} catch (Exception e) {
				e.printStackTrace();
				continue;
			}
		}

		resetInput();
		resetFailed();

		RedisKing.getMQJedisServerConnection().srem(KeyNames.masterQueueKey(),
				this.name);
		RedisKing.getMQJedisServerConnection().del(
				KeyNames.queueWorkersKey(this.name));
	}

	/**
	 * add the message to the queue
	 * 
	 * @param payload
	 */
	public void put(String payload) {
		Packet p = new Packet(System.currentTimeMillis(), payload, this);
		RedisKing.getMQJedisServerConnection().lpush(
				KeyNames.queueInputKey(name), p.getString());
		incrRate(KeyNames.queueInputRateKey(name), 1);
	}

	// requeueFailed moves all failed packages back to the input queue

	/**
	 * requeueFailed moves all failed packets back to the input queue
	 */
	public synchronized void requeueFailed() {
		long l = getFailedLength();
		while (l > 0) {
			RedisKing.getMQJedisServerConnection()
					.rpoplpush(KeyNames.queueFailedKey(name),
							KeyNames.queueInputKey(name));
			incrRate(KeyNames.queueInputRateKey(name), 1);
			l--;
		}
	}

	/**
	 * Removes all the failed messages of this Queue
	 */
	public void resetFailed() {
		RedisKing.getMQJedisServerConnection().del(
				KeyNames.queueFailedKey(this.name));
	}

	/**
	 * removes all the messages in the Queue. All the messages will be lost
	 * forever
	 */
	public void resetInput() {
		RedisKing.getMQJedisServerConnection().del(
				KeyNames.queueInputKey(this.name));

	}

	/**
	 * @return - Gets the number of failed messages in this queue
	 */
	public Long getFailedLength() {
		return RedisKing.getMQJedisServerConnection().llen(
				KeyNames.queueFailedKey(name));

	}

	/**
	 * @return gets the number messages in this queue
	 */
	public Long getInputLength() {
		return RedisKing.getMQJedisServerConnection().llen(
				KeyNames.queueInputKey(name));
	}

	void incrRate(String consumerWorkingRateKey, long value) {
		// TODO Auto-generated method stub
		DataPoint dp = new DataPoint(consumerWorkingRateKey, value);
		try {
			rateStatsChan.put(dp);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * @return Gets all the names of the consumers
	 */
	public Set<String> getConsumers() {
		return RedisKing.getMQJedisServerConnection().smembers(
				KeyNames.queueWorkersKey(name));
	}

	private void startStatsWriter() {
		rateStatsCache = new ConcurrentHashMap<Long, Map<String, Long>>();
		rateStatsChan = new LinkedBlockingQueue<DataPoint>();

		Thread t = new Thread(new Runnable() {
			public void run() {
				boolean writing = false;
				while (true) {
					try {
						DataPoint dp = null;
						try {
							dp = rateStatsChan.take();
							// System.out.println("Take Sucessful " + dp);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						if (dp == null) {
							continue;
						}
						long l = System.currentTimeMillis() / 1000;
						Map<String, Long> map = rateStatsCache.get(l);
						if (map == null) {
							map = new ConcurrentHashMap<String, Long>();
							rateStatsCache.put(l, map);
						}
						map.put(dp.name, dp.value);
						if (l > lastStatsWrite && !writing) {
							writing = true;
							writeStatsCacheToRedis(l);
							writing = false;
						}
					} catch (Exception e) {
						e.printStackTrace();

					}

				}

			}

		});
		t.start();

	}

	private void writeStatsCacheToRedis(long now) {

		try {
			for (long sec : rateStatsCache.keySet()) {
				if (sec >= now - 1) {
					continue;
				}

				for (String name : rateStatsCache.get(sec).keySet()) {
					String key = name + "::" + sec;
					// incrby can handle the situation where multiple inputs are
					// counted
					RedisKing.getMQJedisServerConnection().incrBy(key,
							rateStatsCache.get(sec).get(name));
					// save stats to redis with 2h expiration
					RedisKing.getMQJedisServerConnection().expire(key, 7200);
				}
				// track queue lengths
				String inputKey = KeyNames.queueInputSizeKey(name) + "::" + now;
				String failKey = KeyNames.queueFailedSizeKey(name) + "::" + now;
				RedisKing.getMQJedisServerConnection().setex(inputKey, 7200,
						getInputLength().toString());
				RedisKing.getMQJedisServerConnection().setex(failKey, 7200,
						getFailedLength().toString());
				rateStatsCache.remove(sec);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			lastStatsWrite = now;
		}
	}

	private boolean isActiveConsumer(String name) {

		String val = RedisKing.getMQJedisServerConnection().get(
				KeyNames.consumerHeartbeatKey(this.name, name));
		if (val != null && val.equalsIgnoreCase("ping")) {
			return true;
		}
		return false;

	}

}
