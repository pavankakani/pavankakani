package com.medplus.redis;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;
import redis.clients.jedis.exceptions.JedisConnectionException;
import redis.clients.jedis.exceptions.JedisDataException;
import redis.clients.jedis.exceptions.JedisException;

public class RedisKing {

	static Logger logger = LoggerFactory.getLogger(RedisKing.class);

	protected Set<MasterListener> masterListeners = new HashSet<MasterListener>();
	private static AtomicBoolean init = new AtomicBoolean();
	private static Map<String, String> publishedMessages = new HashMap<String, String>();
	private static Map<String, String> previousMasters = new HashMap<String, String>();;
	private static String REPLICATION_INFO = "replication";
	private static String MASTER = "master";
	private static String SLAVE = "slave";
	private static long SUB_UN_SUB_TIME_GAP = 300000l;
	
	private static Map<String, RedisConfig> redisConfigs = new HashMap<String, RedisConfig>();
	private static final Set<HostAndPort> sentinels = new HashSet<HostAndPort>();

	private static Object lock = new Object();
	/*
	 * static { monitor(); }
	 */
	private static MyJedisInstance masterJedis = null;
	private static MyJedisInstance readJedis = null;
	private static int mqDB = 4;
	private Map<String, String> redisConfigMap = new HashMap<String, String>();
	
 	/*
	 * protected RedisKing() {
	 *
	 * }
	 */

	public RedisKing(Map<String, String> redisConfigMap) {
		super();
		this.redisConfigMap = redisConfigMap;
	}

	private void setMqdb(){
		String mqDBStr = redisConfigMap.get("com.medplus.redis.mq.db");
		logger.info("Redis MQ DB ... " + mqDBStr);
		if (mqDBStr != null && mqDBStr.trim().length() > 0) {
			try {
				System.out.println("Setting Redis MQ DB ... " + mqDBStr);
				mqDB = Integer.parseInt(mqDBStr.trim());
			} catch (NumberFormatException nfe) {
				logger.warn("Invalid mqDb : {}, so continue with default DB : {}", mqDBStr, mqDB);
			}
		}
	}

	public void initRedisKing() {
		if (redisConfigMap != null) {
			setMqdb();
			//Reading sentinels
			if(!sentinels.isEmpty()){
				sentinels.clear();
			}
			for (int i = 1; i <= 15; i++) {
				String ip = redisConfigMap.get("com.medplus.redis.sentinel." + i + ".ip");
				int port = 16379; // default sentinel port

				if (ip != null && ip.trim().length() > 0) {

					String portStr = redisConfigMap.get("com.medplus.redis.sentinel." + i + ".port");

					logger.info("REDIS SENTINEL com.medplus.redis.sentinel.{}.ip : {}",i, ip);
					if (portStr != null && portStr.trim().length() > 0) {
						try {
							port = Integer.parseInt(portStr.trim());
						} catch (NumberFormatException nfe) {
							logger.warn("Invalid Port given for com.medplus.redis.sentinel.{}.port : {}, so continue with default port : {}", i, portStr, port);
						}
						sentinels.add(new HostAndPort(ip.trim(), port));
					}
				}
			}
			// Reading master name and database configuration
			for (int logicNum = 0; logicNum < 15; logicNum++) {
				String masterStr = redisConfigMap.get("com.medplus.redis.logical." + logicNum + ".master");
				String databaseStr = redisConfigMap.get("com.medplus.redis.logical." + logicNum + ".database");
				int database;
				if(masterStr != null && databaseStr != null){
					RedisConfig redisConfig = redisConfigs.get(masterStr);
					if (redisConfig == null){
						redisConfig = new RedisConfig();
						redisConfigs.put(masterStr, redisConfig);
					}
					redisConfig.setMasterName(masterStr.trim());
					try{
						database = Integer.parseInt(databaseStr.trim());
					}catch(NumberFormatException e){
						logger.info("Invalid Database given for logical number {} is {}", logicNum, databaseStr);
						continue;
					}
					redisConfig.addDatabase(logicNum, database);
				}
			}
			
			synchronized (lock) {
				for (Map.Entry<String, RedisConfig> redisConfigEntry : redisConfigs.entrySet()) {
					try {
						initSentinels(redisConfigEntry.getKey());
					} catch (RedisException e) {
						logger.error(e.getMessage());
					}
				}
				
				startListeners();
			}
			
		} else {
			throw new RedisException("redis config not defined");
		}
	}
	
	private void startListeners(){
		
		for (HostAndPort hap : sentinels) {
			MasterListener masterListener = new MasterListener(redisConfigs.keySet(), hap.getHost(), hap.getPort(), new String[] { "+switch-master", "+sdown", "-sdown" });
			// whether MasterListener threads are alive or not, process can be stopped
			masterListener.setDaemon(true);
			if (!masterListeners.contains(masterListener)) {
				masterListeners.add(masterListener);
				masterListener.start();
			}
		}
	}
	
	private void initSentinels(final String masterName) {
		List<HostAndPort> slaves = null;
		HostAndPort master = null;
		boolean sentinelAvailable = false;

		logger.info("Trying to find master from available Sentinels...");
		for (HostAndPort sentinelhap : sentinels) {

			logger.info("Connecting to Sentinel {}", sentinelhap);

			Jedis jedis = null;
			try {
				jedis = new Jedis(sentinelhap.getHost(), sentinelhap.getPort());

				List<String> masterAddr = jedis.sentinelGetMasterAddrByName(masterName);
				List<Map<String, String>> slavesMap = jedis.sentinelSlaves(masterName);

				// connected to sentinel...
				sentinelAvailable = true;

				if (masterAddr == null || masterAddr.size() != 2) {
					logger.info("Can not get master addr, master name: {}. Sentinel: {}", masterName, sentinelhap);
					continue;
				}
				master = toHostAndPort(masterAddr);

				if(master == null){
					logger.info("Unable to connect master... : {}", masterAddr);
					continue;
				}

				slaves = toSlaveHostAndPort(slavesMap);
				break;
			} catch (JedisException e) {
				logger.error("Cannot get master address from sentinel running @ {}. Reason: {}. Trying next one.", sentinelhap, e);
			} finally {
				if (jedis != null) {
					jedis.close();
				}
			}
		}

		if (master == null) {
			if (sentinelAvailable) {
				// can connect to sentinel, but master name seems to not monitored
				throw new JedisException("Can connect to sentinel, but " + masterName
						+ " seems to be not monitored...");
			} else {
				throw new JedisConnectionException("All sentinels down, cannot determine where is "
						+ masterName + " master is running...");
			}
		}
		logger.info("master : {} slaves : {}", master, slaves);
		
		RedisConfig rc = redisConfigs.get(masterName);
		if(rc == null){
			logger.info("Configuration Not Found for Master : {}", masterName);
			throw new RedisException("Configuration Not Found for Master : " + masterName);
		}
		if(masterJedis != null)
			masterJedis.cleanup(rc);
		rc.setMaster(master);
		rc.setSlaves(slaves);
		
	}

	@SuppressWarnings("unused")
	private int getIdleTime() {
		String idleTimeStr = redisConfigMap.get("com.medplus.redis.idleTime");
		int idleTime = 200;
		try {
			idleTime = Integer.parseInt(idleTimeStr.trim());
		} catch (NumberFormatException nfe) {
			logger.warn("Invalid Idleime : {}, so continue with default idleTime : {}", idleTimeStr, idleTime);
		}
		return idleTime;
	}

	@SuppressWarnings("unused")
	private int getActiveTime() {
		String activeTimeStr = redisConfigMap.get("com.medplus.redis.activeTime");
		int activeTime = 200;
		
		try {
			activeTime = Integer.parseInt(activeTimeStr.trim());
		} catch (NumberFormatException nfe) {
			logger.warn("Invalid ActiveTime : {}, so continue with default timeout : {}", activeTimeStr, activeTime);
		}
		
		return activeTime;
	}

	@SuppressWarnings("unused")
	private int getTimeOut() {
		String timeoutStr = redisConfigMap.get("com.medplus.redis.timeout");

		int timeout = 20000;
		try {
			timeout = Integer.parseInt(timeoutStr.trim());
		} catch (NumberFormatException nfe) {
			logger.warn("Invalid TimeOut : {}, so continue with default timeout : {}", timeoutStr, timeout);
		}
		
		return timeout;
	}
	
	private List<HostAndPort> toSlaveHostAndPort(
			List<Map<String, String>> slavesMap) {
		List<HostAndPort> slaves = new ArrayList<HostAndPort>();
		
		if(!slavesMap.isEmpty()){
			for (Map<String, String> slaveInfo : slavesMap) {
				HostAndPort hap = new HostAndPort(slaveInfo.get("ip"), 
						Integer.parseInt(slaveInfo.get("port")));
				if(pingRedis(hap, 2, SLAVE))
					slaves.add(hap);
			}
		}
		
		return slaves;
	}
	
	private boolean pingRedis(HostAndPort hap, int retry, String role){
		Jedis jedis = new Jedis(hap.getHost(), hap.getPort());
		try {
			String ping = jedis.ping();
			if ("PONG".equalsIgnoreCase(ping)) {
				String sectionInfo = jedis.info(REPLICATION_INFO);
				if(sectionInfo != null && sectionInfo.contains("role:"+role))
					return true;
			}
			
		} catch(JedisDataException e) {
			if (retry == 0)
				return false;
			logger.debug(e.getMessage());
			logger.debug("{}, wait 2 sec and try again", e.getMessage());
			try {
				Thread.sleep(2000l);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			
			return pingRedis(hap, retry-1, role);
		} catch (JedisConnectionException e) {
			logger.error("Unable to Connect to Redis Running @ {}", hap);
			
		} finally {
			jedis.close();
		}
		
		return false;
	}

	private HostAndPort toHostAndPort(List<String> getMasterAddrByNameResult) {
		String host = getMasterAddrByNameResult.get(0);
		int port = Integer.parseInt(getMasterAddrByNameResult.get(1));
		
		HostAndPort hap = new HostAndPort(host, port);
		if(pingRedis(hap, 2, MASTER))
			return hap;
		
		return null;
	}

	public static MyJedisInstance getJedisServerReadOnly() {
		if(init.get()){
			synchronized(lock){
				return getReadJedisInstance();
			}
		}

		return getReadJedisInstance();

	}

	private static MyJedisInstance getReadJedisInstance() {
		
		if(readJedis == null){
			readJedis = new ReadJedisInstance(redisConfigs.values());
		}
		
		return readJedis;
	}

	public static MyJedisInstance getJedisServer() {
		if(init.get()){
			synchronized(lock){
				return getMyJedisInstance();
			}
		}
		return getMyJedisInstance();
	}

	private static MyJedisInstance getMyJedisInstance() {
		if(masterJedis == null){
			masterJedis = new MyJedisInstance(redisConfigs.values());
		}
		return masterJedis;
	}

	public static JedisConnection getMQJedisServerConnection() {
		if(init.get()){
			synchronized(lock){
				return getMyJedisInstance().getJedisConnection(mqDB);
			}
		}
		return getMyJedisInstance().getJedisConnection(mqDB);

	}

	protected class MasterListener extends Thread {

		protected Collection<String> masterNames;
		protected String host;
		protected int port;
		protected long subscribeRetryWaitTimeMillis = 5000;
		protected volatile Jedis j;
		protected AtomicBoolean running = new AtomicBoolean(false);

		protected String[] channels = new String[]{"+switch-master"};

		protected MasterListener() {
		}

		public MasterListener(Collection<String> masterNames, String host, int port) {
			super(String.format("MasterListener-%s-[%s:%d]", masterNames, host, port));
			this.masterNames = masterNames;
			this.host = host;
			this.port = port;
		}

		public MasterListener(Collection<String> masterNames, String host, int port,
				long subscribeRetryWaitTimeMillis) {
			this(masterNames, host, port);
			this.subscribeRetryWaitTimeMillis = subscribeRetryWaitTimeMillis;
		}
		public MasterListener(Collection<String> masterNames, String host, int port,
				String[] channels) {
			this(masterNames, host, port);
			if(channels != null)
				this.channels = channels;
		}

		@Override
		public void run() {

			running.set(true);
			SentinelSubscriber subscriber = new SentinelSubscriber(new SentinelPubSub(host, port, channels, masterNames));
			SentinelSubscriber subscriber1;
			subscriber.start();
			while (running.get()) {
				try {
					try {
						Thread.sleep(SUB_UN_SUB_TIME_GAP);
					} catch (Exception e) {
					}
					subscriber1 = new SentinelSubscriber(new SentinelPubSub(host, port, channels, masterNames));
					subscriber1.start();
					try {
						//wait 5 sec for subscribe to sentinel
						Thread.sleep(5000);
					} catch (Exception e) {
					}
					if (subscriber.isSubscribed()){
						subscriber.unsubscribe();
					}
					subscriber = subscriber1;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		public void shutdown() {
			try {
				logger.info("Shutting down listener on {}:{}", host, port);
				running.set(false);
				// This isn't good, the Jedis object is not thread safe
				if (j != null) {
					j.disconnect();
				}
			} catch (Exception e) {
				logger.error("Caught exception while shutting down ", e);
			}
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + Arrays.hashCode(channels);
			result = prime * result + ((host == null) ? 0 : host.hashCode());
			result = prime * result
					+ ((masterNames == null) ? 0 : masterNames.hashCode());
			result = prime * result + port;
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			MasterListener other = (MasterListener) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (!Arrays.equals(channels, other.channels))
				return false;
			if (host == null) {
				if (other.host != null)
					return false;
			} else if (!host.equals(other.host))
				return false;
			if (masterNames == null) {
				if (other.masterNames != null)
					return false;
			} else if (!masterNames.equals(other.masterNames))
				return false;
			if (port != other.port)
				return false;
			return true;
		}

		private RedisKing getOuterType() {
			return RedisKing.this;
		}

	}
	
	protected class SentinelPubSub extends JedisPubSub {
		
		private String host;
		private int port;
		private String[] channels;
		private Collection<String> masterNames;
		
		public SentinelPubSub(String host, int port, String[] channels,
				Collection<String> masterNames) {
			super();
			this.host = host;
			this.port = port;
			this.channels = channels;
			this.masterNames = masterNames;
		}

		public String getHost() {
			return host;
		}

		public int getPort() {
			return port;
		}

		public String[] getChannels() {
			return channels;
		}

		public Collection<String> getMasterNames() {
			return masterNames;
		}

		@Override
		public void onMessage(String channel, String message) {
			logger.info("host : {}, port : {}, channer : {}, message: {}",
					host, port, channel, message);

			String[] switchMasterMsg = message.split(" ");
			
			if (switchMasterMsg.length > 3) {
				
				if((channel.equals(channels[1]) || channel.equals(channels[2])) && "sentinel".equals(switchMasterMsg[0])){
					return;
				}
				
				if((channel.equals(channels[1]) && ("master".equals(switchMasterMsg[0]) || "sentinel".equals(switchMasterMsg[0])))
						|| (channel.equals(channels[2]) && "sentinel".equals(switchMasterMsg[0])))
					return;
				
				String channelMessage = channel + ":" + message;
				String masterName = channel.equals(channels[0]) ? switchMasterMsg[0] : switchMasterMsg[5];
				logger.debug("publishedMessage for master {} is {}", masterName, publishedMessages.get(masterName));
				if(masterNames.contains(masterName) && !channelMessage.equals(publishedMessages.get(masterName))){
					if(channel.equals(channels[0])){
						previousMasters.put(masterName, switchMasterMsg[1] + ":" + switchMasterMsg[2]);
					}
					if(channel.equals(channels[2])){
						previousMasters.remove(masterName);
					}
					logger.debug("previousMaster for master {} is {}", masterName, previousMasters.get(masterName));
					if(channel.equals(channels[1]) && switchMasterMsg[1].equals(previousMasters.get(masterName)))
						return;

					logger.info("going to re init Redis King from sentinel {}:{}", host, port);
					init.set(true);
					synchronized (lock) {
						if(message.contains(masterName) && !channelMessage.equals(publishedMessages.get(masterName))){
							publishedMessages.put(masterName, channelMessage);
							try {
								initSentinels(masterName);
							} catch (Exception e) {
								logger.error(e.getMessage(), e);
							}
						}
					}
					init.set(false);

				} else {
					logger.info("Ignoring message on chennel : {}", channel);
				}

			} else {
				logger.info("Invalid message received on Sentinel {}:{},  channel {} : {}",
						host, port, channel, message);
			}
		}
	}
	
	protected class SentinelSubscriber extends Thread {
		
		private SentinelPubSub sentinelPubSub;
		
		public SentinelSubscriber(SentinelPubSub sentinelPubSub) {
			super();
			this.sentinelPubSub = sentinelPubSub;
			setDaemon(true);
		}

		@Override
		public void run() {
			try {
				Jedis jedis = new Jedis(sentinelPubSub.getHost(), sentinelPubSub.getPort());
				logger.debug("subscribe to {}:{}", sentinelPubSub.getHost(), sentinelPubSub.getPort());
				jedis.subscribe(sentinelPubSub, sentinelPubSub.getChannels());
				jedis.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		public void unsubscribe(){
			logger.debug("unsubscribe to {}:{}", sentinelPubSub.getHost(), sentinelPubSub.getPort());
			sentinelPubSub.unsubscribe();
		}
		
		public boolean isSubscribed(){
			return sentinelPubSub.isSubscribed();
		}
	}
	
}
