package com.medplus.redis.mq;

public class DataPoint {
	
	public DataPoint(String name2, long value2) {
		name=name2;
		value=value2;
	}
	String name;	
	long value;
	boolean incr;
	

}
