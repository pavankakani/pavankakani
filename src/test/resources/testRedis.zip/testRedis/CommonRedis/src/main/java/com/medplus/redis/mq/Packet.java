package com.medplus.redis.mq;

import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;

public class Packet {
	@Expose
	String payload;
	@Expose
	long createdtime;

	Queue queue;
	// Queue interface{} `json:"-"`
	Consumer consumer; // `json:"-"`
	List<Packet> packets;
	// Collection *[]*Package `json:"-"`
	boolean acked; // `json:"-"`

	// TODO add Headers or smth. when needed
	// wellle suggested error headers for failed packages

	Packet(long currentTimeMillis, String payload, Queue queue) {
		// TODO Auto-generated constructor stub
		this.createdtime = currentTimeMillis;
		this.payload = payload;
		this.queue = queue;
	}

	Packet(Queue q, Consumer c, boolean b) {
		this.queue = q;
		this.consumer = c;
		this.acked = b;
	}

	public Packet() {

	}

	public static Packet unmarshalPackage(String answer, Queue queue,
			Consumer consumer) {
		Gson gson1 = new GsonBuilder().excludeFieldsWithoutExposeAnnotation()
				.create();
		Packet p = gson1.fromJson(answer, Packet.class);
		p.queue = queue;
		p.consumer = consumer;
		p.acked = false;
		return p;

	}

	public String getPayload() {
		return payload;
	}

	public long getCreatedtime() {
		return createdtime;
	}

	public String getString() {
		Gson gson1 = new GsonBuilder().excludeFieldsWithoutExposeAnnotation()
				.create();
		return gson1.toJson(this);
	}

	public int index() {
		if (packets == null) {
			return 0;
		}
		int i = 0;
		for (Packet pack : packets) {
			if (this == pack) {
				return i;
			}
			i++;
		}
		return i;
	}

	// MultiAck removes all packaes from the fetched array up to and including
	// this package
	public void multiAck() {
		if (packets == null) {
			return;
		}
		// TODO write in lua
		for (int i = 0; i <= index(); i++) {
			Packet p = packets.get(i);
			// if the package has already been acked just skip
			if (p.acked == true) {
				continue;
			}

			consumer.ackPackage();

			p.acked = true;
		}

	}

	// Ack removes the packages from the queue
	public void ack() throws IllegalStateException {
		if (packets != null) {
			throw new IllegalStateException(
					"cannot Ack package in multi package answer");
		}
		consumer.ackPackage();

	}

	// Requeue moves a package back to input
	public void requeue() {
		reject(true);
	}

	// Fail moves a package to the failed queue
	public void fail() {
		reject(false);
	}

	private void reject(boolean requeue) throws IllegalStateException {
		if (packets != null
				&& (index() > 0 && packets.get(index() - 1).acked == false)) {
			throw new IllegalStateException(
					"cannot reject package while unacked package before it");
		}

		if (!requeue) {
			consumer.failPackage();

		} else {
			consumer.requeuePackage();
		}
	}
}
