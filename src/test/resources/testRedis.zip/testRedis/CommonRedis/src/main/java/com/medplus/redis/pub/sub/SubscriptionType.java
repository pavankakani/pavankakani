package com.medplus.redis.pub.sub;
public enum SubscriptionType {
	
	SUBSCRIBE,
	PSUBSCRIBE;
}