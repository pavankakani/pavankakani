/**
 * 
 */
package com.medplus.redis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import redis.clients.jedis.HostAndPort;

/**
 * @author venkat
 *
 */
public class RedisConfig {

	private String masterName;
	private HostAndPort master;
	private List<HostAndPort> slaves;
	private Map<Integer, Integer> databaseMap;
	
	
	public String getMasterName() {
		return masterName;
	}
	
	public void setMasterName(String masterName) {
		this.masterName = masterName;
	}
	
	public HostAndPort getMaster() {
		return master;
	}
	
	public void setMaster(HostAndPort master) {
		this.master = master;
	}
	
	public List<HostAndPort> getSlaves() {
		return slaves;
	}
	
	public void setSlaves(List<HostAndPort> slaves) {
		this.slaves = slaves;
	}
	
	public Map<Integer, Integer> getDatabaseMap() {
		return databaseMap;
	}
	
	public void setDatabaseMap(Map<Integer, Integer> databaseMap) {
		this.databaseMap = databaseMap;
	}
	
	public void addSlave(HostAndPort hop){
		if(this.slaves == null)
			this.slaves = new ArrayList<HostAndPort>();
		this.slaves.add(hop);
	}
	
	public void addSlave(String host, int port){
		addSlave(constructHostAndPort(host, port));
	}
	
	public void setMaster(String host, int port){
		setMaster(constructHostAndPort(host, port));
	}
	
	public HostAndPort constructHostAndPort(String host, int port){
		if(host == null || port == 0)
			return null;
		return new HostAndPort(host, port);
	}
	
	public void addDatabase(int logicNum, int database){
		if(databaseMap == null)
			databaseMap = new HashMap<Integer, Integer>();
		databaseMap.put(logicNum, database);
	}
	
	public int getDatabase(int logicNum){
		if(databaseMap == null)
			return 0;
		return databaseMap.get(logicNum);
	}
	
	public boolean isValidConfig(int logicNum){
		return (this.databaseMap != null && this.databaseMap.containsKey(logicNum));
	}

	@Override
	public String toString() {
		return "RedisConfig [masterName=" + masterName + ", master=" + master
				+ ", slaves=" + slaves + ", databaseMap=" + databaseMap + "]";
	}
	
	
}
