package com.medplus.redis.mq;

import java.util.ArrayList;
import java.util.List;

import com.medplus.redis.PipelineBlock;
import com.medplus.redis.RedisKing;

public class Consumer {
	String name;
	Queue queue;
	static final int HEARTBEATKEYEXPIRYINSEC = 2;
	static final int HEARTBEATINMILLISEC = 1000;
	//static int noofgets;
	protected Consumer(String name, Queue queue) {
		this.name = name;
		this.queue = queue;
	}

	// Get returns a single package from the queue (blocking)

	/**
	 * @return - Return next packet in the Queue and adds it to working queue of
	 *         the consumer.
	 * @throws IllegalStateException
	 */
	public Packet get() throws IllegalStateException {
		if (hasUnacked()) {
			throw new IllegalStateException(
					"Has unacked  messages in the queue, process them first before calling get");
		}
		return unsafeGet();
	}

	// Get returns a single package from the queue (blocking)

	/**
	 * @return - Return next packet in the Queue and adds it to working queue of
	 *         the consumer.
	 * @throws IllegalStateException
	 */
	public Packet get(int waitTimeinSecs) throws IllegalStateException {
		if (hasUnacked()) {
			throw new IllegalStateException(
					"Has unacked  messages in the queue, process them first before calling get");
		}
		return unsafeGet(waitTimeinSecs);
	}
	
	void startHeartbeat() {
		new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					// TODO: Make expiry time and sleep time configurable
					RedisKing.getMQJedisServerConnection().setex(
							KeyNames.consumerHeartbeatKey(queue.name, name),
							HEARTBEATKEYEXPIRYINSEC, "ping");
					try {
						Thread.sleep(HEARTBEATINMILLISEC);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

				}

			}
		}).start();

	}

	// hasUnacked returns true if the consumers has unacked packages
	private boolean hasUnacked() {
		if (getUnackedLength() != 0) {
			return true;
		}
		return false;
	}

	/**
	 * @return returns the number of packages in the unacked queue
	 */
	public long getUnackedLength() {
		// GetUnackedLength returns the number of packages in the unacked queue
		return RedisKing.getMQJedisServerConnection().llen(
				KeyNames.consumerWorkingQueueKey(queue.name, name));

	}

	/**
	 * @return Returns a single package from the queue (returns null if no
	 *         package in queue)
	 * @throws IllegalStateException
	 *             if they are any unacked messages
	 */
	public Packet noWaitGet() throws IllegalStateException {
		if (hasUnacked()) {
			throw new IllegalStateException(
					"Has unacked  messages in the queue, process them first before calling noWaitGet");
		}
		String answer = RedisKing.getMQJedisServerConnection().rpoplpush(
				KeyNames.queueInputKey(queue.name),
				KeyNames.consumerWorkingQueueKey(queue.name, name));
		if (answer.equalsIgnoreCase("")) {
			return null;
		}
		queue.incrRate(KeyNames.consumerWorkingRateKey(queue.name, name), 1);
		return parseRedisAnswer(answer);
	}

	// MultiGet returns an array of packages from the queue

	/**
	 * @param length
	 *            - Max number of packet
	 * @return Returns an array of packages from the queue. This is blocking
	 *         method. return only if there is at least one message in the queue
	 *         other wise wait till the queue has a message
	 * @throws IllegalStateException
	 *             - if they are any unacked messages
	 */
	public synchronized List<Packet> multiGet(final int length)
			throws IllegalStateException {
		List<Packet> packets = new ArrayList<Packet>();
		if (hasUnacked()) {
			throw new IllegalStateException(
					"Has unacked  messages in the queue, process them first before calling multi get");
		}

		// Jedis jedis = new Jedis("localhost");
		/*Pipeline pipeline = RedisKing.getMQJedisServerConnection().pipelined();
		pipeline.brpoplpush(KeyNames.queueInputKey(queue.name), KeyNames
				.consumerWorkingQueueKey(queue.name, name), 0);
		for (int i = 1; i < length; i++) {
			pipeline.rpoplpush(KeyNames.queueInputKey(queue.name),
					KeyNames.consumerWorkingQueueKey(
							queue.name, name));
		}
		List<Object> reqs = pipeline.syncAndReturnAll();*/
		List<Object> reqs = RedisKing.getMQJedisServerConnection().pipelined(
				new PipelineBlock() {

					@Override
					public void execute() {
						brpoplpush(KeyNames.queueInputKey(queue.name), KeyNames
								.consumerWorkingQueueKey(queue.name, name), 0);
						for (int i = 1; i < length; i++) {
							rpoplpush(KeyNames.queueInputKey(queue.name),
									KeyNames.consumerWorkingQueueKey(
											queue.name, name));
						}

					}
				});
		int gets = 0;
		for (Object answer : reqs) {
			if (answer != null && !answer.equals("nil")) {
				Packet p = parseRedisAnswer(answer.toString());
				if (p != null) {
					List<Packet> currpackets = new ArrayList<Packet>();
					currpackets.addAll(packets);
					currpackets.add(p);
					packets.add(p);
					p.packets = currpackets;
					gets++;
				}
				
			}
			
		}
		queue.incrRate(KeyNames.consumerWorkingRateKey(queue.name, name), gets);
		return packets;
	}

	private Packet parseRedisAnswer(String answer) {
		Packet p = null;
		if(answer!= null)
		 p = Packet.unmarshalPackage(answer, queue, this);
		return p;

	}

	// GetUnacked returns a single packages from the working queue of this
	// consumer
	/**
	 * @return returns a single packages from the working queue of this consumer
	 */
	public Packet getUnacked() {
		if (!hasUnacked()) {
			return null;
		}
		String answer = RedisKing.getMQJedisServerConnection().lindex(
				KeyNames.consumerWorkingQueueKey(queue.name, name), -1);
		return parseRedisAnswer(answer);
	}

	// GetFailed returns a single packages from the failed queue of this
	// consumer

	/**
	 * @return returns a single packages from the failed queue of this consumer
	 */
	public Packet getFailed() {
		String answer = RedisKing.getMQJedisServerConnection().rpoplpush(
				KeyNames.queueFailedKey(queue.name),
				KeyNames.consumerWorkingQueueKey(queue.name, name));

		queue.incrRate(KeyNames.consumerWorkingRateKey(queue.name, name), 1);
		return parseRedisAnswer(answer);
	}

	// RequeueWorking requeues all packages from working to input

	/**
	 * RequeueWorking requeues all packages from working to input
	 */
	public void requeueWorking() {
		while (hasUnacked()) {
			Packet p = getUnacked();
			if (p != null) {
				p.requeue();
			}
		}

	}

	public void ackPackage() {
		RedisKing.getMQJedisServerConnection().rpop(
				KeyNames.consumerWorkingQueueKey(queue.name, name));
	}

	public void requeuePackage() {
		RedisKing.getMQJedisServerConnection().rpoplpush(
				KeyNames.consumerWorkingQueueKey(queue.name, name),
				KeyNames.queueInputKey(queue.name));
		queue.incrRate(KeyNames.queueInputRateKey(queue.name), 1);
	}

	public void failPackage() {
		RedisKing.getMQJedisServerConnection().rpoplpush(
				KeyNames.consumerWorkingQueueKey(queue.name, name),
				KeyNames.queueFailedKey(queue.name));
	}

	private Packet unsafeGet() {
		String answer = RedisKing.getMQJedisServerConnection().brpoplpush(
				KeyNames.queueInputKey(queue.name),
				KeyNames.consumerWorkingQueueKey(queue.name, name), 0);
		queue.incrRate(KeyNames.consumerWorkingRateKey(queue.name, name), 1);
		return parseRedisAnswer(answer);
	}

	
	private Packet unsafeGet(int waitTimeInSecs) {
		String answer = RedisKing.getMQJedisServerConnection().brpoplpush(
				KeyNames.queueInputKey(queue.name),
				KeyNames.consumerWorkingQueueKey(queue.name, name),waitTimeInSecs);
		queue.incrRate(KeyNames.consumerWorkingRateKey(queue.name, name), 1);
		return parseRedisAnswer(answer);
	}

	// ResetWorking deletes! all messages in the working queue of this consumer
	/**
	 * deletes! all messages in the working queue of this consumer. All the
	 * packet in working queue will be lost for ever.
	 */
	public void resetWorking() {
		RedisKing.getMQJedisServerConnection().del(
				KeyNames.consumerWorkingQueueKey(queue.name, name));
		// queue.consumerMap.remove(KeyNames.consumerNameKey(queue.name, name));

	}

}
