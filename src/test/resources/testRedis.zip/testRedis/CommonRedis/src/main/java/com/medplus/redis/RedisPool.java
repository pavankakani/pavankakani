/**
 * 
 */
package com.medplus.redis;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.util.Pool;

/**
 * @author venkat
 *
 */
public class RedisPool {

	private Pool<Jedis> masterPool;
	
	private List<Pool<Jedis>> readPools;
	
	volatile int readKey;
	
	private boolean readInitiated = false;
	
	AtomicIntegerFieldUpdater<RedisPool> readIndex = AtomicIntegerFieldUpdater.newUpdater(RedisPool.class, "readKey");

	public RedisPool(Pool<Jedis> masterPool) {
		this.masterPool = masterPool;
		addMasterForReadPools();
	}

	public RedisPool() {
		// TODO Auto-generated constructor stub
	}

	public Pool<Jedis> getMasterPool() {
		return masterPool;
	}

	public void setMasterPool(Pool<Jedis> masterPool) {
		this.masterPool = masterPool;
		// to add masterPool in to readPools
		addMasterForReadPools();
	}

	protected List<Pool<Jedis>> getReadPools() {
		return readPools;
	}

	protected void setReadPools(List<Pool<Jedis>> readPools) {
		this.readPools = readPools;
		this.readInitiated = true;
	}

	public int getReadKey() {
		return readKey;
	}

	public void setReadKey(int readKey) {
		this.readKey = readKey;
	}

	private void addMasterForReadPools(){
		if(readPools == null)
			readPools = new ArrayList<Pool<Jedis>>();
		readPools.add(masterPool);
	}
	
	public void addReadPool(Pool<Jedis> jedisPool){
		if(readPools == null)
			readPools = new ArrayList<Pool<Jedis>>();
		this.readInitiated = true;
		readPools.add(jedisPool);
	}
	
	public synchronized Pool<Jedis> getReadPool(){
		
		if(readPools == null)
			throw new RedisException("ReadPool is not Initialized");
		
		int index = readIndex.incrementAndGet(this);
		
		if(index >= readPools.size()){
			readIndex.set(this, 0);
			index = 0;
		}
		
		return readPools.get(index);
	}
	
	
	public synchronized void  destroy(){
		
		if (this.masterPool != null)
			this.masterPool.destroy();
		this.masterPool = null;
		
		if (readPools != null && !this.readPools.isEmpty() ) {
			for (Pool<Jedis> pool : readPools) {
				pool.destroy();
			}
		}
		readPools = null;
		readIndex.set(this, 0);
	}

	public boolean isPoolInitilized(boolean isRead) {
		if(isRead)
			return this.readInitiated;
		else
			return (this.masterPool != null);
	}
	
	private static JedisPoolConfig config = new JedisPoolConfig();
	
	static{
		config.setMaxIdle(32);
		config.setMaxTotal(128);
	}
	
	public synchronized void initializePool(RedisConfig redisConfig, int logicNum, boolean isRead){
		
		int database = redisConfig.getDatabase(logicNum);
		if (isRead) {
			if(redisConfig.getSlaves() == null)
				return;
			for (HostAndPort hop : redisConfig.getSlaves()) {
				this.addReadPool(new JedisPool(config, hop.getHost(), hop.getPort(), 10000000,null, database));
			}
		} else {
			HostAndPort hop = redisConfig.getMaster();
			this.setMasterPool(new JedisPool(config, hop.getHost(), hop.getPort(), 10000000,null, database));
		}
	}

	@Override
	public String toString() {
		return "RedisPool [masterPool=" + masterPool + ", readPools="
				+ readPools + ", readKey=" + readKey + ", readInitiated="
				+ readInitiated + "]";
	}
	
}
