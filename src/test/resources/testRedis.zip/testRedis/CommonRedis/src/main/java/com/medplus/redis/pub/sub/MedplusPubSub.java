/**
 * 
 */
package com.medplus.redis.pub.sub;

import com.medplus.redis.RedisException;

import redis.clients.jedis.JedisPubSub;

/**
 * Default implementation for the JedisPubSub, to use in our framework, it depends 
 * on PubSubAction where the actual implementation of the action/events like
 * on message, subscribe, unsubscribe, etc 
 * 
 * @author venkat
 *
 */
public class MedplusPubSub extends JedisPubSub {
	
	private PubSubAction pubSubAction;
	
	public MedplusPubSub(PubSubAction pubSubAction) {
		super();
		if (pubSubAction == null)
			throw new RedisException("PubSubAction implementation is required to use redis pub sub");
		this.pubSubAction = pubSubAction;
	}

	@Override
	public void onMessage(String channel, String message) {

		pubSubAction.onMessage(channel, message);
	}

	@Override
	public void onPMessage(String pattern, String channel, String message) {
		
		pubSubAction.onPMessage(pattern, channel, message);
	}

	@Override
	public void onSubscribe(String channel, int subscribedChannels) {
		
		pubSubAction.onSubscribe(channel, subscribedChannels);
	}

	@Override
	public void onUnsubscribe(String channel, int subscribedChannels) {
		
		pubSubAction.onUnsubscribe(channel, subscribedChannels);
	}

	@Override
	public void onPUnsubscribe(String pattern, int subscribedChannels) {
		
		pubSubAction.onPUnsubscribe(pattern, subscribedChannels);
	}

	@Override
	public void onPSubscribe(String pattern, int subscribedChannels) {
		
		pubSubAction.onPSubscribe(pattern, subscribedChannels);
	}
	
}
