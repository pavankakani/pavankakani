package com.medplus.redis;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.medplus.redis.pub.sub.PubSubAction;
import com.medplus.redis.pub.sub.RedisSubscriber;

import redis.clients.jedis.BinaryClient.LIST_POSITION;
import redis.clients.jedis.BitOP;
import redis.clients.jedis.BitPosParams;
import redis.clients.jedis.DebugParams;
import redis.clients.jedis.GeoCoordinate;
import redis.clients.jedis.GeoRadiusResponse;
import redis.clients.jedis.GeoUnit;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.ScanParams;
import redis.clients.jedis.ScanResult;
import redis.clients.jedis.SortingParams;
import redis.clients.jedis.Tuple;
import redis.clients.jedis.ZParams;
import redis.clients.jedis.commands.AdvancedJedisCommands;
import redis.clients.jedis.commands.JedisCommands;
import redis.clients.jedis.commands.MultiKeyCommands;
import redis.clients.jedis.commands.ScriptingCommands;
import redis.clients.jedis.params.geo.GeoRadiusParam;
import redis.clients.jedis.params.set.SetParams;
import redis.clients.jedis.params.sortedset.ZAddParams;
import redis.clients.jedis.params.sortedset.ZIncrByParams;
import redis.clients.util.Pool;
import redis.clients.util.Slowlog;

import static com.medplus.redis.pub.sub.SubscriptionType.*;

public class JedisConnection implements JedisCommands, MultiKeyCommands,
		AdvancedJedisCommands, ScriptingCommands{

	private Pool<Jedis> jedisPool;

	public JedisConnection(Pool<Jedis> pool) {
		jedisPool = pool;
	}

	public Jedis getConnection(){
		return jedisPool.getResource();
	}
	public void releaseConnection(Jedis jedis){
		try {
			if (jedis != null)
				jedis.close();
		} catch (Exception e) {
		}
	}
	
	/**
	 * this method starts a thread for redis pub sub for the given channels,
	 * for specified subscribeTimeout this re subscribe the channel, when 
	 * ever any event published this will call the corresponding action of 
	 * pubSubAction
	 * 
	 * by default subscriptions are on redis shard 0(zero)
	 * 
	 * @param name
	 * @param pubSubAction
	 * @param subscribeTimeout
	 * @param channels
	 */
	
	public void pubsub(final String name, final PubSubAction pubSubAction, final int subscribeTimeout, final String... channels) throws Exception{
		
		try {
			new RedisSubscriber(name, pubSubAction, channels, subscribeTimeout, SUBSCRIBE, 0).start();
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * this method starts a thread for redis pub sub for the given channels,
	 * for specified subscribeTimeout this re subscribe the channel, when 
	 * ever any event published this will call the corresponding action of 
	 * pubSubAction
	 * 
	 * use this method when channel string is a pattern
	 * 
	 * @param logicalDb logical number for redis shard
	 * @param name
	 * @param pubSubAction
	 * @param subscribeTimeout
	 * @param channels
	 */
	
	public void patternPubSub(final int logicalDb, final String name, final PubSubAction pubSubAction, final int subscribeTimeout, final String... channels) throws Exception{
		
		try {
			new RedisSubscriber(name, pubSubAction, channels, subscribeTimeout, PSUBSCRIBE, logicalDb).start();
		} catch (Exception e) {
			throw e;
		}
	}
		
	@Override
	public String set(final String key,final String value) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.set(key,value);
            }
        }.run(key);
	}

	@Override
    public String get(final String key) {
        return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.get(key);
            }
        }.run(key);
    } 

	@Override
	public Boolean exists(final String key) {
		return new JedisAction<Boolean>(jedisPool) {
            @Override
            public Boolean execute(Jedis connection) {
                return connection.exists(key);
            }
        }.run(key);
	}

	@Override
	public String type(final String key) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.type(key);
            }
        }.run(key);
	}

	@Override
	public Long expire(final String key,final int seconds) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.expire(key,seconds);
            }
        }.run(key);
	}

	@Override
	public Long expireAt(final String key,final long unixTime) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.expireAt(key,unixTime);
            }
        }.run(key);
	}

	@Override
	public Long ttl(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.ttl(key);
            }
        }.run(key);
	}

	@Override
	public Boolean setbit(final String key,final long offset,final boolean value) {
		return new JedisAction<Boolean>(jedisPool) {
            @Override
            public Boolean execute(Jedis connection) {
                return connection.setbit(key,offset,value);
            }
        }.run(key);
	}

	@Override
	public Boolean getbit(final String key,final long offset) {
		return new JedisAction<Boolean>(jedisPool) {
            @Override
            public Boolean execute(Jedis connection) {
                return connection.getbit(key,offset);
            }
        }.run(key);
	}

	@Override
	public Long setrange(final String key,final long offset,final String value) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.setrange(key,offset,value);
            }
        }.run(key);
        }

	@Override
	public String getrange(final String key,final long startOffset,final long endOffset) {

		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.getrange(key,startOffset,endOffset);
            }
        }.run(key);
	}

	@Override
	public String getSet(final String key,final String value) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.getSet(key,value);
            }
        }.run(key);
	}

	@Override
	public Long setnx(final String key,final String value) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.setnx(key,value);
            }
        }.run(key);
	}

	@Override
	public String setex(final String key,final int seconds,final String value) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.setex(key,seconds,value);
            }
        }.run(key);
	}

	@Override
	public Long decrBy(final String key,final long integer) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.decrBy(key,integer);
            }
        }.run(key);
	}

	@Override
	public Long decr(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.decr(key);
            }
        }.run(key);
	}

	@Override
	public Long incrBy(final String key,final long integer) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.incrBy(key,integer);
            }
        }.run(key);
	}

	@Override
	public Long incr(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.incr(key);
            }
        }.run(key);
	}

	@Override
	public Long append(final String key,final String value) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.append(key,value);
            }
        }.run(key);
	}

	@Override
	public String substr(final String key,final int start,final int end) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.substr(key,start,end);
            }
        }.run(key);
	}

	@Override
	public Long hset(final String key,final String field,final String value) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.hset(key,field,value);
            }
        }.run(key);
	}

	@Override
	public String hget(final String key,final String field) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.hget(key,field);
            }
        }.run(key);
	}

	@Override
	public Long hsetnx(final String key,final String field,final String value) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.hsetnx(key,field,value);
            }
        }.run(key);
	}

	@Override
	public String hmset(final String key,final Map<String, String> hash) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.hmset(key,hash);
            }
        }.run(key);
	}

	@Override
	public List<String> hmget(final String key,final String... fields) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public List<String> execute(Jedis connection) {
                return connection.hmget(key,fields);
            }
        }.run(key);
	}

	@Override
	public Long hincrBy(final String key,final String field,final long value) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.hincrBy(key, field, value);
            }
        }.run(key);
	}

	@Override
	public Boolean hexists(final String key,final String field) {
		return new JedisAction<Boolean>(jedisPool) {
            @Override
            public Boolean execute(Jedis connection) {
                return connection.hexists(key,field);
            }
        }.run(key);
	}

	//@Override
	public Long hdel(final String key,final String field) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.hdel(key, field);
            }
        }.run(key);
	}

	@Override
	public Long hlen(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.hlen(key);
            }
        }.run(key);
	}

	@Override
	public Set<String> hkeys(final String key) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.hkeys(key);
            }
        }.run(key);
	}

	@Override
	public List<String> hvals(final String key) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public List<String> execute(Jedis connection) {
                return connection.hvals(key);
            }
        }.run(key);
	}

	@Override
	public Map<String, String> hgetAll(final String key) {
		return new JedisAction<Map<String,String>>(jedisPool) {
            @Override
            public Map<String,String> execute(Jedis connection) {
                return connection.hgetAll(key);
            }
        }.run(key);
	}

	// @Override
	public Long rpush(final String key,final String string) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.rpush(key, string);
            }
        }.run(key);
	}

	// @Override
	public Long lpush(final String key,final String string) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.lpush(key, string);
            }
        }.run(key);
	}

	@Override
	public Long llen(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.llen(key);
            }
        }.run(key);
	}

	@Override
	public List<String> lrange(final String key,final long start,final long end) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public List<String> execute(Jedis connection) {
                return connection.lrange(key, start, end);
            }
        }.run(key);
	}

	@Override
	public String ltrim(final String key,final long start,final long end) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.ltrim(key, start, end);
            }
        }.run(key);
	}

	@Override
	public String lindex(final String key,final long index) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.lindex(key, index);
            }
        }.run(key);
	}

	@Override
	public String lset(final String key,final long index,final String value) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.lset(key, index, value);
            }
        }.run(key);
	}

	@Override
	public Long lrem(final String key,final long count,final String value) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.lrem(key, count, value);
            }
        }.run(key);
	}

	@Override
	public String lpop(final String key) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.lpop(key);
            }
        }.run(key);
	}

	@Override
	public String rpop(final String key) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.rpop(key);
            }
        }.run(key);
	}

	// @Override
	public Long sadd(final String key,final String member) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.sadd(key, member);
            }
        }.run(key);
	}

	@Override
	public Set<String> smembers(final String key) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.smembers(key);
            }
        }.run(key);
	}

	// @Override
	public Long srem(final String key,final String member) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.srem(key, member);
            }
        }.run(key);
	}

	@Override
	public String spop(final String key) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.spop(key);
            }
        }.run(key);
	}

	@Override
	public Long scard(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.scard(key);
            }
        }.run(key);
	}

	@Override
	public Boolean sismember(final String key,final String member) {
		return new JedisAction<Boolean>(jedisPool) {
            @Override
            public Boolean execute(Jedis connection) {
                return connection.sismember(key, member);
            }
        }.run(key);
	}

	@Override
	public String srandmember(final String key) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.srandmember(key);
            }
        }.run(key);
     }

	@Override
	public Long zadd(final String key,final double score,final String member) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zadd(key, score, member);
            }
        }.run(key);
	}

	// @Override
	public Set<String> zrange(final String key,final int start,final int end) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrange(key, start, end);
            }
        }.run(key);
	}

	// @Override
	public Long zrem(final String key,final String member) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zrem(key, member);
            }
        }.run(key);
	}

	@Override
	public Double zincrby(final String key,final double score,final String member) {
		return new JedisAction<Double>(jedisPool) {
            @Override
            public Double execute(Jedis connection) {
                return connection.zincrby(key, score, member);
            }
        }.run(key);
	}

	@Override
	public Long zrank(final String key,final String member) {
		System.out.println("In impl");
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zrank(key, member);
            }
        }.run(key);
	}

	@Override
	public Long zrevrank(final String key,final String member) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zrevrank(key, member);
            }
        }.run(key);
	}

	// @Override
	public Set<String> zrevrange(final String key,final int start,final int end) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrevrange(key, start, end);
            }
        }.run(key);
	}

	// @Override
	public Set<Tuple> zrangeWithScores(final String key,final int start,final int end) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrangeByScoreWithScores(key, start, end);
            }
        }.run(key);
	}

	// @Override
	public Set<Tuple> zrevrangeWithScores(final String key,final int start,final int end) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrevrangeByScoreWithScores(key, start, end);
            }
        }.run(key);
	}

	@Override
	public Long zcard(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zcard(key);
            }
        }.run(key);
	}

	@Override
	public Double zscore(final String key,final String member) {
		return new JedisAction<Double>(jedisPool) {
            @Override
            public Double execute(Jedis connection) {
                return connection.zscore(key, member);
            }
        }.run(key);
	}

	@Override
	public List<String> sort(final String key) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public List<String> execute(Jedis connection) {
                return connection.sort(key);
            }
        }.run(key);
	}

	@Override
	public List<String> sort(final String key,final SortingParams sortingParameters) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public List<String> execute(Jedis connection) {
                return connection.sort(key, sortingParameters);
            }
        }.run(key);
	}

	@Override
	public Long zcount(final String key,final double min,final double max) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zcount(key, min, max);
            }
        }.run(key);
	}

	@Override
	public Set<String> zrangeByScore(final String key,final double min,final double max) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrangeByScore(key, min, max);
            }
        }.run(key);
	}

	@Override
	public Set<String> zrevrangeByScore(final String key,final double max,final double min) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrevrangeByScore(key, max,min);
            }
        }.run(key);
	}

	@Override
	public Set<String> zrangeByScore(final String key,final double min,final double max,
			final int offset,final int count) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrangeByScore(key, min, max,offset,count);
            }
        }.run(key);
	}

	@Override
	public Set<String> zrevrangeByScore(final String key,final double max,final double min,final int offset,final int count) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrangeByScore(key, max,min,offset,count);
            }
        }.run(key);
	}

	@Override
	public Set<Tuple> zrangeByScoreWithScores(final String key,final double min,final double max) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrangeByScoreWithScores(key, min, max);
            }
        }.run(key);
	}

	@Override
	public Set<Tuple> zrevrangeByScoreWithScores(final String key,final double max,
			final double min) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrevrangeByScoreWithScores(key, max, min);
            }
        }.run(key);
	}

	@Override
	public Set<Tuple> zrangeByScoreWithScores(final String key,final double min,
			final double max,final int offset,final int count) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrangeByScoreWithScores(key, min, max,offset,count);
            }
        }.run(key);
	}

	@Override
	public Set<Tuple> zrevrangeByScoreWithScores(final String key,final double max,
			final double min,final int offset,final int count) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrangeByScoreWithScores(key, max,min,offset,count);
            }
        }.run(key);
	}

	// @Override
	public Long zremrangeByRank(final String key,final int start,final int end) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zremrangeByRank(key, start, end);
            }
        }.run(key);
	}

	@Override
	public Long zremrangeByScore(final String key,final double start,final double end) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zremrangeByScore(key, start, end);
            }
        }.run(key);
	}

	@Override
	public Long linsert(final String key,final LIST_POSITION where,final String pivot,
			final String value) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.linsert(key, where, pivot, value);
            }
        }.run(key);
	}

	public String info() {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.info();
            }
        }.run();
	}

	public Long del(final String... keys) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.del(keys);
            }
        }.run();
	}

	public Set<String> keys(final String keys) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.keys(keys);
            }
        }.run(keys);
	}

	public Long zinterstore(final String dst,final String... keys) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zinterstore(dst, keys);
            }
        }.run();
	}

	@Override
	public Long zunionstore(final String string,final String... string2) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zunionstore(string, string2);
            }
        }.run();
	}

	public String flushAll() {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.flushAll();
            }
        }.run();

	}
	
	public String flushDB() {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.flushDB();
            }
        }.run();
	}

	public Long zinterstore(final String string,final ZParams params,final String... keys) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zinterstore(string, params, keys);
            }
        }.run();
	}

	@Override
	public Long hdel(final String key,final String... fields) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.hdel(key, fields);
            }
        }.run();
	}

	@Override
	public Long lpush(final String key,final String... string) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.lpush(key, string);
            }
        }.run(key);
	}

	public Long lpushx(final String key,final String string) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.lpushx(key, string);
            }
        }.run(key);
	}

	@Override
	public Long rpush(final String key,final String... strings) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.rpush(key, strings);
            }
        }.run(key);
	}

	public Long rpushx(final String key,final String string) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.rpushx(key, string);
            }
        }.run(key);
	}

	@Override
	public Long sadd(final String key,final String... members) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.sadd(key, members);
            }
        }.run(key);
	}

	@Override
	public Long srem(final String key,final String... members) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.srem(key, members);
            }
        }.run(key);
	}

	// @Override
	// public Long zadd(String key, Map<Double, String> map) {
	// for (int i = 0; i < RETRYCOUNT; i++) {
	// Jedis jedis = jedisPool.getResource();
	// try {
	// Long b = jedis.zadd(key, map);
	// jedisPool.returnResource(jedis);
	// return b;
	// } catch (Exception e) {
	// jedisPool.returnBrokenResource(jedis);
	//
	// }
	// }
	// return null;
	// }

	@Override
	public Long zcount(final String arg0,final String arg1,final String arg2) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zcount(arg0, arg1, arg2);
            }
        }.run(arg0);
	}

	@Override
	public Set<String> zrange(final String key,final long start,final long end) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrange(key, start, end);
            }
        }.run(key);
	}

	@Override
	public Set<String> zrangeByScore(final String arg0,final String arg1,final String arg2) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrangeByScore(arg0, arg1, arg2);
            }
        }.run(arg0);
	}

	@Override
	public Set<String> zrangeByScore(final String arg0,final String arg1,final String arg2,
			final int arg3,final int arg4) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrangeByScore(arg0, arg1, arg2, arg3, arg4);
            }
        }.run(arg0);

	}

	@Override
	public Set<Tuple> zrangeByScoreWithScores(final String arg0,final String arg1,
			final String arg2) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrangeByScoreWithScores(arg0, arg1, arg2);
            }
        }.run(arg0);
	}

	@Override
	public Set<Tuple> zrangeByScoreWithScores(final String arg0,final String arg1,
			final String arg2,final int arg3,final int arg4) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrangeByScoreWithScores(arg0, arg1, arg2,arg3,arg4);
            }
        }.run(arg0);
	}

	@Override
	public Set<Tuple> zrangeWithScores(final String arg0,final long arg1,final long arg2) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrangeWithScores(arg0, arg1, arg2);
            }
        }.run(arg0);
	}

	@Override
	public Long zrem(final String arg0,final String... arg1) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zrem(arg0, arg1);
            }
        }.run(arg0);
	}

	@Override
	public Long zremrangeByRank(final String arg0,final long arg1,final long arg2) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zremrangeByRank(arg0, arg1, arg2);
            }
        }.run(arg0);
	}

	@Override
	public Long zremrangeByScore(final String arg0,final String arg1,final String arg2) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.zremrangeByScore(arg0, arg1, arg2);
            }
        }.run(arg0);
	}

	@Override
	public Set<String> zrevrange(final String arg0,final long arg1,final long arg2) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrevrange(arg0, arg1, arg2);
            }
        }.run(arg0);
	}

	@Override
	public Set<String> zrevrangeByScore(final String arg0,final String arg1,final String arg2) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrevrangeByScore(arg0, arg1, arg2);
            }
        }.run(arg0);
	}

	@Override
	public Set<String> zrevrangeByScore(final String arg0,final String arg1,final String arg2,
			final int arg3,final int arg4) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public Set<String> execute(Jedis connection) {
                return connection.zrevrangeByScore(arg0, arg1, arg2,arg3,arg4);
            }
        }.run(arg0);
	}

	@Override
	public Set<Tuple> zrevrangeByScoreWithScores(final String arg0,final String arg1,
			final String arg2) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrevrangeByScoreWithScores(arg0, arg1, arg2);
            }
        }.run(arg0);
	}

	@Override
	public Set<Tuple> zrevrangeByScoreWithScores(final String arg0,final String arg1,
			final String arg2,final int arg3,final int arg4) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrevrangeByScoreWithScores(arg0, arg1, arg2,arg3,arg4);
            }
        }.run(arg0);
	}

	@Override
	public Set<Tuple> zrevrangeWithScores(final String key,final long start,final long end) {
		return new JedisAction<Set<Tuple>>(jedisPool) {
            @Override
            public Set<Tuple> execute(Jedis connection) {
                return connection.zrevrangeWithScores(key,start,end);
            }
        }.run(key);
	}

	@Override
	public Long persist(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.persist(key);
            }
        }.run(key);
	}

	@Override
	public Boolean setbit(final String key,final long offset,final String value) {
		return new JedisAction<Boolean>(jedisPool) {
            @Override
            public Boolean execute(Jedis connection) {
                return connection.setbit(key,offset,value);
            }
        }.run(key);
	}

	@Override
	public Long strlen(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.strlen(key);
            }
        }.run(key);
	}

	@Override
	public Long lpushx(final String key,final String... string) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.lpushx(key, string);
            }
        }.run(key);
	}

	@Override
	public Long rpushx(final String key,final String... string) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.rpushx(key, string);
            }
        }.run(key);
	}

	//@Override
	public List<String> blpop(final String arg) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public List<String> execute(Jedis connection) {
                return connection.blpop(arg);
            }
        }.run(arg);
	}

	//@Override
	public List<String> brpop(final String arg) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public List<String> execute(Jedis connection) {
                return connection.brpop(arg);
            }
        }.run(arg);
	}

	@Override
	public Long del(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.del(key);
            }
        }.run(key);
	}

	@Override
	public String echo(final String string) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public String execute(Jedis connection) {
                return connection.echo(string);
            }
        }.run();
	}

	@Override
	public Long move(final String key,final int dbIndex) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.move(key, dbIndex);
            }
        }.run(key);
	}

	@Override
	public Long bitcount(final String key) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.bitcount(key);
            }
        }.run(key);
	}

	@Override
	public Long bitcount(final String key,final long start,final long end) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.bitcount(key, start, end);
            }
        }.run(key);
	}

	/*@Override
	public ScanResult<Entry<String, String>> hscan(final String key,final int cursor) {
		return new JedisAction<ScanResult<Entry<String, String>>>(jedisPool) {
            @Override
            public ScanResult<Entry<String, String>> execute(Jedis connection) {
                return connection.hscan(key,cursor);
            }
        }.run(key);
	}

	public ScanResult<Entry<String, String>> hscan(final String key,final int cursor,
			final ScanParams params) {
		return new JedisAction<ScanResult<Entry<String, String>>>(jedisPool) {
            @Override
            public ScanResult<Entry<String, String>> execute(Jedis connection) {
                return connection.hscan(key,cursor,params);
            }
        }.run(key);
	}*/

	/*@Override
	public ScanResult<String> sscan(final String key,final int cursor) {
		return new JedisAction< ScanResult<String>>(jedisPool) {
            @Override
            public  ScanResult<String> execute(Jedis connection) {
                return connection.sscan(key,cursor);
            }
        }.run(key);
	}*/

	/*@Override
	public ScanResult<Tuple> zscan(final String key,final int cursor) {
		return new JedisAction< ScanResult<Tuple>>(jedisPool) {
            @Override
            public  ScanResult<Tuple> execute(Jedis connection) {
                return connection.zscan(key,cursor);
            }
        }.run(key);
	}*/

	@Override
	public Long zadd(final String key,final Map<String, Double> scoreMembers) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.zadd(key, scoreMembers);
            }
        }.run(key);
	}

	@Override
	public List<String> configGet(final String pattern) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public  List<String> execute(Jedis connection) {
                return connection.configGet(pattern);
            }
        }.run();
	}

	@Override
	public String configSet(final String parameter,final String value) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.configSet(parameter, value);
            }
        }.run();
	}

	@Override
	public String slowlogReset() {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.slowlogReset();
            }
        }.run();
	}

	@Override
	public Long slowlogLen() {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.slowlogLen();
            }
        }.run();
	}

	@Override
	public List<Slowlog> slowlogGet() {
		return new JedisAction<List<Slowlog>>(jedisPool) {
            @Override
            public  List<Slowlog> execute(Jedis connection) {
                return connection.slowlogGet();
            }
        }.run();
	}

	@Override
	public List<Slowlog> slowlogGet(final long entries) {
		return new JedisAction<List<Slowlog>>(jedisPool) {
            @Override
            public  List<Slowlog> execute(Jedis connection) {
                return connection.slowlogGet(entries);
            }
        }.run();
	}

	@Override
	public Long objectRefcount(final String string) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.objectRefcount(string);
            }
        }.run(string);
	}

	@Override
	public String objectEncoding(final String string) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.objectEncoding(string);
            }
        }.run(string);
    }

	@Override
	public Long objectIdletime(final String string) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.objectIdletime(string);
            }
        }.run(string);
	}

	@Override
	public List<String> blpop(final int timeout,final String... keys) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public  List<String> execute(Jedis connection) {
                return connection.blpop(timeout, keys);
            }
        }.run();
	}

	@Override
	public List<String> brpop(final int timeout,final String... keys) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public  List<String> execute(Jedis connection) {
                return connection.brpop(timeout, keys);
            }
        }.run();
	}

	@Override
	public List<String> blpop(final String... args) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public  List<String> execute(Jedis connection) {
                return connection.blpop(args);
            }
        }.run();
	}

	@Override
	public List<String> brpop(final String... args) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public  List<String> execute(Jedis connection) {
                return connection.brpop(args);
            }
        }.run();
	}

	@Override
	public List<String> mget(final String... keys) {
		return new JedisAction<List<String>>(jedisPool) {
            @Override
            public  List<String> execute(Jedis connection) {
                return connection.mget(keys);
            }
        }.run();
	}

	@Override
	public String mset(final String... keysvalues) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.mset(keysvalues);
            }
        }.run();
	}

	@Override
	public Long msetnx(final String... keysvalues) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.msetnx(keysvalues);
            }
        }.run();
	}

	@Override
	public String rename(final String oldkey,final String newkey) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.rename(oldkey, newkey);
            }
        }.run(oldkey);
	}

	@Override
	public Long renamenx(final String oldkey,final String newkey) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.renamenx(oldkey, newkey);
            }
        }.run(oldkey);
	}

	@Override
	public String rpoplpush(final String srckey,final String dstkey) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.rpoplpush(srckey, dstkey);
            }
        }.run(srckey);
	}

	@Override
	public Set<String> sdiff(final String... keys) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public  Set<String> execute(Jedis connection) {
                return connection.sdiff(keys);
            }
        }.run();
	}

	@Override
	public Long sdiffstore(final String dstkey,final String... keys) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.sdiffstore(dstkey, keys);
            }
        }.run(dstkey);
	}

	@Override
	public Set<String> sinter(final String... keys) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public  Set<String> execute(Jedis connection) {
                return connection.sinter(keys);
            }
        }.run();
	}

	@Override
	public Long sinterstore(final String dstkey,final String... keys) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.sinterstore(dstkey, keys);
            }
        }.run(dstkey);
	}

	@Override
	public Long smove(final String srckey,final String dstkey,final String member) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.smove(srckey, dstkey, member);
            }
        }.run(srckey);
	}

	@Override
	public Long sort(final String key,final SortingParams sortingParameters,final String dstkey) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.sort(key, sortingParameters,dstkey);
            }
        }.run(key);
	}

	@Override
	public Long sort(final String key,final String dstkey) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.sort(key, dstkey);
            }
        }.run(key);
	}

	@Override
	public Set<String> sunion(final String... keys) {
		return new JedisAction<Set<String>>(jedisPool) {
            @Override
            public  Set<String> execute(Jedis connection) {
                return connection.sunion(keys);
            }
        }.run();
	}

	@Override
	public Long sunionstore(final String dstkey,final String... keys) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.sunionstore(dstkey,keys);
            }
        }.run(dstkey);
	}

	@Override
	public String watch(final String... keys) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.watch(keys);
            }
        }.run();
	}

	@Override
	public String unwatch() {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.unwatch();
            }
        }.run();
	}

	@Override
	public Long zunionstore(final String dstkey,final ZParams params,final String... sets) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public  Long execute(Jedis connection) {
                return connection.zunionstore(dstkey, params, sets);
            }
        }.run(dstkey);
	}

	@Override
	public String brpoplpush(final String source,final String destination,final int timeout) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.brpoplpush(source, destination, timeout);
            }
        }.run(source);
	}

	@Override
	public Long publish(final String channel,final String message) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.publish(channel, message);
            }
        }.run();
	}

	@Override
	public void subscribe(final JedisPubSub jedisPubSub, final String... channels) {
		new JedisAction<Integer>(jedisPool) {
            @Override
            public Integer execute(Jedis connection) {
                connection.subscribe(jedisPubSub, channels);
                return 0;
            }
        }.run();

	}

	@Override
	public void psubscribe(final JedisPubSub jedisPubSub, final String... patterns) {
		new JedisAction<Integer>(jedisPool) {
            @Override
            public Integer execute(Jedis connection) {
                connection.psubscribe(jedisPubSub, patterns);
                return 0;
            }
        }.run();

	}

	@Override
	public String randomKey() {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.randomKey();
            }
        }.run();
	}

	@Override
	public Long bitop(final BitOP op,final String destKey,final String... srcKeys) {
		return new JedisAction<Long>(jedisPool) {
            @Override
            public Long execute(Jedis connection) {
                return connection.bitop(op, destKey, srcKeys);
            }
        }.run();
	}

	/*@Override
	public ScanResult<String> scan(final int cursor) {
		return new JedisAction<ScanResult<String>>(jedisPool) {
            @Override
            public  ScanResult<String> execute(Jedis connection) {
                return connection.scan(cursor);
            }
        }.run();
	}*/

	/**
	 * implement the execute method in {@link PipelineBlock}, with set of commands
	 * except sync and exec commands
	 * 
	 * @param pipelineBlock
	 * @return
	 */
	public List<Object> pipelined(final PipelineBlock pipelineBlock) {
		return new JedisAction<List<Object>>(jedisPool) {
            @Override
            public List<Object> execute(Jedis connection) {
            	pipelineBlock.setClient(connection.getClient());
            	return pipelineBlock.run();
            }
        }.run();
	}

	/**
	 * this method is deprecated, due to connection leaking
	 * 
	 * use method with {@link PipelineBlock} or get Pipeline from getConncetion()
	 * once the pipeline exec or sync done releaseConnection()
	 * 
	 * @return
	 */
	@Deprecated
	public Pipeline pipelined() {
		
		return getConnection().pipelined();
		/*return new JedisAction<Pipeline>(jedisPool) {
            @Override
            public  Pipeline execute(Jedis connection) {
                return connection.pipelined();
            }
        }.run();*/

	}

	@Override
	public Long exists(final String... keys) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.exists(keys);
			}
		}.run();
	}

	@Override
	public ScanResult<String> scan(final String cursor) {
		return new JedisAction<ScanResult<String>>(jedisPool) {
			@Override
			public ScanResult<String> execute(Jedis connection) {
				return connection.scan(cursor);
			}
		}.run();
	}

	@Override
	public ScanResult<String> scan(final String cursor, final ScanParams params) {
		return new JedisAction<ScanResult<String>>(jedisPool) {
			@Override
			public ScanResult<String> execute(Jedis connection) {
				return connection.scan(cursor, params);
			}
		}.run();
	}

	@Override
	public String pfmerge(final String destkey, final String... sourcekeys) {
		return new JedisAction<String>(jedisPool) {
			@Override
			public String execute(Jedis connection) {
				return connection.pfmerge(destkey, sourcekeys);
			}
		}.run();
	}

	@Override
	public long pfcount(final String... keys) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.pfcount(keys);
			}
		}.run();
	}

	@Override
	public String set(final String key, final String value, final SetParams params) {
		return new JedisAction<String>(jedisPool) {
			@Override
			public String execute(Jedis connection) {
				return connection.set(key, value, params);
			}
		}.run();
	}

	@Override
	public Long pexpire(final String key, final long milliseconds) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.pexpire(key, milliseconds);
			}
		}.run();
	}

	@Override
	public Long pexpireAt(final String key, final long millisecondsTimestamp) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.pexpireAt(key, millisecondsTimestamp);
			}
		}.run();
	}

	@Override
	public Long pttl(final String key) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.pttl(key);
			}
		}.run();
	}

	@Override
	public String psetex(final String key, final long milliseconds, final String value) {
		return new JedisAction<String>(jedisPool) {
			@Override
			public String execute(Jedis connection) {
				return connection.psetex(key, milliseconds, value);
			}
		}.run();
	}

	@Override
	public Double incrByFloat(final String key, final double value) {
		return new JedisAction<Double>(jedisPool) {
			@Override
			public Double execute(Jedis connection) {
				return connection.incrByFloat(key, value);
			}
		}.run();
	}

	@Override
	public Double hincrByFloat(final String key, final String field, final double value) {
		return new JedisAction<Double>(jedisPool) {
			@Override
			public Double execute(Jedis connection) {
				return connection.hincrByFloat(key, field, value);
			}
		}.run();
	}

	@Override
	public Set<String> spop(final String key, final long count) {
		return new JedisAction<Set<String>>(jedisPool) {
			@Override
			public Set<String> execute(Jedis connection) {
				return connection.spop(key, count);
			}
		}.run();
	}

	@Override
	public List<String> srandmember(final String key, final int count) {
		return new JedisAction<List<String>>(jedisPool) {
			@Override
			public List<String> execute(Jedis connection) {
				return connection.srandmember(key, count);
			}
		}.run();
	}

	@Override
	public Long zadd(final String key, final double score, final String member, final ZAddParams params) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.zadd(key, score, member, params);
			}
		}.run();
	}

	@Override
	public Long zadd(final String key, final Map<String, Double> scoreMembers,
			final ZAddParams params) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.zadd(key, scoreMembers, params);
			}
		}.run();
	}

	@Override
	public Double zincrby(final String key, final double score, final String member,
			final ZIncrByParams params) {
		return new JedisAction<Double>(jedisPool) {
			@Override
			public Double execute(Jedis connection) {
				return connection.zincrby(key, score, member, params);
			}
		}.run();
	}

	@Override
	public Long zlexcount(final String key, final String min, final String max) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.zlexcount(key, min, max);
			}
		}.run();
	}

	@Override
	public Set<String> zrangeByLex(final String key, final String min, final String max) {
		return new JedisAction<Set<String>>(jedisPool) {
			@Override
			public Set<String> execute(Jedis connection) {
				return connection.zrangeByLex(key, min, max);
			}
		}.run();
	}

	@Override
	public Set<String> zrangeByLex(final String key, final String min, final String max,
			final int offset, final int count) {
		return new JedisAction<Set<String>>(jedisPool) {
			@Override
			public Set<String> execute(Jedis connection) {
				return connection.zrangeByLex(key, min, max, offset, count);
			}
		}.run();
	}

	@Override
	public Set<String> zrevrangeByLex(final String key, final String max, final String min) {
		return new JedisAction<Set<String>>(jedisPool) {
			@Override
			public Set<String> execute(Jedis connection) {
				return connection.zrevrangeByLex(key, max, min);
			}
		}.run();
	}

	@Override
	public Set<String> zrevrangeByLex(final String key, final String max, final String min,
			final int offset, final int count) {
		return new JedisAction<Set<String>>(jedisPool) {
			@Override
			public Set<String> execute(Jedis connection) {
				return connection.zrevrangeByLex(key, max, min, offset, count);
			}
		}.run();
	}

	@Override
	public Long zremrangeByLex(final String key, final String min, final String max) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.zremrangeByLex(key, min, max);
			}
		}.run();
	}

	@Override
	public List<String> blpop(final int timeout, final String key) {
		return new JedisAction<List<String>>(jedisPool) {
			@Override
			public List<String> execute(Jedis connection) {
				return connection.blpop(timeout, key);
			}
		}.run();
	}

	@Override
	public List<String> brpop(final int timeout, final String key) {
		return new JedisAction<List<String>>(jedisPool) {
			@Override
			public List<String> execute(Jedis connection) {
				return connection.brpop(timeout, key);
			}
		}.run();
	}

	@Override
	public Long bitpos(final String key, final boolean value) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.bitpos(key, value);
			}
		}.run();
	}

	@Override
	public Long bitpos(final String key, final boolean value, final BitPosParams params) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.bitpos(key, value, params);
			}
		}.run();
	}

	@Override
	public ScanResult<Entry<String, String>> hscan(final String key, final String cursor) {
		return new JedisAction<ScanResult<Entry<String, String>>>(jedisPool) {
			@Override
			public ScanResult<Entry<String, String>> execute(Jedis connection) {
				return connection.hscan(key, cursor);
			}
		}.run();
	}

	@Override
	public ScanResult<Entry<String, String>> hscan(final String key, final String cursor,
			final ScanParams params) {
		return new JedisAction<ScanResult<Entry<String, String>>>(jedisPool) {
			@Override
			public ScanResult<Entry<String, String>> execute(Jedis connection) {
				return connection.hscan(key, cursor, params);
			}
		}.run();
	}

	@Override
	public ScanResult<String> sscan(final String key, final String cursor) {
		return new JedisAction<ScanResult<String>>(jedisPool) {
			@Override
			public ScanResult<String> execute(Jedis connection) {
				return connection.sscan(key, cursor);
			}
		}.run();
	}

	@Override
	public ScanResult<Tuple> zscan(final String key, final String cursor) {
		return new JedisAction<ScanResult<Tuple>>(jedisPool) {
			@Override
			public ScanResult<Tuple> execute(Jedis connection) {
				return connection.zscan(key, cursor);
			}
		}.run();
	}

	@Override
	public ScanResult<Tuple> zscan(final String key, final String cursor, final ScanParams params) {
		return new JedisAction<ScanResult<Tuple>>(jedisPool) {
			@Override
			public ScanResult<Tuple> execute(Jedis connection) {
				return connection.zscan(key, cursor, params);
			}
		}.run();
	}

	@Override
	public ScanResult<String> sscan(final String key, final String cursor, final ScanParams params) {
		return new JedisAction<ScanResult<String>>(jedisPool) {
			@Override
			public ScanResult<String> execute(Jedis connection) {
				return connection.sscan(key, cursor, params);
			}
		}.run();
	}

	@Override
	public Long pfadd(final String key, final String... elements) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.pfadd(key, elements);
			}
		}.run();
	}

	@Override
	public long pfcount(final String key) {
		return new JedisAction<Long>(jedisPool) {
			@Override
			public Long execute(Jedis connection) {
				return connection.pfcount(key);
			}
		}.run();
	}

	@Override
	public Long geoadd(String key, double longitude, double latitude,
			String member) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Long geoadd(String key,
			Map<String, GeoCoordinate> memberCoordinateMap) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double geodist(String key, String member1, String member2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double geodist(String key, String member1, String member2,
			GeoUnit unit) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> geohash(String key, String... members) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<GeoCoordinate> geopos(String key, String... members) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<GeoRadiusResponse> georadius(String key, double longitude,
			double latitude, double radius, GeoUnit unit) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<GeoRadiusResponse> georadius(String key, double longitude,
			double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<GeoRadiusResponse> georadiusByMember(String key, String member,
			double radius, GeoUnit unit) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<GeoRadiusResponse> georadiusByMember(String key, String member,
			double radius, GeoUnit unit, GeoRadiusParam param) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String debug(final DebugParams params){
		return new JedisAction<String>(jedisPool) {
			@Override
			public String execute(Jedis connection) {
				return connection.debug(params);
			}
		}.run();
	}
	
	/**
	 * It takes script and return object if script return object otherwise return null
	 * 
	 * @param script
	 * @return
	 */
	@Override
	public Object eval(final String script) {
		return new JedisAction<Object>(jedisPool) {
			@Override
			public  Object execute(Jedis connection) {
				return connection.eval(script);
			}
		}.run();
	}
	
	/**
	 * It takes script and return object, if script return object otherwise return null
	 * we can give values dynamically to script through these list of keys and list of arguments
	 * The keys can be accessed by Lua using the KEYS global variable in the form of a one-based array (so KEYS[1], KEYS[2], ...)
	 * Eg: eval("return KEYS[2]",[1,2],[3,4])  o/p: (Integer)2
	 * The args also used as same with ARGV global variable
	 * 
	 * @param script
	 * @return
	 */
	@Override
	public Object eval(final String script,final List<String> keys,final List<String> args) {
		return new JedisAction<Object>(jedisPool) {
			@Override
			public  Object execute(Jedis connection) {
				return connection.eval(script,keys,args);
			}
		}.run();
	}
	
	/**
	 * It takes script and return object if script return object otherwise return null
	 * 
	 * @param keycount specifies how many number of keys in params
	 * @param params array has keys and args.first 
	 * @param keycount number of elements are keys remaining are args 
	 * @param script
	 * @return
	 */
	@Override
	public Object eval(final String script,final int keyCount,final String... params) {
		return new JedisAction<Object>(jedisPool) {
			@Override
			public  Object execute(Jedis connection) {
				return connection.eval(script,keyCount,params);
			}
		}.run();
	}
	
	/**
	 * It takes sha and return object if script related to sha code return object otherwise return null
	 * 
	 * @param sha
	 * @return
	 */
	@Override
	public Object evalsha(final String script) {
		return new JedisAction<Object>(jedisPool) {
			@Override
			public  Object execute(Jedis connection) {
				return connection.evalsha(script);
			}
		}.run();
	}
	
	/**
	 * 
	 * @see eval method 
	 * 
	 * @param sha
	 * @return
	 */
	@Override
	public Object evalsha(final String sha1,final List<String> keys,final List<String> args) {
		return new JedisAction<Object>(jedisPool) {
			@Override
			public  Object execute(Jedis connection) {
				return connection.evalsha(sha1,keys,args);
			}
		}.run();
	}
	
	/**
	 * same as eval, but takes sha code as 
	 * 
	 * @param sha
	 * @return
	 */
	@Override
	public Object evalsha(final String sha1,final int keyCount,final String... params) {
		return new JedisAction<Object>(jedisPool) {
			@Override
			public  Object execute(Jedis connection) {
				return connection.evalsha(sha1,keyCount,params);
			}
		}.run();
	}

	
	/**
	 * It takes sha code as 
	 * 
	 * @param sha and returns true if its exists in scriptcache otherwise return false
	 * @return
	 */
	@Override
	public Boolean scriptExists(final String sha1) {
		return new JedisAction<Boolean>(jedisPool) {
			@Override
			public  Boolean execute(Jedis connection) {
				return connection.scriptExists(sha1);
			}
		}.run();
	}

	@Override
	public List<Boolean> scriptExists(final String... sha1) {
		return new JedisAction<List<Boolean>>(jedisPool) {
			@Override
			public  List<Boolean> execute(Jedis connection) {
				return connection.scriptExists(sha1);
			}
		}.run();
	}
	
	/**
	 * It takes script and gives sha code which can be used for evalsha
	 * @return
	 */
	@Override
	public String scriptLoad(final String script) {
		return new JedisAction<String>(jedisPool) {
            @Override
            public  String execute(Jedis connection) {
                return connection.scriptLoad(script);
            }
        }.run();
	}

}