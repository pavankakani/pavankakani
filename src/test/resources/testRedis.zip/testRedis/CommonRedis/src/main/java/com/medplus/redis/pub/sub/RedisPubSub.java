/**
 * 
 */
package com.medplus.redis.pub.sub;

import com.medplus.redis.RedisException;
import com.medplus.redis.RedisKing;

/**
 * @author venkat
 *
 * use this class to access redis pub sub in application, given publish and
 * subscribe features, it  simply call the common redis's JedisConnection's
 * implementation.
 *  
 */
public class RedisPubSub {
	
	private static RedisPubSub redisPubSub = new RedisPubSub();
	
	private RedisPubSub(){
	
	}
	
	public static RedisPubSub getInstance(){
		
		return redisPubSub;
	}
	
	/**
	 * publishes given message to the given channel.
	 *  
	 * @param channel
	 * @param message
	 * @return
	 */
	public Long publish(String channel, String message){
		
		try {
			return RedisKing.getJedisServer().getJedisConnection().publish(channel, message);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0l;
	}
	
	/**
	 * subscribes to the given channels with given PubSubAction implementation,
	 * any event raised on the given channel, implementation of the given 
	 * PubSubAction will be triggered.
	 *  
	 * @param name 
	 * @param pubSubAction
	 * @param subscribeTimeout
	 * @param channels
	 * @throws Exception 
	 */
	public void subscribe(final String name, final PubSubAction pubSubAction, final int subscribeTimeout, final String... channels) throws Exception{
		
		if(pubSubAction == null)
			throw new RedisException("PubSubAction should not be null, to use Redis Pub Sub!");
		
		if(channels == null || channels.length <= 0)
			throw new RedisException("Atleast one channel required to subscribe!");
		try {
			RedisKing.getJedisServer().getJedisConnection().pubsub(name, pubSubAction, subscribeTimeout, channels);
		} catch (Exception e){
			throw e;
		}
	}
	
	/**
	 * subscribes to the given channels with given PubSubAction implementation,
	 * any event raised on the given channel, implementation of the given 
	 * PubSubAction will be triggered.
	 *  
	 * @param pubSubAction
	 * @param channels
	 * @throws Exception 
	 */
	public void subscribe(final PubSubAction pubSubAction, final String... channels) throws Exception{
		
		if(pubSubAction == null)
			throw new RedisException("PubSubAction should not be null, to use Redis Pub Sub!");
		
		if(channels == null || channels.length <= 0)
			throw new RedisException("Atleast one channel required to subscribe!");
		try {
			RedisKing.getJedisServer().getJedisConnection().pubsub(channels[0], pubSubAction, 300000, channels);
		} catch (Exception e){
			throw e;
		}
	}
	
	/**
	 * subscribes to the given channels with given PubSubAction implementation,
	 * any event raised on the given channel, implementation of the given 
	 * PubSubAction will be triggered.  
	 * 
	 * channel can be a pattern also. 
	 * 
	 * @param logicalDb
	 * @param name
	 * @param pubSubAction
	 * @param subscribeTimeout
	 * @param channels
	 * @throws Exception 
	 */
	public void psubscribe(final int logicalDb, final String name, final PubSubAction pubSubAction, final int subscribeTimeout, final String... channels) throws Exception{
		
		if(pubSubAction == null)
			throw new RedisException("PubSubAction should not be null, to use Redis Pub Sub!");
		
		if(channels == null || channels.length <= 0)
			throw new RedisException("Atleast one channel required to subscribe!");
		try {
			RedisKing.getJedisServer().getJedisConnection().patternPubSub(logicalDb, name, pubSubAction, subscribeTimeout, channels);
		} catch (Exception e){
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * subscribes to the given channels with given PubSubAction implementation,
	 * any event raised on the given channel, implementation of the given 
	 * PubSubAction will be triggered.
	 *  
	 * channel can be a pattern also.
	 *  
	 * @param pubSubAction
	 * @param channels
	 * @throws Exception 
	 */
	public void psubscribe(final int logicDb, final PubSubAction pubSubAction, final String... channels) throws Exception{
		
		if(pubSubAction == null)
			throw new RedisException("PubSubAction should not be null, to use Redis Pub Sub!");
		
		if(channels == null || channels.length <= 0)
			throw new RedisException("Atleast one channel required to subscribe!");
		try {
			RedisKing.getJedisServer().getJedisConnection().patternPubSub(logicDb, channels[0], pubSubAction, 300000, channels);
		} catch (Exception e){
			e.printStackTrace();
			throw e;
		}
	}

}
