/**
 * 
 */
package com.medplus.redis;

/**
 * @author venkat
 *
 */
public class RedisException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3348822581656269236L;

	/**
	 * 
	 */
	public RedisException() {
		super();
	}

	/**
	 * @param message
	 */
	public RedisException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public RedisException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public RedisException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public RedisException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
