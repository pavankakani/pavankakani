package com.medplus.redis.mq;

public class KeyNames {

	static String masterQueueKey() {
		return "redismq::queues";
	}

	static String queueWorkersKey(String queue) {
		return queue + "::workers";
	}

	static String queueInputKey(String queue) {
		return "redismq::" + queue;
	}

	static String queueFailedKey(String queue) {
		return "redismq::" + queue + "::failed";
	}

	static String queueInputRateKey(String queue) {
		return queueInputKey(queue) + "::rate";
	}

	static String queueInputSizeKey(String queue) {
		return queueInputKey(queue) + "::size";
	}

	static String queueFailedSizeKey(String queue) {
		return queueFailedKey(queue) + "::size";
	}

	static String queueHeartbeatKey(String queue) {
		return queueInputKey(queue) + "::buffered::heartbeat";
	}

	static String queueWorkingPrefix(String queue) {
		return "redismq::" + queue + "::working";
	}

	static String consumerWorkingQueueKey(String queue, String consumer) {
		return queueWorkingPrefix(queue) + "::" + consumer;
	}

	static String consumerWorkingRateKey(String queue, String consumer) {
		return consumerWorkingQueueKey(queue, consumer) + "::rate";
	}

	static String consumerHeartbeatKey(String queue, String consumer) {
		return consumerWorkingQueueKey(queue, consumer) + "::heartbeat";
	}

	static String consumerNameKey(String queue, String consumer) {
		return queue + ":" + consumer;
	}
}