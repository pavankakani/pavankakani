package com.medplus.redis.mq;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.gson.Gson;
import com.medplus.redis.RedisKing;

// Observer is a very simple implementation of an statistics observer
// far more complex things could be implemented with the way stats are written
// for now it allows basic access
// to throughput rates and queue size averaged over seconds, minutes and hours
public class Observer {
	
	Map<String, QueueStat> stats;

	// NewObserver returns an Oberserver to monitor different statistics from
	// redis
	public Observer() {
		stats = new HashMap<String, QueueStat>();
	}

	// UpdateAllStats fetches stats for all queues and all their consumers
	public void updateAllStats() {
		Set<String> queues = getAllQueues();
		if (queues != null) {
			for (String queue : queues) {
				updateQueueStats(queue);
			}
		}

	}

	private void updateQueueStats(String queue) {
		QueueStat queueStats = new QueueStat();

		queueStats.inputRateSecond = fetchStat(
				KeyNames.queueInputRateKey(queue), 1);
		queueStats.inputSizeSecond = fetchStat(
				KeyNames.queueInputSizeKey(queue), 1);
		queueStats.failSizeSecond = fetchStat(
				KeyNames.queueFailedSizeKey(queue), 1);

		queueStats.inputRateMinute = fetchStat(
				KeyNames.queueInputRateKey(queue), 60);
		queueStats.inputSizeMinute = fetchStat(
				KeyNames.queueInputSizeKey(queue), 60);
		queueStats.failSizeMinute = fetchStat(
				KeyNames.queueFailedSizeKey(queue), 60);

		queueStats.inputRateHour = fetchStat(KeyNames.queueInputRateKey(queue),
				3600);
		queueStats.inputSizeHour = fetchStat(KeyNames.queueInputSizeKey(queue),
				3600);
		queueStats.failSizeHour = fetchStat(KeyNames.queueFailedSizeKey(queue),
				3600);

		queueStats.workRateSecond = 0;
		queueStats.workRateMinute = 0;
		queueStats.workRateHour = 0;
		queueStats.failedLen=fetchFailedQueueLen(queue);
		queueStats.queueLen=fetchQueueLen(queue);
		Set<String> consumers = getConsumers(queue);
		if (consumers == null) {
			return;
		}

		for (String consumer : consumers) {
			ConsumerStat stat = new ConsumerStat();
			stat.workRateSecond = fetchStat(
					KeyNames.consumerWorkingRateKey(queue, consumer), 1);
			stat.workRateMinute = fetchStat(
					KeyNames.consumerWorkingRateKey(queue, consumer), 60);
			stat.workRateHour = fetchStat(
					KeyNames.consumerWorkingRateKey(queue, consumer), 3600);
			stat.unAckedLen=fetchUnacked(queue,consumer);
			queueStats.workRateSecond += stat.workRateSecond;
			queueStats.workRateMinute += stat.workRateMinute;
			queueStats.workRateHour += stat.workRateHour;
			queueStats.unAckedLen+=stat.unAckedLen;

			queueStats.setConsumerStat(stat, consumer);
		}

		stats.put(queue, queueStats);

	}

	private long fetchQueueLen(String queue) {
		return RedisKing.getMQJedisServerConnection().llen(
				KeyNames.queueInputKey(queue));
	}

	private long fetchUnacked(String queue, String consumer) {
		// TODO Auto-generated method stub
		return RedisKing.getMQJedisServerConnection().llen(
				KeyNames.consumerWorkingQueueKey(queue, consumer));
	}
	
	private long fetchFailedQueueLen(String queue) {
		// TODO Auto-generated method stub
		return RedisKing.getMQJedisServerConnection().llen(
				KeyNames.queueFailedKey(queue));
	}


	private long fetchStat(String keyName, long seconds) {
		// TODO the current implementation does not handle gaps for queue size
		// which appear for queues with little or no traffic

		long now = (System.currentTimeMillis() / 1000) - 2;
		// we can only look for already written stats
		List<String> keys = new ArrayList<String>();
		// keys := make([]string, 0)

		for (int i = 0; i < seconds; i++) {
			String key = keyName + "::" + now; // := fmt.Sprintf("%s::%d",
												// keyName, now);
			keys.add(key);
			// keys = append(keys, key)
			now--;
		}
		String[] array = new String[keys.size()];
		keys.toArray(array);
		List<String> answer = RedisKing.getMQJedisServerConnection()
				.mget(array);

		if (answer == null) {
			return 0;
		}
		// nilVal := 0
		long sum = 0;
		for (String val : answer) {// _, val := range answer.Val() {
			if (val == null) {
				// nilVal++
				continue;
			}
			long num = Long.parseLong(val);
			// num, _ := strconv.ParseInt(val.(string), 10, 64)
			sum += num;
		}
		return sum;
	}

	// GetAllQueues returns a list of all registed queues
	public Set<String> getAllQueues() {
		return RedisKing.getMQJedisServerConnection()
				.smembers(KeyNames.masterQueueKey());
	}

	public Set<String> getConsumers(String queue) {
		return RedisKing.getMQJedisServerConnection()
				.smembers(KeyNames.queueWorkersKey(queue));
	}

	// ToJSON renders the whole observer as a JSON string
	public String toJSON() {
		
		Gson gson = new Gson();
		String json = gson.toJson(this);  
		// json, err := json.Marshal(observer)
		// if err != nil {
		// log.Fatalf("ERROR MARSHALLING OVERSEER %s", err.Error())
		// }
		// return string(json)
		return json;
	}

}

// QueueStat collects data about a queue
class QueueStat {
	long inputSizeSecond;
	long inputSizeMinute;
	long inputSizeHour;

	long failSizeSecond;
	long failSizeMinute;
	long failSizeHour;

	long inputRateSecond;
	long inputRateMinute;
	long inputRateHour;

	long workRateSecond;
	long workRateMinute;
	long workRateHour;
	long unAckedLen;
	long failedLen;
	long queueLen;

	public QueueStat() {
		consumerStats = new HashMap<String, ConsumerStat>();
	}

	Map<String, ConsumerStat> consumerStats;

	public Map<String, ConsumerStat> getConsumerStats() {
		return consumerStats;
	}

	public void setConsumerStat(ConsumerStat consumerStat, String customer) {
		consumerStats.put(customer, consumerStat);
	}
}

// ConsumerStat collects data about a queues consumer
class ConsumerStat {
	long workRateSecond;
	long workRateMinute;
	long workRateHour;
	long unAckedLen;
}
