/**
 * 
 */
package com.medplus.redis.pub.sub;

/**
 * SubClasses of this class is used in Redis Pub Sub framework, PubSub events
 * trigger this class implementation.
 * 
 * @author venkat
 *
 */
public abstract class PubSubAction {

	public void onMessage(String channel, String message) {
		
	}

	public void onPMessage(String pattern, String channel, String message) {

	}

	public void onSubscribe(String channel, int subscribedChannels) {

	}

	public void onUnsubscribe(String channel, int subscribedChannels) {
	
	}

	public void onPUnsubscribe(String pattern, int subscribedChannels) {
		
	}

	public void onPSubscribe(String pattern, int subscribedChannels) {
		
	}
}
