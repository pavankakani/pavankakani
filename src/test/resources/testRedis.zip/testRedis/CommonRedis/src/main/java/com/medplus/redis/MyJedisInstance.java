package com.medplus.redis;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.Protocol;
import redis.clients.util.Pool;

public class MyJedisInstance {
	
	static Logger logger = LoggerFactory.getLogger(MyJedisInstance.class);

	protected Collection<RedisConfig> redisConfigs = new ArrayList<RedisConfig>();
	
	public MyJedisInstance(Collection<RedisConfig> redisConfigs){
		this.redisConfigs = redisConfigs;
	}
	
	protected static Map<Integer, RedisPool> redisPoolMap = new HashMap<Integer, RedisPool>();

	private Pool<Jedis> defaultPool;

	public Pool<Jedis> getPool() {
		return defaultPool;
	}
	

	@Deprecated
	private  Map<Integer,Pool<Jedis>> poolMap= new HashMap<Integer,Pool<Jedis>>();

    public Pool<Jedis> getPool(int dataBase)
    {
    	return poolMap.get(dataBase);
    }
	
	
	public int getMaxIdleTime() {
		return maxIdleTime;
	}

	public void setMaxIdleTime(int maxIdleTime) {
		this.maxIdleTime = maxIdleTime;
	}

	public int getMaxActiveTime() {
		return maxActiveTime;
	}

	public void setMaxActiveTime(int maxActiveTime) {
		this.maxActiveTime = maxActiveTime;
	}

	public int getMaxTimeOut() {
		return maxTimeOut;
	}

	public void setMaxTimeOut(int maxTimeOut) {
		this.maxTimeOut = maxTimeOut;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	private int maxIdleTime = 200;
	private int maxActiveTime = 200;
	private int maxTimeOut = 10000;
	private String ipAddress = "localhost";
	private int port = 6379;

	//private Object lock = new Object();

	@Deprecated
	public MyJedisInstance(String ipAddress, int port, int maxIdleTime,
			int maxActiveTime, int maxTimeOut) {
		this.maxIdleTime = maxIdleTime;
		this.maxActiveTime = maxActiveTime;
		this.maxTimeOut = maxTimeOut;
		this.ipAddress = ipAddress;
		this.port = port;
	}

	@Deprecated
	public MyJedisInstance(String ipAddress, int port) {
		this.ipAddress = ipAddress;
		this.port = port;
	}

	public JedisConnection getJedisConnection() {
		return getJedisConnection(0, Protocol.DEFAULT_DATABASE, false);
	}

	public JedisConnection getJedisConnection(int dataBase) {
		return getJedisConnection(0,dataBase, false);
	}

	protected JedisConnection getJedisConnection(int retrycount, int dataBase, boolean isRead) {
		
		RedisPool redisPool = redisPoolMap.get(dataBase);
		
		if(redisPool == null || !redisPool.isPoolInitilized(isRead))
			redisPool = instantiatePool(dataBase, isRead);
		if(redisPool == null){
			throw new RedisException("RedisPool Not Created!");
		}
		Pool<Jedis> jedisPool = isRead ? redisPool.getReadPool() : redisPool.getMasterPool();
		
		return new JedisConnection(jedisPool);
	}
	
	private synchronized RedisPool instantiatePool(int logicNum, boolean isRead) {
		logger.info("logicNum : {}, isRead : {}", logicNum, isRead);
		RedisConfig redisConfig = null;
		for (RedisConfig redisConf : redisConfigs) {
			if(redisConf.isValidConfig(logicNum)){
				redisConfig = redisConf;
				break;
			}
		}
		if(redisConfig == null){
			logger.info("Configuration Not Found for Logical Number : {}", logicNum);
			throw new RedisException("Configuration Not Found for Logical Number : "+logicNum);
		}
		
		if(!isRead && redisConfig.getMaster() == null){
			logger.info("Master Not Found");
			throw new RedisException("Master Not Found");
		}
		
		RedisPool redisPool = redisPoolMap.get(logicNum);
		if(redisPool == null)
			redisPool = new RedisPool();
		
		redisPool.initializePool(redisConfig, logicNum, isRead);
		redisPoolMap.put(logicNum, redisPool);
		
		return redisPool;
	}
	

	public synchronized void cleanup(RedisConfig redisConfig) {
		Map<Integer, Integer> databases = redisConfig.getDatabaseMap();
		if(databases == null)
			return;
				
		for (Map.Entry<Integer, Integer> entry : databases.entrySet()) {
			RedisPool redisPool = redisPoolMap.remove(entry.getKey());
			if(redisPool != null)
				redisPool.destroy();
		}
	}


	@Deprecated
	private synchronized void instantiatePool(int dataBase) {
		
		JedisPoolConfig config = new JedisPoolConfig();
		config.setMaxIdle(200);
		JedisPool pool = new JedisPool(config, ipAddress, port, 10000000,null,dataBase);
		poolMap.put(dataBase, pool);
		
	}
	
	@Deprecated
	private synchronized void instantiatePool() {
		if (defaultPool == null) {
			JedisPoolConfig config = new JedisPoolConfig();
			config.setMaxIdle(200);
			defaultPool = new JedisPool(config, ipAddress, port, 10000000);
		}
	}

	// private Jedis getJedisInstance() {
	// JedisPoolConfig config = new JedisPoolConfig();
	// config.setMaxActive(maxActiveTime);
	// config.setMaxIdle(maxIdleTime);
	// Pool<Jedis> pool = new JedisPool(config, ipAddress, port, maxTimeOut);
	// // jedis = new Jedis("localhost");
	// pool.getResource().connect();
	// // jedis.connect();
	// Jedis jedis = pool.getResource();
	// return jedis;
	//
	// }

	@Override
	public int hashCode() {
		int hash = 40;
		hash += ipAddress.hashCode() * 11;
		hash += port * 101;
		hash += maxActiveTime * 9;
		hash += maxIdleTime * 6;
		hash += maxTimeOut * 5;
		return hash;

	}

	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MyJedisInstance other = (MyJedisInstance) obj;
		if (ipAddress == null) {
			if (other.ipAddress != null)
				return false;
		} else if (!ipAddress.equals(other.ipAddress))
			return false;
		if (port != other.port)
			return false;
		return true;
	}


	public boolean equals(MyJedisInstance anotherjedis) {

		if ((anotherjedis != null)
				&& (anotherjedis.getIpAddress().equalsIgnoreCase(ipAddress))
				&& anotherjedis.getPort() == port) {
			return true;
		}

		return false;
	}

	
	
	
	public String toString() {
		return "MYJEDIS:ipAddress:" + ipAddress + " port:" + port
				+ " maxActiveTime:" + maxActiveTime + " maxTimeOut:"
				+ maxTimeOut + " maxIdleTime:" + maxIdleTime;
	}

	public void release() {

	}

	@Deprecated
	public void cleanup() {
		if(defaultPool != null)
			defaultPool.destroy();
		defaultPool=null;
		if (poolMap != null && poolMap.values() != null) {
			for (Pool<Jedis> pool : poolMap.values()) {
				pool.destroy();
			}
		}
		poolMap=null;
	}

}
