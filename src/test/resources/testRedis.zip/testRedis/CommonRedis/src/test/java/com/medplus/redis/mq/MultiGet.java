package com.medplus.redis.mq;

import java.util.List;

public class MultiGet {

	public static void main(String args[]) throws Exception {

		write("example");
		write("example");
		write("example");
		write("example");
		
		read("example", "1");
		read("example", "2");

		new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					Observer o = new Observer();
					o.updateAllStats();
					System.out.println(o.toJSON());
			//		System.out.println(" No of gets "+Consumer.noofgets);
				//	System.out.println(" No of puts "+Queue.noofputs);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}).start();
		// select {}
	}

	private static String randomString(int l) {
		byte bytes[] = new byte[l];
		for (int i = 0; i < l; i++) {
			bytes[i] = (byte) randbyte(65, 90);
		}
		return new String(bytes);
	}

	private static int randbyte(int i, int j) {
		return (int) (i + Math.random() * (j - i));
	}

	public static void write(final String queue) {
		new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					Queue testQueue = Queue.CreateQueue(queue);
					String payload = randomString(1024 * 1); // adjust for size
					testQueue.put(payload);
					try {
						Thread.sleep(1);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}).start();

	}

	public static void read(final String queue, final String prefix)
			throws Exception {
		new Thread(new Runnable() {

			@Override
			public void run() {
				Queue testQueue = Queue.CreateQueue(queue);

				Consumer consumer = testQueue.addConsumer("testconsumer"
						+ prefix);

				long j = consumer.getUnackedLength();
				while (j > 0) {

					Packet p = consumer.getUnacked();
					System.out.println(p.getString());
					p.ack();
					j--;
				}
				while (true) {
				
					
					// try {
					// Thread.sleep(100000000);
					// } catch (InterruptedException e) {
					// // TODO Auto-generated catch block
					// e.printStackTrace();
					// }
					// // consumer.resetWorking();

					List<Packet> packets = consumer.multiGet(200);
					// Packet packet = consumer.get();
					// i++;
					// System.out.println("Processing  this Packet "
					// + packet.getString());
					// System.out.println("Processing " + i);
					// packet.ack();

					packets.get(packets.size() - 1).multiAck();
					try {
						Thread.sleep(1);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}).start();

	}
}
