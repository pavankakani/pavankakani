package com.medplus.redis;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import org.junit.Ignore;
import org.junit.Test;

import redis.clients.jedis.DebugParams;
import redis.clients.jedis.exceptions.JedisException;
/**
 * 
 * @author venkat
 * 
 * to run tests in this class, you need to set up the redis sentinel in your local
 * with one server and 4-6 slaves, and at least  sentinels,
 * 
 * to set up sentinel use redis vesrion latest by 3.x
 * use jedis latest by 3.x
 * 
 * for better understand refer below url or redis-sentinel-set-up-example.pdf in the context
 *  
 * https://seanmcgary.com/posts/how-to-build-a-fault-tolerant-redis-cluster-with-sentinel 
 * 
 */

@Ignore
public class RedisKingTest {
	
	static Map<String, String> redisConfigMap = new HashMap<String, String>();
	static String localhost = "127.0.0.1";
	static int port = 16380;
	
	
	
	@Test(expected = RedisException.class)
	public void testInitRedisKingWhenNoConfigurationTest(){
		
		RedisKing redisKing = new RedisKing(null);
		redisKing.initRedisKing();
	
		RedisKing.getJedisServer().getJedisConnection();
		
	}
	
	
	@Test(expected = JedisException.class)
	public void testInitRedisKingWhenSentinelsNotConnected(){
		Map<String, String> redisConfigMap = new HashMap<String, String>();
		
		redisConfigMap.put("com.medplus.redis.sentinel.master.name", "redis-cluster");
		redisConfigMap.put("com.medplus.redis.sentinel.1.ip", localhost);
		
		RedisKing redisKing = new RedisKing(redisConfigMap);
		redisKing.initRedisKing();
	
		assertNull(RedisKing.getJedisServer());
		assertNull(RedisKing.getJedisServerReadOnly());
		
	}
	
	//@Test
	@Deprecated
	public void testGetJedisServerReadOnly(){
		
		Map<String, String> redisConfigMap = getRedisConfigMap();
		
		RedisKing redisKing = new RedisKing(redisConfigMap);
		redisKing.initRedisKing();
		
		MyJedisInstance read1 = RedisKing.getJedisServerReadOnly();
		MyJedisInstance read2 = RedisKing.getJedisServerReadOnly();
		
		for (int i = 0; i < 100; i++) {
			assertNotEquals(read1, read2);
			read1 = RedisKing.getJedisServerReadOnly();
			read2 = RedisKing.getJedisServerReadOnly();
		}
		
		assertNotEquals(read1, read2);
	}
	
	//@Test
	@Deprecated
	public void testInitRedisKingWhenMasterAndSlaveDown(){
		Map<String, String> redisConfigMap = getRedisConfigMap();
		
		RedisKing redisKing = new RedisKing(redisConfigMap);
		redisKing.initRedisKing();
	
		MyJedisInstance masterJedis = RedisKing.getJedisServer();
		assertNotNull(masterJedis);
		
		MyJedisInstance slaveJedis = null;
		for (int i = 0; i < 4; i++) {
			slaveJedis = RedisKing.getJedisServerReadOnly();
			if(!masterJedis.equals(slaveJedis))
				break;
		}
		assertNotNull(slaveJedis);
		
				
		final AtomicBoolean run = new AtomicBoolean();
		run.set(true);
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (run.get()) {
					assertNotNull(RedisKing.getJedisServer());
					assertNotNull(RedisKing.getJedisServerReadOnly());
				}
			}
		}).start();
		
		try {
			masterJedis.getJedisConnection().debug(DebugParams.SEGFAULT());
		} catch (Exception e1) {
		}
		
		try {
			slaveJedis.getJedisConnection().debug(DebugParams.SEGFAULT());
		} catch (Exception e1) {
		}
		
		try {
			Thread.sleep(30000);
			run.set(false);
		} catch (InterruptedException e) {
		}
		
		MyJedisInstance masterjedisafter = RedisKing.getJedisServer();
		assertNotNull(masterjedisafter);
		MyJedisInstance slavejedisafter = RedisKing.getJedisServer();
		assertNotNull(slavejedisafter);
		
		assertNotEquals(masterJedis, masterjedisafter);
		assertNotEquals(slaveJedis, slavejedisafter);
	}


	private Map<String, String> getRedisConfigMap() {
		Map<String, String> redisConfigMap = new HashMap<String, String>();
		
		redisConfigMap.put("com.medplus.redis.sentinel.master.name", "redis-cluster");
		redisConfigMap.put("com.medplus.redis.sentinel.1.ip", localhost);
		redisConfigMap.put("com.medplus.redis.sentinel.1.port", String.valueOf(port));
		redisConfigMap.put("com.medplus.redis.sentinel.2.ip", localhost);
		redisConfigMap.put("com.medplus.redis.sentinel.2.port", String.valueOf(port+1));
		redisConfigMap.put("com.medplus.redis.sentinel.3.ip", localhost);
		redisConfigMap.put("com.medplus.redis.sentinel.3.port", String.valueOf(port+2));
		
		return redisConfigMap;
	}
	
	//@Test
	@Deprecated
	public void testInitRedisKingWhenSlaveDown(){
		Map<String, String> redisConfigMap = getRedisConfigMap();
		
		RedisKing redisKing = new RedisKing(redisConfigMap);
		redisKing.initRedisKing();
		MyJedisInstance readJedis = null;
		MyJedisInstance masterJedis = RedisKing.getJedisServer();
		assertNotNull(masterJedis);
		
		for (int i = 0; i < 4; i++) {
			readJedis = RedisKing.getJedisServerReadOnly();
			if(!masterJedis.equals(readJedis))
				break;
		}
				
		final AtomicBoolean run = new AtomicBoolean();
		run.set(true);
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (run.get()) {
					assertNotNull(RedisKing.getJedisServer());
					assertNotNull(RedisKing.getJedisServerReadOnly());
				}
			}
		}).start();
		try {
			readJedis.getJedisConnection().debug(DebugParams.SEGFAULT());
		} catch (Exception e1) {
		}
				
		try {
			Thread.sleep(30000);
			run.set(false);
		} catch (InterruptedException e) {
		}
		
		for (int i = 0; i < 10; i++) {
			assertNotEquals(readJedis, RedisKing.getJedisServerReadOnly());
		}
		assertEquals(masterJedis, RedisKing.getJedisServer());
		
	}
	
	//@Test
	@Deprecated
	public void testInitRedisKingWhenMasterDown(){
		Map<String, String> redisConfigMap = getRedisConfigMap();
		
		RedisKing redisKing = new RedisKing(redisConfigMap);
		redisKing.initRedisKing();
	
		MyJedisInstance masterJedis = RedisKing.getJedisServer();
		assertNotNull(masterJedis);
		
				
		final AtomicBoolean run = new AtomicBoolean();
		run.set(true);
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (run.get()) {
					assertNotNull(RedisKing.getJedisServer());
					assertNotNull(RedisKing.getJedisServerReadOnly());
				}
			
			}
		}).start();
		try {
			RedisKing.getJedisServer().getJedisConnection().debug(DebugParams.SEGFAULT());
		} catch (Exception e1) {
		}
		
		try {
			Thread.sleep(30000);
			run.set(false);
		} catch (InterruptedException e) {
		}
		
		MyJedisInstance masterjedisafter = RedisKing.getJedisServer();
		assertNotNull(masterjedisafter);
		assertNotNull(RedisKing.getJedisServerReadOnly());
		
		assertNotEquals(masterJedis, masterjedisafter);
		
	}
	
	@Deprecated
	public static void mainForSingleRedisSentinel(String[] args) {
		Map<String, String> redisConfig = new HashMap<String, String>();
		redisConfig.put("com.medplus.redis.sentinel.master.name", "redis-cluster");
		redisConfig.put("com.medplus.redis.sentinel.1.ip", "192.168.1.33");
		redisConfig.put("com.medplus.redis.sentinel.1.port", "14380");
		redisConfig.put("com.medplus.redis.sentinel.2.ip", "192.168.1.33");
		redisConfig.put("com.medplus.redis.sentinel.2.port", "14381");
		redisConfig.put("com.medplus.redis.sentinel.3.ip", "192.168.1.33");
		redisConfig.put("com.medplus.redis.sentinel.3.port", "14382");
		RedisKing redisKing = new RedisKing(redisConfig);
		redisKing.initRedisKing();
		
		MyJedisInstance jedisInstance = RedisKing.getJedisServer();
		System.out.println("master : "+jedisInstance);
		
		jedisInstance.getJedisConnection().set("test0", "test0");
		
		MyJedisInstance readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 1 "+readjedisInstance);
		System.out.println("read 1 "+readjedisInstance.getJedisConnection().get("test0"));
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 2 "+readjedisInstance);
		System.out.println("read 2 "+readjedisInstance.getJedisConnection().get("test0"));
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 3 "+readjedisInstance);
		System.out.println("read 3 "+readjedisInstance.getJedisConnection().get("test0"));
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 4 "+readjedisInstance);
		System.out.println("read 4 "+readjedisInstance.getJedisConnection().get("test0"));
		
		System.out.println("Please down the master");
		try {
			Thread.sleep(40000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("==============================master done=================================================");
		jedisInstance = RedisKing.getJedisServer();
		System.out.println("master : "+jedisInstance);
		
		jedisInstance.getJedisConnection().set("test1", "test1");
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 1 "+readjedisInstance);
		System.out.println("read 1 "+readjedisInstance.getJedisConnection().get("test0"));
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 2 " + readjedisInstance);
		System.out.println("read 2 "+readjedisInstance.getJedisConnection().get("test0"));
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 3 "+readjedisInstance);
		System.out.println("read 3 "+readjedisInstance.getJedisConnection().get("test0"));
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 4 "+readjedisInstance);
		System.out.println("read 4 "+readjedisInstance.getJedisConnection().get("test0"));
		
		System.out.println("Please up the slave");
		try {
			Thread.sleep(60000);
		} catch (InterruptedException e) {
			//e.printStackTrace();
		}
		System.out.println("===================================running slave got add============================================");
		jedisInstance = RedisKing.getJedisServer();
		System.out.println(jedisInstance);
		
		
		jedisInstance.getJedisConnection().set("test2", "test2");
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 1 "+readjedisInstance);
		System.out.println("read 1 "+readjedisInstance.getJedisConnection().get("test0"));
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 2 " + readjedisInstance);
		System.out.println("read 2 "+readjedisInstance.getJedisConnection().get("test0"));
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 3 "+readjedisInstance);
		System.out.println("read 3 "+readjedisInstance.getJedisConnection().get("test0"));
		
		readjedisInstance = RedisKing.getJedisServerReadOnly();
		System.out.println("read 4 "+readjedisInstance);
		System.out.println("read 4 "+readjedisInstance.getJedisConnection().get("test0"));
		
	}
	

	
	public static void mainForPipelined(String[] args) {
		
		Map<String, String> redisConfig = new HashMap<String, String>();
		redisConfig.put("com.medplus.redis.sentinel.master.name", "redis-cluster");
		/*redisConfig.put("com.medplus.redis.sentinel.1.ip", "192.168.1.33");
		redisConfig.put("com.medplus.redis.sentinel.1.port", "14380");
		redisConfig.put("com.medplus.redis.sentinel.2.ip", "192.168.1.33");
		redisConfig.put("com.medplus.redis.sentinel.2.port", "14381");
		redisConfig.put("com.medplus.redis.sentinel.3.ip", "192.168.1.33");
		redisConfig.put("com.medplus.redis.sentinel.3.port", "14382");*/
		redisConfig.put("com.medplus.redis.sentinel.1.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.1.port", "16380");
		redisConfig.put("com.medplus.redis.sentinel.2.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.2.port", "16381");
		redisConfig.put("com.medplus.redis.sentinel.3.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.3.port", "16382");
		
		
		redisConfig.put("com.medplus.redis.logical.0.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.0.database", "0");
		
		redisConfig.put("com.medplus.redis.logical.1.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.1.database", "1");
		
		redisConfig.put("com.medplus.redis.logical.2.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.2.database", "2");
		
		redisConfig.put("com.medplus.redis.logical.3.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.3.database", "3");
		
		redisConfig.put("com.medplus.redis.logical.10.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.10.database", "10");
		
		RedisKing redisKing = new RedisKing(redisConfig);
		redisKing.initRedisKing();
		
		JedisConnection jedisConnection = RedisKing.getJedisServer().getJedisConnection(10);
		jedisConnection.set("venkat", "venkat");
		
		List<Object> res = jedisConnection.pipelined(new PipelineBlock() {
			
			@Override
			public void execute() {
				set("test1", "test1");
				set("test2", "test1");
				set("test3", "test1");
				set("test4", "test1");
				set("test5", "test1");
				
			}
		});
		
		System.out.println(res);
		
		Set<String> s = RedisKing.getJedisServer().getJedisConnection(10).keys("*");
		System.out.println(s);
		/*String s = RedisKing.getJedisServer().getJedisConnection(1).set("logic1", "logic1");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(0).set("logic0", "logic0");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(2).set("logic2", "logic2");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(3).set("logic3", "logic3");
		System.out.println("s : "+s);
		final AtomicBoolean run = new AtomicBoolean(true);
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				while(run.get()){
					
					try{
						String s = RedisKing.getJedisServer().getJedisConnection(1).set("logic1", "logic1");
						//System.out.println("s : "+s);
						s = RedisKing.getJedisServerReadOnly().getJedisConnection(1).get("logic1");
						//System.out.println("s : "+s);
						
						s = RedisKing.getJedisServer().getJedisConnection(0).set("logic0", "logic0");
						//System.out.println("s : "+s);
						s = RedisKing.getJedisServerReadOnly().getJedisConnection(0).get("logic0");
						//System.out.println("s : "+s);
						
						s = RedisKing.getJedisServer().getJedisConnection(2).set("logic2", "logic2");
						//System.out.println("s : "+s);
						s = RedisKing.getJedisServerReadOnly().getJedisConnection(2).get("logic2");
						//System.out.println("s : "+s);
						
						s = RedisKing.getJedisServer().getJedisConnection(3).set("logic3", "logic3");
						//System.out.println("s : "+s);
						s = RedisKing.getJedisServerReadOnly().getJedisConnection(3).get("logic3");
						//System.out.println("s : "+s);
						
					}catch(Exception e){
						System.out.print("e,");
						//e.printStackTrace();
					}
				}
				
			}
		}).start();
		
		try{
			Thread.sleep(240000);
		} catch (InterruptedException e){
			
		}
		s = RedisKing.getJedisServer().getJedisConnection(1).get("logic1");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(0).get("logic0");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(2).get("logic2");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(3).get("logic3");
		System.out.println("s : "+s);
		System.out.println("===============================================");
		for (int i = 0; i < 3; i++) {
			s = RedisKing.getJedisServerReadOnly().getJedisConnection(1).get("logic1");
			System.out.println("s : "+s);
			
			s = RedisKing.getJedisServerReadOnly().getJedisConnection(0).get("logic0");
			System.out.println("s : "+s);
			
			s = RedisKing.getJedisServerReadOnly().getJedisConnection(2).get("logic2");
			System.out.println("s : "+s);
			
			s = RedisKing.getJedisServerReadOnly().getJedisConnection(3).get("logic3");
			System.out.println("s : "+s);
		}
		
		run.set(false);*/
		
	}
	
	public static void main(String[] args) {
		Map<String, String> redisConfig = new HashMap<String, String>();
		redisConfig.put("com.medplus.redis.sentinel.master.name", "redis-cluster");
		redisConfig.put("com.medplus.redis.sentinel.1.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.1.port", "16380");
		redisConfig.put("com.medplus.redis.sentinel.2.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.2.port", "16381");
		redisConfig.put("com.medplus.redis.sentinel.3.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.3.port", "16382");
		
		
		redisConfig.put("com.medplus.redis.logical.0.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.0.database", "0");
		
		redisConfig.put("com.medplus.redis.logical.1.master", "redis-cluster_1");
		redisConfig.put("com.medplus.redis.logical.1.database", "1");
		
		redisConfig.put("com.medplus.redis.logical.2.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.2.database", "2");
		
		redisConfig.put("com.medplus.redis.logical.3.master", "redis-cluster_1");
		redisConfig.put("com.medplus.redis.logical.3.database", "3");
		
		RedisKing redisKing = new RedisKing(redisConfig);
		redisKing.initRedisKing();
		
		try {
			Thread.sleep(300000l);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	public static void mainForMultipleRedisInstances(String[] args) {
		
		Map<String, String> redisConfig = new HashMap<String, String>();
		redisConfig.put("com.medplus.redis.sentinel.master.name", "redis-cluster");
		redisConfig.put("com.medplus.redis.sentinel.1.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.1.port", "16380");
		redisConfig.put("com.medplus.redis.sentinel.2.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.2.port", "16381");
		redisConfig.put("com.medplus.redis.sentinel.3.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.3.port", "16382");
		
		
		redisConfig.put("com.medplus.redis.logical.0.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.0.database", "0");
		
		redisConfig.put("com.medplus.redis.logical.1.master", "redis-cluster_1");
		redisConfig.put("com.medplus.redis.logical.1.database", "1");
		
		redisConfig.put("com.medplus.redis.logical.2.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.2.database", "2");
		
		redisConfig.put("com.medplus.redis.logical.3.master", "redis-cluster_1");
		redisConfig.put("com.medplus.redis.logical.3.database", "3");
		
		RedisKing redisKing = new RedisKing(redisConfig);
		redisKing.initRedisKing();
		
		String s = RedisKing.getJedisServer().getJedisConnection(1).set("logic1", "logic1");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(0).set("logic0", "logic0");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(2).set("logic2", "logic2");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(3).set("logic3", "logic3");
		System.out.println("s : "+s);
		final AtomicBoolean run = new AtomicBoolean(true);
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				while(run.get()){
					
					try{
						String s = RedisKing.getJedisServer().getJedisConnection(1).set("logic1", "logic1");
						//System.out.println("s : "+s);
						s = RedisKing.getJedisServerReadOnly().getJedisConnection(1).get("logic1");
						//System.out.println("s : "+s);
						
						s = RedisKing.getJedisServer().getJedisConnection(0).set("logic0", "logic0");
						//System.out.println("s : "+s);
						s = RedisKing.getJedisServerReadOnly().getJedisConnection(0).get("logic0");
						//System.out.println("s : "+s);
						
						s = RedisKing.getJedisServer().getJedisConnection(2).set("logic2", "logic2");
						//System.out.println("s : "+s);
						s = RedisKing.getJedisServerReadOnly().getJedisConnection(2).get("logic2");
						//System.out.println("s : "+s);
						
						s = RedisKing.getJedisServer().getJedisConnection(3).set("logic3", "logic3");
						//System.out.println("s : "+s);
						s = RedisKing.getJedisServerReadOnly().getJedisConnection(3).get("logic3");
						//System.out.println("s : "+s);
						
					}catch(Exception e){
						System.out.print("e,");
						//e.printStackTrace();
					}
				}
				
			}
		}).start();
		
		try{
			Thread.sleep(240000);
		} catch (InterruptedException e){
			
		}
		s = RedisKing.getJedisServer().getJedisConnection(1).get("logic1");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(0).get("logic0");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(2).get("logic2");
		System.out.println("s : "+s);
		
		s = RedisKing.getJedisServer().getJedisConnection(3).get("logic3");
		System.out.println("s : "+s);
		System.out.println("===============================================");
		for (int i = 0; i < 3; i++) {
			s = RedisKing.getJedisServerReadOnly().getJedisConnection(1).get("logic1");
			System.out.println("s : "+s);
			
			s = RedisKing.getJedisServerReadOnly().getJedisConnection(0).get("logic0");
			System.out.println("s : "+s);
			
			s = RedisKing.getJedisServerReadOnly().getJedisConnection(2).get("logic2");
			System.out.println("s : "+s);
			
			s = RedisKing.getJedisServerReadOnly().getJedisConnection(3).get("logic3");
			System.out.println("s : "+s);
		}
		
		run.set(false);
		
	}
}
