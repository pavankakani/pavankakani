/**
 * 
 */
package com.medplus.redis;


import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import redis.clients.jedis.BinaryClient.LIST_POSITION;
import redis.clients.jedis.BitOP;
import redis.clients.jedis.BitPosParams;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.ScanParams;
import redis.clients.jedis.ScanResult;
import redis.clients.jedis.SortingParams;
import redis.clients.jedis.Tuple;
import redis.clients.jedis.ZParams;
import redis.clients.jedis.ZParams.Aggregate;
import redis.clients.jedis.exceptions.JedisDataException;
import redis.clients.jedis.params.set.SetParams;
import redis.clients.jedis.params.sortedset.ZAddParams;
import redis.clients.jedis.params.sortedset.ZIncrByParams;
import redis.clients.util.Slowlog;

import com.medplus.redis.pub.sub.PubSubAction;
import com.medplus.redis.pub.sub.RedisPubSub;

/**
 * @author saipavanm
 *
 */
@Ignore
public class JedisConnectionTest {

	static JedisConnection jedisConnection;

	@BeforeClass
	public static  void initJedisConnection(){
		Map<String, String> redisConfig = new HashMap<String, String>();
		redisConfig.put("com.medplus.redis.sentinel.master.name", "redis-cluster");
		redisConfig.put("com.medplus.redis.sentinel.1.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.1.port", "26379");
		redisConfig.put("com.medplus.redis.sentinel.2.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.2.port", "26380");
		redisConfig.put("com.medplus.redis.sentinel.3.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.3.port", "26381");
		redisConfig.put("com.medplus.redis.logical.0.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.0.database", "0");
		redisConfig.put("com.medplus.redis.logical.1.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.1.database",	"1");
		redisConfig.put("com.medplus.redis.logical.2.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.2.database", "2");
		redisConfig.put("com.medplus.redis.logical.3.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.3.database", "3");
		redisConfig.put("com.medplus.redis.logical.4.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.4.database", "4");
		redisConfig.put("com.medplus.redis.logical.5.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.5.database", "5");
		redisConfig.put("com.medplus.redis.logical.6.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.6.database", "6");
		redisConfig.put("com.medplus.redis.logical.7.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.7.database", "7");
		redisConfig.put("com.medplus.redis.logical.8.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.8.database", "8");
		RedisKing redisKing = new RedisKing(redisConfig);
		redisKing.initRedisKing();
		jedisConnection = RedisKing.getJedisServer().getJedisConnection();
		jedisConnection.flushAll();
	}

	public static void main(String[] args) throws Exception {
		Map<String, String> redisConfig = new HashMap<String, String>();
		redisConfig.put("com.medplus.redis.sentinel.master.name", "redis-cluster");
		redisConfig.put("com.medplus.redis.sentinel.1.ip", "192.168.1.67");
		redisConfig.put("com.medplus.redis.sentinel.1.port", "26379");
		redisConfig.put("com.medplus.redis.sentinel.2.ip", "192.168.1.80");
		redisConfig.put("com.medplus.redis.sentinel.2.port", "26379");
		redisConfig.put("com.medplus.redis.sentinel.3.ip", "192.168.1.81");
		redisConfig.put("com.medplus.redis.sentinel.3.port", "26379");
		redisConfig.put("com.medplus.redis.logical.0.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.0.database", "0");
		redisConfig.put("com.medplus.redis.logical.1.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.1.database",	"1");
		redisConfig.put("com.medplus.redis.logical.2.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.2.database", "2");
		redisConfig.put("com.medplus.redis.logical.3.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.3.database", "3");
		redisConfig.put("com.medplus.redis.logical.4.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.4.database", "4");
		redisConfig.put("com.medplus.redis.logical.5.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.5.database", "5");
		redisConfig.put("com.medplus.redis.logical.6.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.6.database", "6");
		redisConfig.put("com.medplus.redis.logical.7.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.7.database", "7");
		redisConfig.put("com.medplus.redis.logical.8.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.8.database", "8");
		redisConfig.put("com.medplus.redis.logical.9.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.9.database", "9");
		RedisKing redisKing = new RedisKing(redisConfig);
		redisKing.initRedisKing();
		jedisConnection = RedisKing.getJedisServer().getJedisConnection();
		
		
		//System.out.println(jedisConnection.eval("return 10"));
		//System.out.println("result"+jedisConnection.evalsha("return 10"));
		
		RedisPubSub.getInstance().subscribe("test-pub-sub", new PubSubAction() {

			@Override
			public void onMessage(String channel, String message) {
				
				System.out.println("channel : "+channel + " message : "+message);
			}
			
		}, 60000, "test-pub-sub");
		
		RedisPubSub.getInstance().psubscribe(9 ,"test-pub-sub-pattern", new PubSubAction() {

			@Override
			public void onPMessage(String pattern, String channel, String message) {
				
				System.out.println("pattern : "+ pattern +"channel : "+channel + " message : "+message);
			}
			
			@Override
			public void onMessage(String channel, String message) {
				
				System.out.println("channel : "+channel + " message : "+message);
			}
			
		}, 60000, "test*","pattern*");
		
		while(true){
			
		}
	}
	
	@Test
	public void testPubSub() throws Exception{

		Map<String, String> redisConfig = new HashMap<String, String>();
		redisConfig.put("com.medplus.redis.sentinel.master.name", "redis-cluster");
		redisConfig.put("com.medplus.redis.sentinel.1.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.1.port", "26379");
		redisConfig.put("com.medplus.redis.sentinel.2.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.2.port", "26380");
		redisConfig.put("com.medplus.redis.sentinel.3.ip", "127.0.0.1");
		redisConfig.put("com.medplus.redis.sentinel.3.port", "26381");
		redisConfig.put("com.medplus.redis.logical.0.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.0.database", "0");
		redisConfig.put("com.medplus.redis.logical.1.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.1.database",	"1");
		redisConfig.put("com.medplus.redis.logical.2.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.2.database", "2");
		redisConfig.put("com.medplus.redis.logical.3.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.3.database", "3");
		redisConfig.put("com.medplus.redis.logical.4.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.4.database", "4");
		redisConfig.put("com.medplus.redis.logical.5.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.5.database", "5");
		redisConfig.put("com.medplus.redis.logical.6.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.6.database", "6");
		redisConfig.put("com.medplus.redis.logical.7.master","redis-cluster");
		redisConfig.put("com.medplus.redis.logical.7.database", "7");
		redisConfig.put("com.medplus.redis.logical.8.master", "redis-cluster");
		redisConfig.put("com.medplus.redis.logical.8.database", "8");
		RedisKing redisKing = new RedisKing(redisConfig);
		redisKing.initRedisKing();
		JedisConnection jedisConnection = RedisKing.getJedisServer().getJedisConnection();
		
		jedisConnection.pubsub("test-pub-sub", new PubSubAction() {

			@Override
			public void onMessage(String channel, String message) {
				
				System.out.println("channel : "+channel + " message : "+message);
			}
			
		}, 60000, "test-pub-sub");
	}
	@Test
	public void setGetTest(){
		String res = jedisConnection.set("test0", "test0");
		assertEquals("OK",res);
		String type0 = jedisConnection.get("test0");
		assertEquals("test0",type0);
		String fres = jedisConnection.get("test123");
		assertNull(fres);
		String resNull=jedisConnection.set(null, "test1");
		assertEquals(null,resNull);
		String getNull=jedisConnection.get(null);
		assertNull(getNull);
	}

	@Test
	public void setTest(){
		String res=jedisConnection.set("setparams", "setparams",SetParams.setParams().nx());
		assertEquals("OK",res);
		res=jedisConnection.set("setparams123", "setparams123",SetParams.setParams().xx());
		assertNull(res);
	}

	@Test
	public void existsTest(){
		jedisConnection.set("sai", "value");
		Boolean res=jedisConnection.exists("sai");
		assertTrue(res);
		Boolean fres=jedisConnection.exists("value");
		assertFalse(fres);
		String s = null;
		Boolean fres1=jedisConnection.exists(s);
		assertNull(fres1);
	}

	@Test
	public void typeTest(){
		String type=jedisConnection.type("test0");
		assertEquals("string",type);
		String type1=jedisConnection.type(null);
		assertNull(type1);
		String type2=jedisConnection.type("typeTest");
		assertEquals("none",type2);
	}

	@Test
	public void expireTtlTest(){
		jedisConnection.set("expireTtlTest", "test0");
		Long expire=jedisConnection.expire("expireTtlTest",20);
		Long l=1l;
		assertEquals(l,expire);
		Long ttl=jedisConnection.ttl("expireTtlTest");
		l=20l;
		assertEquals(l, ttl);
		Long expire1=jedisConnection.expire("test1",20);
		l=0l;
		assertEquals(l,expire1);
		Long ttl1=jedisConnection.ttl("test1");
		l=-2l;
		assertEquals(l, ttl1);
		Long expire2=jedisConnection.expire(null,20);
		assertNull(expire2);
		Long ttl2=jedisConnection.ttl(null);
		assertNull(ttl2);
		Long expireAt=jedisConnection.expireAt("expireTtlTest",20);
		l=1l;
		assertEquals(l,expireAt);
		Long expireAt1=jedisConnection.expireAt("test1",20);
		l=0l;
		assertEquals(l,expireAt1);
		Long expireAt2=jedisConnection.expireAt(null,20);
		assertNull(expireAt2);
		Long ttl3=jedisConnection.ttl("test0");
		l=-2l;
		assertEquals(l, ttl3);
	}

	@Test
	public void pexpireTest(){
		jedisConnection.set("pexpireTest", "pexpireTest");
		Long res=jedisConnection.pexpire("pexpireTest", 1200);
		Long l=1l;
		assertEquals(res,l);
		jedisConnection.set("pexpireTest1", "pexpireTest1");
		res=jedisConnection.pexpire("pexpireTest",120234560);
		l=1l;
		assertEquals(res,l);
	}

	@Test
	public void pttlTest(){
		Long res=jedisConnection.pttl("pexpireTest");
		Long l=-2l;
		assertEquals(res,l);
		jedisConnection.psetex("pexpireTest",10000, "pexpireTest");
		res=jedisConnection.pttl("pexpireTest");
		assertNotNull(res);
	}

	@Test
	public void setGetBitTest(){
		jedisConnection.set("setbit", "value");
		Boolean res=jedisConnection.setbit("test0",3,true);
		assertFalse(res);
		res=jedisConnection.setbit("setbit",3,false);
		assertTrue(res);
		res=jedisConnection.setbit("setbit",3,true);
		assertFalse(res);
		res=jedisConnection.setbit("setbit12",3,false);
		assertFalse(res);
		res=jedisConnection.setbit(null, 0, true);
		assertNull(null, res);
		res=jedisConnection.setbit("setbit",3,"0");
		assertTrue(res);
		res=jedisConnection.setbit("setbit",3,"0");
		assertFalse(res);
		res=jedisConnection.setbit("setbit1",3,"1");
		assertFalse(res);
		res=jedisConnection.setbit("setbit1",3,"0");
		assertTrue(res);
		res=jedisConnection.setbit(null, 0, "1");
		assertNull(null, res);
		res=jedisConnection.getbit("setbit",3);
		assertFalse(res);
		res=jedisConnection.getbit("setbit",30);
		assertFalse(res);
		res=jedisConnection.getbit(null, 0);
		assertNull(res);
	}

	@Test
	public void setGetRangeTest(){
		Long res=jedisConnection.setrange("test0", 1, "added");
		Long l=(long) (1+("added").length());
		assertEquals(l, res);
		res=jedisConnection.setrange("test1", 0, "added");
		l=(long) (0+("added").length());
		assertEquals(l, res);
		res=jedisConnection.setrange("test2", 23, "added");
		l=(long) (23+("added").length());
		assertEquals(l, res);
		res=jedisConnection.setrange(null, 0, "1236");
		assertNull(res);
		String getRange=jedisConnection.getrange("test1", 0, 10);
		assertEquals("added", getRange);
		getRange=jedisConnection.getrange(null, 0, 10);
		assertNull(getRange);
	}

	@Test
	public void getSet(){
		jedisConnection.set("getSet","getSet");
		String res=jedisConnection.getSet("getSet", "value");
		assertEquals(res,"getSet");
		res=jedisConnection.getSet("getSet1", "value1");
		assertNull(res);
		res=jedisConnection.getSet(null, "value");
		assertNull(res);
	}

	@Test
	public void setnxTest(){
		Long res=jedisConnection.setnx("key", "value");
		assertNotNull(res);
		res=jedisConnection.setnx("key1", "value");
		assertNotNull(res);
		res=jedisConnection.setnx(null, "value");
		assertNull(res);
	}

	@Test
	public void setexTest(){
		String res=jedisConnection.setex("key", 36, "value");
		assertEquals("OK", res);
		res=jedisConnection.setex(null, 10, "value");
		assertNull(res);
	}

	@Test
	public void decrTest(){
		Long res=jedisConnection.decr("key");
		Long l=-1l;
		assertEquals(res,l);
		jedisConnection.set("1", "10");
		res=jedisConnection.decr("1");
		l=9l;
		assertEquals(l,res);
		jedisConnection.set("1", "10");
		res=jedisConnection.decrBy("1",4);
		l=6l;
		assertEquals(l,res);
		res=jedisConnection.decr(null);
		assertNull(res);
	}

	@Test
	public void incrTest(){
		jedisConnection.set("1", "10");
		Long res=jedisConnection.incr("1");
		Long l=11l;
		assertEquals(l,res);
		res=jedisConnection.incrBy("1",10);
		l=21l;
		assertEquals(l,res);
		res=jedisConnection.incr(null);
		assertNull(res);
	}

	@Test
	public void incrByFloatTest(){
		jedisConnection.set("1","21");
		Double dres=jedisConnection.incrByFloat("1", 3.6);
		Double d=24.6;
		assertEquals(d,dres);
	}

	@Test
	public void appendSubTest(){
		Long res=jedisConnection.append("appendSubTest", "value");
		Long l=(long) "value".length();
		assertEquals(l, res);
		res=jedisConnection.append(null, "value");
		assertNull(res);
		String str=jedisConnection.substr("key", 0, 4);
		assertEquals("value", str);
		str=jedisConnection.substr("key4", 0, 4);
		assertEquals("", str);
		str=jedisConnection.substr(null, 0, 4);
		assertNull(str);
	}

	@Test
	public void hsetGetTest(){
		Long res=jedisConnection.hset("hkey", "field", "value");
		Long l=1l;
		assertEquals(l, res);
		res=jedisConnection.hset("hkey", "field", "value");
		l=0l;
		assertEquals(l, res);
		res=jedisConnection.hset(null, "field", "value");
		assertNull(res);
		String str=jedisConnection.hget("hkey", "field");
		assertEquals("value",str);
		str=jedisConnection.hget("hkey", "field2");
		assertNull(str);
		str=jedisConnection.hget(null, "field");
		assertNull(str);
		Map<String,String> result=jedisConnection.hgetAll("hkey");
		Map<String,String> map=new HashMap<String,String>();
		map.put("field", "value");
		assertEquals(result, map);
		result=jedisConnection.hgetAll(null);
		assertNull(result);
	}

	@Test
	public void hsetnxTest(){
		Long res=jedisConnection.hsetnx(null,"field","value");
		assertNull(res);
		jedisConnection.hset("hkey", "field", "value");
		Long l=0l;
		res=jedisConnection.hsetnx("hkey", "field", "value");
		assertEquals(l, res);
		res=jedisConnection.hsetnx("hkey1", "field", "value");
		l=1l;
		assertEquals(l, res);
	}
	@Test
	public void hmsetGetTest(){
		Map<String,String> hash=new HashMap<String,String>();
		hash.put("key", "value");
		hash.put("key", "value");
		String res=jedisConnection.hmset("hkey2", hash);
		assertEquals("OK", res);
		res=jedisConnection.hmset(null, hash);
		assertNull(res);
		List<String> list=jedisConnection.hmget("hkey2", "key");
		List<String> list2=new ArrayList<String>();
		list2.add("value");
		assertEquals(list, list2);
		list=jedisConnection.hmget("hkey2", "key2");
		list2=new ArrayList<String>();
		list2.add(null);
		assertEquals(list2,list);
		list=jedisConnection.hmget(null, "key");
		assertNull(list);
	}

	@Test
	public void hincrByTest(){
		Long res=jedisConnection.hincrBy("hkey2", "field", 30);
		Long l=30l;
		assertEquals(res, l);
		res=jedisConnection.hincrBy("hkey2", "field", 30);
		l=60l;
		assertEquals(res, l);
		res=jedisConnection.hincrBy(null, "field", 10);
		assertNull(res);
	}

	@Test
	public void hincrbyFloatTest(){
		Double dres=jedisConnection.hincrByFloat("hkey2", "field", 36.6);
		Double d=96.6;
		assertEquals(dres,d);
	}

	@Test
	public void hexistsTest(){
		Boolean value=jedisConnection.hexists("hfunctionsTest", "key");
		assertFalse(value);
		value=jedisConnection.hexists("hkey2", "key2");
		assertFalse(value);
		value=jedisConnection.hexists(null, "key");
		assertNull(value);
	}

	@Test
	public void hdelTest2(){
		jedisConnection.hset("hkey2", "key", "value");
		Long res=jedisConnection.hdel("hkey2", "key");
		Long l=1l;
		assertEquals(l, res);
		res=jedisConnection.hdel("hkey2", "key");
		l=0l;
		assertEquals(l, res);
		res=jedisConnection.hdel(null, "key");
		assertNull(res);
	}

	@Test
	public void rlpushTest(){
		Long res=jedisConnection.rpush("rlpushTest", "string");
		Long l=1l;
		assertEquals(res, l);
		res=jedisConnection.rpush(null, "string");
		assertNull(res);
		res=jedisConnection.lpush(null, "string");
		assertNull(res);
	}

	@Test
	public void rlpopTest(){
		jedisConnection.lpush("rlpopTest", "string");
		String res=jedisConnection.rpop("rlpopTest");
		assertEquals(res,"string");
		res=jedisConnection.rpop(null);
		assertNull(res);
		res=jedisConnection.lpop(null);
		assertNull(res);
	}

	@Test()
	public void llenTest(){
		jedisConnection.lpush("listFnctsTest", "value");
		Long res=jedisConnection.llen("listFnctsTest");
		Long l=1l;
		assertEquals(l,res);
		res=jedisConnection.llen("lkey10");
		l=0l;
		assertEquals(l,res);
		res=jedisConnection.llen(null);
		assertNull(res);
	}

	@Test
	public void lrangeTest(){
		List<String> result=jedisConnection.lrange("listFnctsTest", 0, -1);
		assertEquals(1,result.size());
		result=jedisConnection.lrange("lkey10", 0, -1);
		assertEquals(0,result.size());
		result=jedisConnection.lrange(null, 0, -1);
		assertNull(result);
	}

	public void ltrimTest(){
		String str=jedisConnection.ltrim("lkey", 0, 1);
		assertEquals("OK",str);
		str=jedisConnection.ltrim("lkey10", 0, 1);
		assertEquals("OK",str);
		str=jedisConnection.ltrim(null, 0, 3);
		assertNull(str);
	}

	@Test
	public void lindexTest(){
		jedisConnection.lpush("lkey","value");
		String str=jedisConnection.lindex("lkey", 0);
		assertEquals("value",str);
		str=jedisConnection.lindex("lkey", 10);
		assertNull(str);
		str=jedisConnection.lindex("lkey10", 0);
		assertNull(str);
	}

	public void lremTest(){
		Long res=jedisConnection.lrem("lkey", 1, "value1");
		Long l=1l;
		assertEquals(res,l);
		res=jedisConnection.lrem("lkey",7,"value");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.lrem(null, 1, "value");
		assertNull(res);
	}
	@Test
	public void lsetTest(){
		jedisConnection.lpush("lkey", "value");
		String str=jedisConnection.lset("lkey", 0, "value1");
		assertEquals("OK",str);
		str=jedisConnection.lset(null, 10, "value1");
		assertNull(str);
	}

	@Test
	public void saddTest(){
		jedisConnection.lpush("lkey", "test");
		Long res=jedisConnection.sadd("skey","value");
		Long l=1l;
		assertEquals(res,l);
		res=jedisConnection.sadd("skey", "value");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.sadd(null, "member");
		assertNull(res);
	}

	@Test
	public void smemebersTest(){
		Object[] mem=jedisConnection.smembers("skey").toArray();
		Object[] mem2={"member"};
		assertArrayEquals(mem, mem2);
		Set<String> res=jedisConnection.smembers("skey10");
		assertEquals(0,res.size());
		res=jedisConnection.smembers(null);
		assertNull(res);
	}

	@Test
	public void srempopTest(){
		jedisConnection.sadd("srempopTest", "value");
		Long res=jedisConnection.srem("srempopTest", "value");
		Long l=1l;
		assertEquals(res,l);
		res=jedisConnection.srem("srempopTest", "value");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.srem(null,"value");
		assertNull(res);
		String str=jedisConnection.spop("skey3");
		assertNull(str);
		str=jedisConnection.spop(null);
		assertNull(str);
		jedisConnection.sadd("srempopTest", "value","value2");
		Set<String> sstr=jedisConnection.spop("srempopTest", 2);
		assertEquals(sstr.size(),2);
	}

	@Test()
	public void scardTest(){
		jedisConnection.sadd("skey", "member");
		Long res=jedisConnection.scard("skey");
		Long l=1l;
		assertEquals(l,res);
		res=jedisConnection.scard("skey10");
		l=0l;
		assertEquals(l,res);
		res=jedisConnection.scard(null);
		assertNull(res);
	}

	@Test
	public void srandmember1Test(){
		jedisConnection.sadd("srandmember", "member","srandmember");
		List<String> lstr=jedisConnection.srandmember("srandmember", 2);
		assertEquals(lstr.size(),2);
	}

	@Test
	public void sismemberTest(){
		Boolean sis=jedisConnection.sismember("skey", "member");
		assertTrue(sis);
		sis=jedisConnection.sismember("skey", "member1");
		assertFalse(sis);
		sis=jedisConnection.sismember(null, "member");
		assertNull(sis);
	}

	@Test
	public void srandmemberTest(){
		jedisConnection.sadd("srandmemberTest", "member");
		String str=jedisConnection.srandmember("srandmemberTest");
		assertEquals("member",str);
		str=jedisConnection.srandmember("skey10");
		assertNull(str);
		str=jedisConnection.srandmember(null);
		assertNull(str);
	}

	@Test
	public void zaddTest(){
		Long res=jedisConnection.zadd("zkey",1,"zmember");
		Long l=1l;
		assertEquals(res,l);
		res=jedisConnection.zadd("zkey",1,"zmember");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.zadd(null,1,"zmember");
		assertNull(res);
		res=jedisConnection.zadd("zaddTest", 0, "zmember", ZAddParams.zAddParams().nx());
		assertNotEquals(l,res);
	}

	@Test
	public void zrangeTest(){
		jedisConnection.zadd("zrangeTest", 0, "member");
		Set<String> result=jedisConnection.zrange("zrangeTest", 0, -1);
		assertEquals(1,result.size());
		result=jedisConnection.zrange("zkey10", 0, -1);
		assertEquals(0,result.size());
		result=jedisConnection.zrange(null, 0, -1);
		assertNull(result);
	}

	@Test
	public void zrangeLexTest(){
		jedisConnection.zadd("zrangeTest", 0, "member1");jedisConnection.zadd("zrangeTest", 0, "member2");
		Set<String> result=jedisConnection.zrangeByLex("zrangeTest", "-", "+");
		assertEquals(result.size(),2);
		result=jedisConnection.zrangeByLex("zrangeTest", "-", "+",0,20);
		assertEquals(result.size(),2);
	}

	@Test()
	public void zremTest(){
		jedisConnection.zadd("zremTest", 10, "zmember");
		Long res=jedisConnection.zrem("zremTest", "zmember");
		Long l=1l;
		assertEquals(res,l);
		res=jedisConnection.zrem("zkey", "zmember");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.zrem(null, "zmember");
		assertNull(res);
	}

	@Test
	public void zincrbyTest(){
		jedisConnection.zadd("zkey",2, "smember2");
		Double res=jedisConnection.zincrby("zkey", 2, "smember2");
		Double d=4.0;
		assertEquals(res,d);
		res=jedisConnection.zincrby("zkey", 4, "smember3");
		assertEquals(res,d);
		res=jedisConnection.zincrby(null, 2, "smember2");
		assertNull(res);
		res=jedisConnection.zincrby("zkey", 3, "smember2",ZIncrByParams.zIncrByParams().xx());
		d=7.0;
		assertEquals(res,d);
	}

	@Test
	public void zrankTest(){
		jedisConnection.zadd("zkey2", 1, "smember3");
		Long res=jedisConnection.zrank("zkey2", "smember3");
		Long l=0l;
		assertEquals(res,l);
		res=jedisConnection.zrank("zkey", "smember10");
		assertNull(res);
		res=jedisConnection.zrank(null, "member");
		assertNull(res);
	}

	@Test
	public void zrevrankTest(){
		jedisConnection.zadd("zrevrankTest", 12, "zrevrankTest");
		Long res=jedisConnection.zrevrank("zrevrankTest", "zrevrankTest");
		Long l=0l;
		assertEquals(res,l);
		res=jedisConnection.zrevrank("zkey", "smember10");
		assertNull(res);
		res=jedisConnection.zrevrank(null, "member");
		assertNull(res);
	}

	@Test
	public void zrevrangeTest(){
		jedisConnection.zadd("zkey", 0,"member");
		jedisConnection.zadd("zkey", 0,"member1");
		Set<String> result=jedisConnection.zrevrange("zkey",0, -1);
		assertEquals(2,result.size());
		result=jedisConnection.zrevrange("zkey10", 0, -1);
		assertEquals(0,result.size());
		result=jedisConnection.zrevrange(null, 0, -1);
		assertNull(result);
	}

	@Test
	public void zrevrangeLexTest(){
		jedisConnection.zadd("zrangeTest", 0, "member1");jedisConnection.zadd("zrangeTest", 0, "member2");
		assertEquals(jedisConnection.zrevrangeByLex("zrangeTest", "+", "-").size(),2);
		assertEquals(jedisConnection.zrevrangeByLex("zrangeTest", "+", "-",1,2).size(),1);
	}

	@Test
	public void zrangeWithScoresTest(){
		jedisConnection.zadd("zrangeWithScoresTest", 1, "zrangeWithScoresTest");
		jedisConnection.zadd("zrangeWithScoresTest", 1, "zrangeWithScoresTest1");
		Set<Tuple> result=jedisConnection.zrangeWithScores("zrangeWithScoresTest", 0, -1);
		assertNotNull(result);
		result=jedisConnection.zrangeWithScores("zkey10", 0, -1);
		assertEquals(0,result.size());
		result=jedisConnection.zrangeWithScores("lkey", 0, -1);
		assertEquals(result.size(),0);
		result=jedisConnection.zrangeWithScores(null, 0, -1);
		assertNull(result);
	}

	@Test
	public void zrevrangeWithScoresTest(){
		Set<Tuple> result=jedisConnection.zrevrangeWithScores("zkey", 0, -1);
		assertEquals(2,result.size());
		result=jedisConnection.zrevrangeWithScores("zkey10", 0, -1);
		assertEquals(0,result.size());
		result=jedisConnection.zrevrangeWithScores(null, 0, -1);
		assertNull(result);
	}

	@Test
	public void zcardTest(){
		jedisConnection.zadd("zkey",1, "value1");
		jedisConnection.zadd("zkey",2, "value2");
		jedisConnection.zadd("zkey",3, "value3");
		jedisConnection.zadd("zkey",4, "value4");
		Long result=jedisConnection.zcard("zkey");
		Long l=4l;
		assertEquals(l,result);
		result=jedisConnection.zcard("zcardTest");
		l=0l;
		assertEquals(l,result);
		result=jedisConnection.zcard("lkey");
		assertEquals(result,l);
		result=jedisConnection.zcard(null);
		assertNull(result);
	}

	@Test
	public void zscoreTest(){
		jedisConnection.zadd("zscoreTest", 4, "smember2");
		Double result=jedisConnection.zscore("zscoreTest","smember2");
		Double d=4.0;
		assertEquals(d,result);
		result=jedisConnection.zscore("zkey10","smember");
		assertNull(result);
		result=jedisConnection.zscore(null,"smember");
		assertNull(result);
	}

	@Test
	public void sortTest(){
		List<String> res=jedisConnection.sort("lkey123");
		assertEquals(res.size(),0);
		res=jedisConnection.sort(null);
		assertNull(res);
		res=jedisConnection.sort("zkey",new SortingParams().alpha());
		assertEquals("member",res.get(0));
		res=jedisConnection.sort("lkey123",new SortingParams().alpha());
		assertEquals(res.size(),0);
		res=jedisConnection.sort(null,new SortingParams().alpha());
		assertNull(res);
	}

	@Test()
	public void zcountTest(){
		jedisConnection.zadd("zcountTest", 2, "zcountTest");
		jedisConnection.zadd("zcountTest", 11, "zcountTest1");
		jedisConnection.lpush("lkey", "value");
		Long res=jedisConnection.zcount("zcountTest", 0, 12);
		Long l=2l;
		assertEquals(res,l);
		res=jedisConnection.zcount("zcountTest1", 0, 12);
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.zcount(null, 0, 'm');
		assertNull(res);
		jedisConnection.lpop("lkey");
	}

	@Test
	public void zlexcountTest(){
		jedisConnection.zadd("zlexcount", 1, "member");jedisConnection.zadd("zlexcount", 1, "member1");jedisConnection.zadd("zlexcount", 1, "member2");
		Long res=jedisConnection.zlexcount("zlexcount", "-", "+");
		Long l=3l;
		assertEquals(res,l);
	}

	@Test
	public void zrangeByScoreTest(){
		jedisConnection.zadd("zrangeByScoreTest", 3, "zrangeByScoreTest");
		jedisConnection.zadd("zrangeByScoreTest", 12, "zrangeByScoreTest1");
		Set<String> result=jedisConnection.zrangeByScore("zrangeByScoreTest", 0, 12);
		assertEquals(result.size(),2);
		assertEquals("zrangeByScoreTest",result.toArray()[0]);
		result=jedisConnection.zrangeByScore("zkey12", 0, 12);
		assertEquals(result.size(),0);
		result=jedisConnection.zrangeByScore(null, 0, 12);
		assertNull(result);
	}

	@Test
	public void zrevrangeByScoreTest(){
		Set<String> result=jedisConnection.zrevrangeByScore("zrangeByScoreTest", 12,0);
		assertEquals(result.size(),2);
		assertEquals("zrangeByScoreTest1",result.toArray()[0]);
		result=jedisConnection.zrevrangeByScore("zkey12",12,0);
		assertEquals(result.size(),0);
		result=jedisConnection.zrevrangeByScore(null,12,0);
		assertNull(result);
	}

	@Test
	public void zrangeByScoreTest2(){
		Set<String> result=jedisConnection.zrangeByScore("zkey", 0, 12,0,2);
		assertEquals(result.size(),2);
		assertEquals("value1",result.toArray()[0]);
		result=jedisConnection.zrangeByScore("zkey12", 0, 12,0,2);
		assertEquals(result.size(),0);
		result=jedisConnection.zrangeByScore(null, 0, 12,0,2);
		assertNull(result);
	}

	@Test
	public void zrevrangeByScoreTest2(){
		Set<String> result=jedisConnection.zrevrangeByScore("zkey", 0, 12,0,2);
		assertEquals(result.size(),2);
		assertEquals("value1",result.toArray()[0]);
		result=jedisConnection.zrevrangeByScore("zkey12", 0, 12,0,2);
		assertEquals(result.size(),0);
		result=jedisConnection.zrevrangeByScore(null, 0, 12,0,2);
		assertNull(result);
		result=jedisConnection.zrevrangeByScore("zkey", "+inf","-inf",0,2);
		assertEquals(result.size(),2);
		assertEquals("value4",result.toArray()[0]);
		result=jedisConnection.zrevrangeByScore("zkey12", "+inf","-inf",0,2);
		assertEquals(result.size(),0);
		result=jedisConnection.zrevrangeByScore(null, "+inf","-inf",0,2);
		assertNull(result);
	}

	@Test
	public void zrangeByScoreWithScoresTest(){
		jedisConnection.zadd("zrangeByScoreWithScoresTest", 0, "member");
		jedisConnection.zadd("zrangeByScoreWithScoresTest",12, "member1");
		Set<Tuple> result=jedisConnection.zrangeByScoreWithScores("zrangeByScoreWithScoresTest",0, 12);
		assertEquals(result.size(),2);
		result=jedisConnection.zrangeByScoreWithScores("zkey12", 0, 12);
		assertEquals(result.size(),0);
		result=jedisConnection.zrangeByScoreWithScores(null, 0, 12);
		assertNull(result);
	}

	@Test
	public void zrevrangeByScoreWithScoresTest(){
		jedisConnection.zadd("zrevrangeByScoreWithScoresTest", 0, "member");
		jedisConnection.zadd("zrevrangeByScoreWithScoresTest", 11, "member1");
		Set<Tuple> result=jedisConnection.zrevrangeByScoreWithScores("zrevrangeByScoreWithScoresTest", 12, 0);
		assertEquals(result.size(),2);
		result=jedisConnection.zrevrangeByScoreWithScores("zkey12",12, 0);
		assertEquals(result.size(),0);
		result=jedisConnection.zrevrangeByScoreWithScores(null,12, 0);
		assertNull(result);
		result=jedisConnection.zrevrangeByScoreWithScores("zrevrangeByScoreWithScoresTest","+inf","-inf");
		assertEquals(result.size(),2);
		result=jedisConnection.zrevrangeByScoreWithScores("zkey12","+inf","-inf");
		assertEquals(result.size(),0);
		result=jedisConnection.zrevrangeByScoreWithScores(null,"+inf","-inf");
		assertNull(result);
	}

	@Test
	public void zrangeByScoreWithScoresTest2(){
		jedisConnection.zadd("zrevrangeByScoreWithScoresTest", 0, "member");
		jedisConnection.zadd("zrevrangeByScoreWithScoresTest", 11, "member1");
		Set<Tuple> result=jedisConnection.zrangeByScoreWithScores("zrevrangeByScoreWithScoresTest", 0, 12,0,2);
		assertEquals(result.size(),2);
		result=jedisConnection.zrangeByScoreWithScores("zkey12", 0, 12,0,2);
		assertEquals(result.size(),0);
		result=jedisConnection.zrangeByScoreWithScores(null, 0, 12,0,2);
		assertNull(result);
	}

	@Test
	public void zrevrangeByScoreWithScoresTest2(){
		Set<Tuple> result=jedisConnection.zrevrangeByScoreWithScores("zkey", 0, 12,0,2);
		assertEquals(result.size(),2);
		result=jedisConnection.zrevrangeByScoreWithScores("zkey12", 0, 12,0,2);
		assertEquals(result.size(),0);
		result=jedisConnection.zrevrangeByScoreWithScores(null, 0, 12,0,2);
		assertNull(result);
		result=jedisConnection.zrevrangeByScoreWithScores("zkey", "+inf","-inf",0,2);
		assertEquals(result.size(),2);
		result=jedisConnection.zrevrangeByScoreWithScores("zkey12", "+inf","-inf",0,2);
		assertEquals(result.size(),0);
		result=jedisConnection.zrevrangeByScoreWithScores(null,"+inf","-inf",0,2);
		assertNull(result);
	}

	@Test
	public void zremrangeByRankTest(){
		jedisConnection.zadd("zremrangeByRankTest", 0, "value1");
		jedisConnection.zadd("zremrangeByRankTest", 1, "value2");
		jedisConnection.zadd("zremrangeByRankTest",2, "value3");
		Long res=jedisConnection.zremrangeByRank("zremrangeByRankTest", 0, 2);
		Long l=3l;
		assertEquals(l,res);
		res=jedisConnection.zremrangeByRank("zremrangeByRankTest", 0, 2);
		l=0l;
		assertEquals(l,res);
		res=jedisConnection.zremrangeByRank(null, 0, 2);
		assertNull(res);
	}

	@Test
	public void zremrangeByScoreTest(){
		jedisConnection.zadd("zkey", 1, "zmember1");
		jedisConnection.zadd("zkey", 12, "zmember2");
		Long res=jedisConnection.zremrangeByScore("zkey", 0, 12);
		Long l=2l;
		assertEquals(l,res);
		res=jedisConnection.zremrangeByScore("zkey", 0, 2);
		l=0l;
		assertEquals(l,res);
		res=jedisConnection.zremrangeByScore(null, 0, 2);
		assertNull(res);
	}

	@Test
	public void linserttest(){
		jedisConnection.lpush("listkey", "value1");
		jedisConnection.lpush("listkey", "value2");
		Long res=jedisConnection.linsert("listkey", LIST_POSITION.BEFORE, "value1","added");
		Long l=3l;
		assertEquals(res,l);
		res=jedisConnection.linsert("listkey10", LIST_POSITION.BEFORE, "value1","added");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.linsert(null, LIST_POSITION.BEFORE, "value1","added");
		assertNull(res);
	}

	@Test
	public void infoTest(){
		String res=jedisConnection.info();
		assertNotNull(res);
	}

	@Test
	public void delTest(){
		jedisConnection.set("keys1", "value1");
		jedisConnection.set("key2", "value2");
		Long res=jedisConnection.del("keys1","key2");
		Long l=2l;
		assertEquals(res,l);
		res=jedisConnection.del("keys1","key2");
		l=0l;
		assertEquals(res,l);
	}

	@Test
	public void keysTest(){
		jedisConnection.set("keysTest", "value");
		Set<String> keys=jedisConnection.keys("*key*");
		assertNotEquals(keys.size(),0);
		keys=jedisConnection.keys("*association*");
		assertEquals(keys.size(),0);
		keys=jedisConnection.keys(null);
		assertNull(keys);
	}

	@Test
	public void zinterscoreTest(){
		jedisConnection.zadd("zkey1",0,"value1");
		jedisConnection.zadd("zkey2",10,"value1");
		Long res=jedisConnection.zinterstore("zdst","zkey1","zkey2");
		Long l=1l;
		assertEquals(res,l);
		Double d=jedisConnection.zscore("zdst", "value1");
		Double d1=10.0;
		assertEquals(d,d1);
		res=jedisConnection.zinterstore("zdst","zkey10","zkey2");
		l=0l;
		assertEquals(res,l);
	}

	@Test
	public void zunionstoreTest(){
		jedisConnection.zadd("zunionstoreTest",0,"value2");
		jedisConnection.zadd("zunionstoreTest1",10,"value3");
		Long res=jedisConnection.zunionstore("zdst","zunionstoreTest","zunionstoreTest1");
		Long l=2l;
		assertEquals(res,l);
		Double d=jedisConnection.zscore("zdst", "value3");
		Double d1=10.0;
		assertEquals(d,d1);
		res=jedisConnection.zunionstore("zdst1","zunionstoreTest","zkey220");
		l=1l;
		assertEquals(res,l);
		res=jedisConnection.zunionstore("zdst2","lkey","zkey2");
		assertNotNull(res);
		res=jedisConnection.zunionstore("zdst1",new ZParams().aggregate(Aggregate.SUM),"zunionstoreTest","zunionstoreTest1");
		l=2l;
		assertEquals(res,l);
		res=jedisConnection.zunionstore("zdst2",new ZParams().aggregate(Aggregate.SUM),"lkey","zkey2");
		assertNotNull(res);
		res=jedisConnection.zunionstore(null,new ZParams().aggregate(Aggregate.SUM),"lkey","zkey2");
		assertNull(res);
	}

	@Test
	public void flushallTest(){
		assertEquals(jedisConnection.flushDB(),"OK");
		assertEquals(jedisConnection.flushAll(),"OK");
	}

	@Test
	public void zinterstoreTest2(){
		jedisConnection.zadd("zkey1",0,"value1");
		jedisConnection.zadd("zkey2",10,"value1");
		Long res=jedisConnection.zinterstore("zdst",new ZParams().aggregate(Aggregate.MIN),"zkey1","zkey2");
		Long l=1l;
		assertEquals(res,l);
		Double d=jedisConnection.zscore("zdst", "value1");
		Double d1=0.0;
		assertEquals(d,d1);
		res=jedisConnection.zinterstore("zdst",new ZParams().aggregate(Aggregate.MIN),"zkey10","zkey2");
		l=0l;
		assertEquals(res,l);
	} 

	@Test
	public void hdelTest(){
		jedisConnection.hset("hkey2", "field1", "value1");
		jedisConnection.hset("hkey2", "field2", "value1");
		jedisConnection.hset("hkey2", "field3", "value1");
		Long res=jedisConnection.hdel("hkey2", "field1");
		Long l=1l;
		assertEquals(res,l);
		res=jedisConnection.hdel("hkey2", "field3","field2");
		l=2l;
		assertEquals(res,l);
		res=jedisConnection.hdel("hkey10", "field");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.hdel(null, "field");
		assertNull(res);
	}

	@Test
	public void hlenTest(){
		jedisConnection.hset("hlenTest", "field1", "value1");
		jedisConnection.hset("hlenTest", "field2", "value1");
		jedisConnection.hset("hlenTest", "field3", "value1");
		Long res=jedisConnection.hlen("hlenTest");
		Long l=3l;
		assertEquals(res,l);
		res=jedisConnection.hlen("hkey10");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.hlen(null);
		assertNull(res);
	}

	@Test
	public void hkeysTest(){
		jedisConnection.hset("hlenTest", "field1", "value1");
		jedisConnection.hset("hlenTest", "field2", "value1");
		jedisConnection.hset("hlenTest", "field3", "value1");
		Set<String> result=jedisConnection.hkeys("hlenTest");
		assertEquals(result.size(),3);
		assertTrue(result.contains("field1"));
		result=jedisConnection.hkeys("hkey10");
		assertEquals(result.size(),0);
		result=jedisConnection.hkeys(null);
		assertNull(result);
	}

	@Test
	public void hvalsTest(){
		jedisConnection.hset("hvalsTest", "field", "value");
		jedisConnection.hset("hvalsTest", "field1", "value1");
		List<String> result=jedisConnection.hvals("hvalsTest");
		assertEquals(result.size(),2);
		assertTrue(result.contains("value1"));
		result=jedisConnection.hvals("hkey10");
		assertEquals(result.size(),0);
		result=jedisConnection.hvals(null);
		assertNull(result);
	}

	@Test
	public void lpushTest(){
		Long res=jedisConnection.lpush("lpushTest", "val","val2","val3");
		Long l=3l;
		assertEquals(res,l);
		res=jedisConnection.lpush( null,"listkey","val4");
		assertNull(res);
	}

	@Test
	public void lpushxTest(){
		Long res=jedisConnection.lpushx("lpushxTest", "val");
		Long l=0l;
		assertEquals(res,l);
		res=jedisConnection.lpushx("listkey10", "val");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.lpushx(null,"val2");
		assertNull(res);
	}

	@Test
	public void rpushTest(){
		Long res=jedisConnection.rpush("listkey", "val","val2","val3");
		Long l=3l;
		assertEquals(res,l);
	}

	@Test
	public void rpushxTest(){
		jedisConnection.lpush("keylist", "val");
		String res = jedisConnection.lpop("keylist");
		assertEquals("val", res);
		jedisConnection.rpushx("keylist0", "val");
		res = jedisConnection.lpop("keylist0");
		assertNull(res);
		jedisConnection.del("keylist");
	}

	@Test
	public void saddmulTest(){
		jedisConnection.lpush("list", "val1");
		Long res=jedisConnection.sadd("set12", "member1","member2");
		Long l=2l;
		assertEquals(res,l);
		res=jedisConnection.sadd(null, "member","member2");
		assertNull(res);
		jedisConnection.lpop("list");
	}

	@Test
	public void sremmulTest(){
		jedisConnection.sadd("sremmulTest", "member1","member2");
		Long res=jedisConnection.srem("sremmulTest", "member1","member2");
		Long l=2l;
		assertEquals(l,res);
		res=jedisConnection.srem("sremmulTest", "member1","member2");
		l=0l;
		assertEquals(l,res);
		res=jedisConnection.srem(null, "member2","member1");
		assertNull(res);
	}

	@Test
	public void zcountTest2(){
		jedisConnection.zadd("zcountTest2", 1, "zvalue");
		jedisConnection.zadd("zcountTest2", 2, "zvalue2");
		Long res=jedisConnection.zcount("zcountTest2", "-inf", "+inf");
		Long l=2l;
		assertEquals(res,l);
		res=jedisConnection.zcount("zcountTest2", "(5", "+inf");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.zcount(null, "-inf", "+inf");
		assertNull(res);
	}

	@Test
	public void zrangeByScoreTest3(){
		Map<String,Double> map=new HashMap<String,Double>();
		map.put("member",3.0);
		map.put("member2",3.0);
		jedisConnection.zadd("zrangeByScoreTest3", map);
		Set<String> result=jedisConnection.zrangeByScore("zrangeByScoreTest3","-inf","+inf");
		assertEquals(result.size(),2);
		assertEquals("member",result.toArray()[0]);
		result=jedisConnection.zrangeByScore("zcountTest20", "-inf","+inf");
		assertEquals(result.size(),0);
		result=jedisConnection.zrangeByScore(null,"-inf","+inf");
		assertNull(result);
	}

	@Test
	public void zrangeByScoreTest4(){
		Map<String,Double> map=new HashMap<String,Double>();
		map.put("member",3.0);
		map.put("member2",3.0);
		jedisConnection.zadd("zrangeByScoreTest3", map);
		Set<String> result=jedisConnection.zrangeByScore("zrangeByScoreTest3","-inf","+inf",0,2);
		assertEquals(result.size(),2);
		assertEquals("member",result.toArray()[0]);
		result=jedisConnection.zrangeByScore("zcountTest20","-inf","+inf",0,2);
		assertEquals(result.size(),0);
		result=jedisConnection.zrangeByScore(null,"-inf","+inf",0,2);
		assertNull(result);
	}

	@Test
	public void zrangeByScoreWithScoresTest3(){
		Map<String,Double> map=new HashMap<String,Double>();
		map.put("member",3.0);
		map.put("member2",3.0);
		jedisConnection.zadd("zrangeByScoreTest3", map);
		Set<Tuple> result=jedisConnection.zrangeByScoreWithScores("zrangeByScoreTest3", "-inf", "+inf");
		assertEquals(result.size(),2);
		result=jedisConnection.zrangeByScoreWithScores("zkey12","+inf", "-inf");
		assertEquals(result.size(),0);
		result=jedisConnection.zrangeByScoreWithScores(null, "+inf", "-inf");
		assertNull(result);
	}

	@Test
	public void zrangeByScoreWithScoresTest4(){
		Map<String,Double> map=new HashMap<String,Double>();
		map.put("member",3.0);
		map.put("member2",3.0);
		jedisConnection.zadd("zrangeByScoreTest3", map);
		Set<Tuple> result=jedisConnection.zrangeByScoreWithScores("zrangeByScoreTest3", "-inf", "+inf",0,2);
		assertEquals(result.size(),2);
		result=jedisConnection.zrangeByScoreWithScores("zkey12","-inf", "+inf",0,2);
		assertEquals(result.size(),0);
		result=jedisConnection.zrangeByScoreWithScores(null, "-inf", "+inf",0,2);
		assertNull(result);
	}

	@Test
	public void zremmulTest(){
		Long res=jedisConnection.zrem("zcountTest2", "zvalue","zvalue2");
		Long l=2l;
		assertEquals(res,l);
		res=jedisConnection.zrem("zcountTest2", "zvalue","zvalue2");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.zrem(null, "zvalue","zvalue2");
		assertNull(res);
	}

	@Test
	public void zremrangeByScoreTest2(){
		jedisConnection.zadd("zkey", 1, "zmember1");
		jedisConnection.zadd("zkey", 12, "zmember2");
		Long res=jedisConnection.zremrangeByScore("zkey", "-inf","+inf");
		Long l=2l;
		assertEquals(l,res);
		res=jedisConnection.zremrangeByScore("zkey","-inf","+inf");
		l=0l;
		assertEquals(l,res);
		res=jedisConnection.zremrangeByScore(null,"-inf","+inf");
		assertNull(res);
	}

	@Test
	public void persistTest(){
		jedisConnection.set("persistTest", "value");
		jedisConnection.expire("persistTest", 50);
		Long res=jedisConnection.persist("persistTest");
		Long l=1l;
		assertEquals(res,l);
		res=jedisConnection.persist("persistTest");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.persist(null);
		assertNull(res);
		jedisConnection.del("persistTest");
	}

	@Test
	public void strlenTest(){
		jedisConnection.set("strlen", "value");
		Long res=jedisConnection.strlen("strlen");
		Long l=(long) "value".length();
		assertEquals(res,l);
		res=jedisConnection.strlen("strlen1");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.strlen(null);
		assertNull(res);
	}

	@Test
	public void blrpopTest(){
		jedisConnection.lpush("blrpopTest", "string");
		jedisConnection.lpush("blrpopTest2", "string2");
		List<String> result=jedisConnection.blpop(10,"blrpopTest");
		assertEquals(result.size(),2);
		result=jedisConnection.blpop(5,"blrpopTest12");
		assertNull(result);
		jedisConnection.lpush("blrpopTest", "string");
		jedisConnection.lpush("blrpopTest2", "string2");
		result=jedisConnection.brpop(10,"blrpopTest");
		assertEquals(result.size(),2);
		result=jedisConnection.brpop(10, "blrpopTest3","blrpopTest2");
		assertEquals(result.size(),2);
		result=jedisConnection.blpop(10,"blrpopTest12");
		assertNull(result);
	}

	@Test
	public void echoTest(){
		String res=jedisConnection.echo("welcome to medplus");
		assertEquals(res,"welcome to medplus");
	}

	@Test()
	public void moveTest(){
		jedisConnection.set("moveTest", "value");
		Long res=jedisConnection.move("moveTest", 4);
		Long l=1l;
		assertEquals(res,l);
		res=jedisConnection.move("moveTest12", 4);
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.move(null, 2);
		assertNull(res);
	}

	@Test(expected=JedisDataException.class)
	public void configsetgetTest(){
		String res=jedisConnection.configSet("timeout", "300");
		assertEquals("OK",res);
		res=jedisConnection.configSet("test", "300");
		List<String> result=jedisConnection.configGet("t*");
		assertNotNull(result);
	}

	@Test
	public void slowlogTest(){
		jedisConnection.configSet("slowlog-log-slower-than", "10");
		jedisConnection.set("key12", "value12");
		Long len=jedisConnection.slowlogLen();
		assertNotNull(len);
	}

	@Test
	public void slowlogGet(){
		jedisConnection.configSet("slowlog-log-slower-than", "10");
		jedisConnection.set("key12", "value12");
		List<Slowlog> res=jedisConnection.slowlogGet();
		assertNotNull(res);
		res=jedisConnection.slowlogGet(1);
		assertNotNull(res);
	}

	@Test
	public void slowlogReset(){
		String str=jedisConnection.slowlogReset();
		assertEquals("OK",str);
		jedisConnection.configSet("slowlog-log-slower-than", "10000");
	}

	@Test
	public void objectTest(){
		jedisConnection.set("objectTest", "value");
		Long res=jedisConnection.objectRefcount("objectTest");
		Long l=1l;
		assertEquals(res,l);
	}

	@Test
	public void objectEncodingTest(){
		jedisConnection.set("objectTest","objectTest");
		String str=jedisConnection.objectEncoding("objectTest");
		assertEquals(str,"embstr");
	}

	@Test
	public void objectIdletimeTest(){
		jedisConnection.set("objectTest","objectTest");
		Long re=jedisConnection.objectIdletime("objectTest");
		Long l=0l;
		assertEquals(re,l);
	}

	@Test(expected=JedisDataException.class)
	public void msetgetTest(){
		String res=jedisConnection.mset("mset","value","mset1","value","mset2","value");
		assertEquals(res,"OK");
		res=jedisConnection.mset("mset","value","mset1","value","mset2");
		assertNull(res);
		List<String> result=jedisConnection.mget("mset","mset1","mset2");
		assertEquals(result.size(),3);
		result=jedisConnection.mget("mset","mset1","mset20");
		assertNull(result.get(2));
		result=jedisConnection.mget("mset","mset1",null);
		assertNull(result);
		res=jedisConnection.mset(null,"value","mset1","value");
		assertNull(res);
		Long setnx=jedisConnection.msetnx("mset","value","mset1","value","mset2","value");
		Long l=0l;
		assertEquals(setnx,l);
		setnx=jedisConnection.msetnx("mset36","value","mset37","value","mset38","value");
		l=1l;
		assertEquals(setnx,l);
		setnx=jedisConnection.msetnx(null,"value","mset37","value","mset38","value");
		assertNull(setnx);
		setnx=jedisConnection.msetnx("value","mset37","value","mset38","value");
		assertNull(setnx);
	}

	@Test(expected=JedisDataException.class)
	public void renameTest(){
		jedisConnection.set("renameTest","value");
		String res=jedisConnection.rename("renameTest", "renameTest2");
		assertEquals("OK",res);
		res=jedisConnection.rename("renameTest", "renameTest2");
		assertNull(res);
		Long result=jedisConnection.renamenx("renameTest2", "renameTest");
		Long l=1l;
		assertEquals(result,l);
		result=jedisConnection.renamenx("renameTest2", "renameTest");
		l=0l;
		assertEquals(result,l);
		result=jedisConnection.renamenx(null, "renameTest");
		assertNull(result);
		res=jedisConnection.rename(null, "renameTest");
		assertNull(res);
		jedisConnection.del("renameTest");
	}

	@Test
	public void rpoplpushTest(){
		jedisConnection.lpush("rpoplpushTest","string");
		jedisConnection.lpush("rpoplpushTest","string23");
		String res=jedisConnection.rpoplpush("rpoplpushTest", "dstkey");
		assertEquals("string",res);
		res=jedisConnection.rpoplpush("rpoplpushTest2", "dstkey");
		assertNull(res);
		res=jedisConnection.rpoplpush(null, "dstkey");
		assertNull(res);
		res=jedisConnection.brpoplpush("rpoplpushTest", "dstkey",10);
		assertEquals("string23",res);
		res=jedisConnection.brpoplpush(null, "dstkey",10);
		assertNull(res);
	}

	@Test
	public void sdiffTest(){
		jedisConnection.sadd("sdiffTest","value");
		jedisConnection.sadd("sdiffTest2","value3");
		Set<String> res=jedisConnection.sdiff("sdiffTest","sdiffTest2");
		assertNotNull(res);
		Long result=jedisConnection.sdiffstore("dest", "sdiffTest","sdiffTest2");
		Long l=1l;
		assertEquals(result,l);
		result=jedisConnection.sdiffstore("dest", "sdiffTest20","sdiffTest2");
		l=0l;
		assertEquals(result,l);

	}

	@Test
	public void sinterTest(){
		jedisConnection.sadd("sdiffTest","value3");
		jedisConnection.sadd("sdiffTest2","value3");
		Set<String> res=jedisConnection.sinter("sdiffTest","sdiffTest2");
		assertNotNull(res);
		Long result=jedisConnection.sinterstore("dest", "sdiffTest","sdiffTest2");
		Long l=1l;
		assertEquals(result,l);
		result=jedisConnection.sinterstore("dest", "sdiffTest20","sdiffTest2");
		l=0l;
		assertEquals(result,l);
	}

	@Test
	public void sunionTest(){
		jedisConnection.sadd("sdiffTest","value3");
		jedisConnection.sadd("sdiffTest2","value3");
		Set<String> res=jedisConnection.sunion("sdiffTest","sdiffTest2");
		assertNotNull(res);
		Long result=jedisConnection.sunionstore("dest", "sdiffTest","sdiffTest2");
		Long l=2l;
		assertEquals(result,l);
	}

	@Test(expected=JedisDataException.class)
	public void smoveTest(){
		jedisConnection.sadd("sdiffTest", "value3");
		Long res=jedisConnection.smove("sdiffTest", "smoveTest", "value3");
		Long l=1l;
		assertEquals(res,l);
		res=jedisConnection.smove("sdiffTest", "smoveTest", "value30");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.smove("sdiffTest",null, "value30");
		assertNull(res);
	}

	@Test
	public void sortstoreTest(){
		jedisConnection.lpush("sortstoreTest", "field");
		jedisConnection.lpush("sortstoreTest", "value");
		Long res=jedisConnection.sort("sortstoreTest",new SortingParams().alpha(),"dstsortstoreTest");
		Long l=2l;
		assertEquals(res,l);
		res=jedisConnection.sort("sortstoreTest45","dst");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.sort("sortstoreTest45",new SortingParams().asc(),"dst");
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.sort(null,new SortingParams().asc(),"dstkey");
		assertNull(res);
	}

	@Test
	public void watchTest(){
		String res=jedisConnection.watch("sortstoreTest");
		assertEquals("OK",res);
		res=jedisConnection.unwatch();
		assertEquals("OK",res);
	}

	@Test
	public void pubsubTest(){
		Long res=jedisConnection.publish("medpluschannel", "welcome to medplus");
		Long l=0l;
		assertEquals(res,l);
	}

	@Test
	public void randomKeyTest(){
		String res=jedisConnection.randomKey();
		assertNotNull(res);
		jedisConnection.flushDB();
		res=jedisConnection.randomKey();
		assertNull(res);
	}

	@Test
	public void pipelineTest(){
		Pipeline pipeline = jedisConnection.pipelined();
		assertNotNull(pipeline);
		pipeline.set("pipeline", "pipeline");
		List<Object> list= pipeline.syncAndReturnAll();
		assertNotNull(list);
	}
	
	@Test
	public void pipelineBlockTest(){
		
		List<Object> res = jedisConnection.pipelined(new PipelineBlock() {
			
			@Override
			public void execute() {
				set("PipelineB", "PipelineBlock");
				hset("PipelineBlock", "one", "one");
				hset("PipelineBlock", "two", "two");
				hset("PipelineBlock", "three", "three");
				hset("PipelineBlock", "four", "four");
			}
		});
		System.out.println("res : "+res);
		assertNotNull(res);
	}
	
	@Test
	public void pipelineBlockWithMultiSuccessTest(){
		
		List<Object> res = jedisConnection.pipelined(new PipelineBlock() {
			
			@Override
			public void execute() {
				multi();
				set("PipelineB1", "PipelineBlock");
				hset("PipelineBlock1", "one", "one");
				hset("PipelineBlock1", "two", "two");
				hset("PipelineBlock1", "three", "three");
				hset("PipelineBlock1", "four", "four");
			}
		});
		System.out.println("res : "+res);
		assertNotNull(res);
	}
	
	@Test
	public void pipelineBlockWithMultiFailureTest(){
		
		List<Object> res = jedisConnection.pipelined(new PipelineBlock() {
			
			@Override
			public void execute() {
				multi();
				set("PipelineBlock2", "PipelineBlock");
				hset("PipelineBlock2", "one", "one");
				hset("PipelineBlock2", "two", "two");
				hset("PipelineBlock2", "three", "three");
				hset("PipelineBlock2", "four", "four");
			}
		});
		System.out.println("res : "+res);
		assertNotNull(res);
	}


	@Test
	public void scanTest(){
		ScanResult<String> res=jedisConnection.scan("0");
		assertNotNull(res);
		res=jedisConnection.scan("-1");
		assertNotNull(res);
		res=jedisConnection.scan("0", new ScanParams().count(10));
	}

	@Test
	public void hscanTest(){
		ScanResult<Entry<String, String>> result=jedisConnection.hscan("hscanTest", "0");
		assertEquals(result.getResult().size(),0);
		jedisConnection.hset("hscanTest", "field", "hscanTest");
		result=jedisConnection.hscan("hscanTest", "0");
		assertNotEquals(result.getResult().size(),0);
		result=jedisConnection.hscan("hscanTest", "0",new ScanParams().match("hello*"));
		assertEquals(result.getResult().size(),0);
	}

	@Test
	public void sscanTest(){
		ScanResult<String> res=jedisConnection.sscan("scanTestSet", "0");
		assertEquals(res.getResult().size(),0);
		jedisConnection.sadd("scanTestSet", "members","scanTestSet");
		res=jedisConnection.sscan("scanTestSet", "0",new ScanParams().count(10));
		assertNotEquals(res.getResult().size(),0);
	}

	@Test
	public void zscanTest(){
		ScanResult<Tuple> zres=jedisConnection.zscan("scanTestZSet", "0");
		assertEquals(zres.getResult().size(),0);
		jedisConnection.zadd("scanTestZSet",0,"scanTestZSet");
		zres=jedisConnection.zscan("scanTestZSet", "0",new ScanParams().count(10));
		assertNotEquals(zres.getResult().size(),0);
	}

	@Test
	public void zremrangeByLexTest(){
		jedisConnection.zadd("zremrangeByLexTest", 3.0,"zremrangeByLexTest");jedisConnection.zadd("zremrangeByLexTest", 3.0,"zremrangeByLexTest1");jedisConnection.zadd("zremrangeByLexTest", 3.0,"zremrangeByLexTest2");
		Long res=jedisConnection.zremrangeByLex("zremrangeByLexTest", "-", "+");
		Long l=3l;
		assertEquals(res, l);
	}

	@Test
	public void bitopTest(){
		jedisConnection.set("tkey", "tkey");jedisConnection.set("tkey1", "tkey123");
		Long res=jedisConnection.bitop(BitOP.AND, "dstkey", "tkey","tkey1");
		Long l=7l;
		assertEquals(res,l);
		res=jedisConnection.bitop(BitOP.AND, "dstkey", "tkey123","tkey124");
		l=0l;
		assertEquals(res,l);
	}

	@Test
	public void bitposTest(){
		jedisConnection.set("bitposTest", "bitpo1fbhvbgjh@");
		Long res=jedisConnection.bitpos("bitposTest", true);
		Long l=1l;
		assertEquals(res,l);
		res=jedisConnection.bitpos("bitposTest", false);
		l=0l;
		assertEquals(res,l);
		res=jedisConnection.bitpos("bitposTestno",true);
		l=-1l;
		assertEquals(res,l);
		res=jedisConnection.bitpos("bitposTest", true,new BitPosParams(0));
		l=1l;
		assertEquals(res,l);
	}

	@Test
	public void pfaddTest(){
		Long res=jedisConnection.pfadd("pfaddTest", "pfaddTest","pfaddTest1","pfaddTest2");
		Long l=1l;
		assertEquals(res,l);
	}

	@Test
	public void pfcountTest(){
		Long res=jedisConnection.pfadd("pfcountTest", "pfaddTest","pfaddTest1","pfaddTest2");
		res=jedisConnection.pfcount("pfcountTest");
		Long l=3l;
		assertEquals(res,l);
		jedisConnection.pfadd("pfcountTest1", "pfaddTest3","pfaddTest4","pfaddTest5");
		res=jedisConnection.pfcount("pfcountTest1","pfcountTest");
		l=6l;
		assertEquals(res,l);
	}

	@Test
	public void pfmergeTest(){
		jedisConnection.pfadd("pfmergeTest", "pfaddTest","pfaddTest1","pfaddTest2");
		jedisConnection.pfadd("pfmergeTest3", "pfaddTest","pfaddTest4","pfaddTest5");
		String res=jedisConnection.pfmerge("pfadddstkey", "pfmergeTest","pfmergeTest1");
		assertEquals(res,"OK");
	}
	
	@Test
	public void evalTest(){
		Object res=jedisConnection.eval("return 10");
		assertEquals(res, new Long(10));
		res=jedisConnection.eval("return 'hello'");
		assertEquals(res, "hello");
		res=jedisConnection.eval("");
		assertEquals(res, null);
		
		jedisConnection.eval("redis.call('set','sms_route_provider','p3')"
				+ "redis.call('hmset','p1','url','mart.com','uid','123123','pwd','123123')"
				+ "redis.call('hmset','p2','url','lab.com','uid','123123','pwd','123123')"
				+ "redis.call('hmset','p3','url','lens.com','uid','123123','pwd','123123')"
				+ ""
				+ "redis.call('hmset','1234','p1','1111','p2','2222','p3','3333','special','p1')"
				+ "redis.call('hmset','1235','p1','4444','p2','5555','p3','6666')"
				+ "redis.call('hmset','1236','p1','7777','p2','8888','p3','9999')"
				+ "");
		
		res=jedisConnection.eval(""
				+ "	local number=1235"
				+ "	local special=redis.call('hget',number,'special')"
				+ "	local srm=redis.call('get','sms_route_provider')"
				+ "	local finalresult = {}"
				+ "	local nextkey"
				+ "	local res"
				+ " local templateid"
			
				+ "	if special then"
				+ "		res=redis.call('hgetall',special)"
				+ "		templateid=special"
				+ "	else"
				+ "		res=redis.call('hgetall',srm)"
				+ "		templateid=srm"
				+ "	end"
				+ "	"
			
				+ "	for i, v in ipairs(res) do"
				+ "		if i % 2 == 1 then"
				+ "			nextkey = v"
				+ "		else if v~='mart.com' then"
				+ "			finalresult[nextkey] = v"
				+ "			end"
				+ "		end"
				+ "	end"
			
				+ "	finalresult['templateid']=redis.call('hget',number,templateid)"
				
				+ "	return cjson.encode(finalresult)");
		
		assertNotNull(res);
	}
	
	@Test
	public void evalTest2(){
		String str[]={"key1","key2","first","second"};
		Object res=jedisConnection.eval("return {KEYS[1],KEYS[2],ARGV[1],ARGV[2]}", 2, str);
		List<String> list=new ArrayList<String>();
		list.add("key1");list.add("key2");list.add("first"); list.add("second");
		assertEquals(res, list);
		res=jedisConnection.eval("return 10", 0,"");
		assertEquals(res, new Long(10));
		String str1[]={"key1","key2","key3","arg1","arg2"};
		res=jedisConnection.eval("return {KEYS[3],ARGV[1],ARGV[2]}", 3, str1);
		list=new ArrayList<String>();
		list.add("key3");list.add("arg1");list.add("arg2");
		assertEquals(res, list);
		res=jedisConnection.eval("", 0,"");
		assertEquals(res, null);
	}
	
	@Test
	public void evalTest3(){
		Object res=jedisConnection.eval("return 10", new ArrayList<String>(), new ArrayList<String>());
		assertEquals(res, new Long(10));
		List<String> keyList=new ArrayList<String>();
		keyList.add("key1");keyList.add("key2");
		List<String> argList=new ArrayList<String>();
		argList.add("arg1");argList.add("arg2");
		res=jedisConnection.eval("return {KEYS[1],KEYS[2],ARGV[1],ARGV[2]}",new ArrayList<String>(), new ArrayList<String>());
		assertEquals(res, new ArrayList<String>());
		res=jedisConnection.eval("return {KEYS[1],KEYS[2],ARGV[1],ARGV[2]}",keyList,argList);
		keyList.addAll(argList);
		assertEquals(keyList, res);
		res=jedisConnection.eval("return redis.call('set',KEYS[1],ARGV[1])", keyList, argList);
		assertEquals(res,"OK");
		assertEquals(argList.get(0),jedisConnection.get(keyList.get(0)));
	}
	
	@Test
	public void scriptLoadTest(){
		String res=jedisConnection.scriptLoad("return 10");
		assertNotNull(res);
		res=jedisConnection.scriptLoad("return redis.call('hset','sai','key','value')");
		assertNotNull(res);
		res=jedisConnection.scriptLoad("");
		assertNotNull(res);
	}
	
	@Test
	public void scriptExistsTest(){
		Boolean res=jedisConnection.scriptExists("709b5fb8ba54835dbeafc85d59fe139681c699c1");//script:return redis.call('hset','sai','key','value')
		assertTrue(res);
		res=jedisConnection.scriptExists("709b5fb8ba54835dbeafc85d59fe139681rgfthyc699c1");
		assertFalse(res);
		res=jedisConnection.scriptExists("");
		assertFalse(res);
		List<Boolean> list=jedisConnection.scriptExists("709b5fb8ba54835dbeafc85d59fe139681c699c1","da39a3ee5e6b4b0d3255bfef95601890afd80709");//script2:""
		List<Boolean> list2=new ArrayList<Boolean>();
		list2.add(true);list2.add(true);
		assertEquals(list,list2);
	}
	

	@Test(expected=JedisDataException.class)
	public void evalshaTest(){
		Object res=jedisConnection.evalsha("080c414e64bca1184bc4f6220a19c4d495ac896d");
		assertEquals(res, new Long(10));
		res=jedisConnection.evalsha("080c414e64bca1184bc4f6220a19c4d495ac896dh");
	}
	
	@Test
	public void evalshaTest2(){
		String str[]={"key1","key2","first","second"};
		Object res=jedisConnection.evalsha("a42059b356c875f0717db19a51f6aaca9ae659ea", 2, str);//script: return {KEYS[1],KEYS[2],ARGV[1],ARGV[2]}
		List<String> list=new ArrayList<String>();
		list.add("key1");list.add("key2");list.add("first"); list.add("second");
		assertEquals(res, list);
		res=jedisConnection.evalsha("080c414e64bca1184bc4f6220a19c4d495ac896d", 0,"");//script: return 10
		assertEquals(res, new Long(10));
		String str1[]={"key1","key2","key3","arg1","arg2"};
		res=jedisConnection.evalsha("0642a6cf68827e251f4cb5f76feb6ca9ddcda763", 3, str1);//script: return {KEYS[3],ARGV[1],ARGV[2]}
		list=new ArrayList<String>();
		list.add("key3");list.add("arg1");list.add("arg2");
		assertEquals(res, list);
		res=jedisConnection.evalsha("da39a3ee5e6b4b0d3255bfef95601890afd80709", 0,"");//script: return ""
		assertEquals(res, null);
	}
	
	@Test
	public void evalshaTest3(){
		Object res=jedisConnection.evalsha("080c414e64bca1184bc4f6220a19c4d495ac896d", new ArrayList<String>(), new ArrayList<String>());
		assertEquals(res, new Long(10));
		List<String> keyList=new ArrayList<String>();
		keyList.add("key1");keyList.add("key2");
		List<String> argList=new ArrayList<String>();
		argList.add("arg1");argList.add("arg2");
		res=jedisConnection.evalsha("a42059b356c875f0717db19a51f6aaca9ae659ea",new ArrayList<String>(), new ArrayList<String>());
		assertEquals(res, new ArrayList<String>());
		res=jedisConnection.evalsha("a42059b356c875f0717db19a51f6aaca9ae659ea",keyList,argList);
		keyList.addAll(argList);
		assertEquals(keyList, res);
		res=jedisConnection.evalsha("c686f316aaf1eb01d5a4de1b0b63cd233010e63d", keyList, argList);//script: return redis.call('set',KEYS[1],ARGV[1])
		assertEquals(res,"OK");
		assertEquals(argList.get(0),jedisConnection.get(keyList.get(0)));
	}
	
}
