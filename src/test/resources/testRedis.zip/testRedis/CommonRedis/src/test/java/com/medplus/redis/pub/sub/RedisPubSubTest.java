/**
 * 
 */
package com.medplus.redis.pub.sub;


import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import redis.clients.jedis.Jedis;
import redis.clients.util.Pool;

import com.medplus.redis.JedisConnection;
import com.medplus.redis.MyJedisInstance;
import com.medplus.redis.RedisKing;

/**
 * @author venkat
 *
 */
@Ignore
public class RedisPubSubTest {

	protected Mockery jmockContext;
	
	MyJedisInstance myJedisInstance;
    JedisConnection jedisConnection;
    RedisKing redisKing;
    RedisPubSub redisPubSub;
    
    
    Pool<Jedis> jedisPool;
    Jedis jedis;
    
	@Before
    public void setUp() {

    	jmockContext = new Mockery() {
    		{
    			setImposteriser(ClassImposteriser.INSTANCE);
    		}
    	};
    	
    	redisKing = jmockContext.mock(RedisKing.class);
    	jedisConnection = jmockContext.mock(JedisConnection.class);
    	myJedisInstance = jmockContext.mock(MyJedisInstance.class);
    	
    	redisPubSub = jmockContext.mock(RedisPubSub.class);
    }
	
	@After
    public void tearDown() {

        jmockContext.assertIsSatisfied();
    }
	
	@Test
	public void testPublish(){
		
		final Long result = 4l;
		jmockContext.checking(new Expectations(){
			{
				redisPubSub.publish(with(any(String.class)), with(any(String.class)));
				will(returnValue(result));
			}
		});
		
		Long resultEx = redisPubSub.publish("channel", "message");
		Assert.assertEquals(4l, resultEx.longValue());
	}
}
