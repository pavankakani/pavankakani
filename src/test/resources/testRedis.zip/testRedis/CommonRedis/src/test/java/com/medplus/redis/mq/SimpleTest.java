package com.medplus.redis.mq;

import com.medplus.redis.mq.Consumer;
import com.medplus.redis.mq.Packet;
import com.medplus.redis.mq.Queue;



public class SimpleTest {
	


public static void  main(String args[]) {
		
		Queue testQueue=Queue.CreateQueue("clicks");
		for (int i = 0; i < 10; i++) {
			testQueue.put("testpayload");
		}
		Consumer consumer=null;
		try {
			consumer = testQueue.addConsumer("testconsumer");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    if(consumer==null)
	    {
	    	System.out.println("Cannot create a Consumer");
	    	return;
	    }
		for (int  i= 0; i < 10; i++){
			Packet p = consumer.get();
			if(p==null)
			{
				System.out.println("Cannot get the packet");
				continue;
			}
			System.out.println(p.createdtime);
			p.ack();
			
		}
	}

}
