/**
 * 
 */
package com.medplus.redis;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import redis.clients.jedis.Jedis;
import redis.clients.util.Pool;


/**
 * @author venkat
 *
 */
public class JedisConnectionMockTest {

	protected Mockery jmockContext;
	
    JedisConnection jedisConnection;
    
    Pool<Jedis> jedisPool;
    Jedis jedis;
    
    @SuppressWarnings("unchecked")
	@Before
    public void setUp() {

    	jmockContext = new Mockery() {
    		{
    			setImposteriser(ClassImposteriser.INSTANCE);
    		}
    	};
    	
    	
    	jedisPool = jmockContext.mock(Pool.class);
    	jedis =  jmockContext.mock(Jedis.class);
    	jedisConnection = new JedisConnection(jedisPool);
    }

    @After
    public void tearDown() {

        jmockContext.assertIsSatisfied();
    }
    
    @Test
    public void testSet(){
    	
    	jmockContext.checking(new Expectations() {
            {
                one(jedisPool).getResource();
                will(returnValue(jedis));
                
                one(jedis).set(with(any(String.class)), with(any(String.class)));
                will(returnValue("OK"));
                
                one(jedis).close();
            }
        });
    	
    	String res = jedisConnection.set("test", "test");
    	Assert.assertEquals("OK", res);
    	
    }
}
